import React, { useState } from "react";
import WalletConnect from "./components/WalletConnect";
import AdminActions from "./components/AdminActions";
import InvestorActions from "./components/InvestorActions";
import "./styles.css";

function App() {
    const [account, setAccount] = useState(null);
    const [role, setRole] = useState("Unknown");

    return (
        <div className="main-container">
            <h1 className="platform-title">🎨 Artwork Tokenization Platform</h1>
    
            <WalletConnect onWalletConnected={(addr, userRole) => {
                setAccount(addr);
                setRole(userRole); 
            }} />
    
            {/* ✅ Display Role Only If It's Not "Unknown" */}
            {role !== "Unknown" && <p className="user-role"><strong>Role:</strong> {role}</p>}
    
            {role === "Admin" && <AdminActions account={account} />}
            {role === "Investor" && <InvestorActions account={account} />}
        </div>
    );    
}

export default App;
