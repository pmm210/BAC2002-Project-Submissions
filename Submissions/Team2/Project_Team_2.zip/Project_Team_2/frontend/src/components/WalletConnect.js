import React, { useState, useEffect } from "react";
import { ethers } from "ethers";
import { CONTRACT_ADDRESS, CONTRACT_ABI } from "../config";

const WalletConnect = ({ onWalletConnected }) => {
    const [account, setAccount] = useState(null);
    const [role, setRole] = useState("Checking...");

    useEffect(() => {
        if (!window.ethereum) {
            alert("Please install MetaMask!");
            return;
        }
        window.ethereum.on("accountsChanged", async (accounts) => {
            if (accounts.length > 0) {
                connectWallet();
            } else {
                setAccount(null);
                setRole("Unknown");
            }
        });

        window.ethereum.on("chainChanged", () => {
            window.location.reload(); // Reload on network change
        });
    }, []);

    const connectWallet = async () => {
        try {
            const provider = new ethers.BrowserProvider(window.ethereum);
            const accounts = await window.ethereum.request({ method: "eth_requestAccounts" });
            const userAddress = accounts[0];
            setAccount(userAddress);

            const contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, provider);
            
            // ✅ Check Role
            const isAdmin = await contract.hasRole(ethers.id("ADMIN_ROLE"), userAddress);
            const isKYC = await contract.isKYCVerified(userAddress);

            let userRole = "Unverified";
            if (isAdmin) userRole = "Admin";
            else if (isKYC) userRole = "Investor";

            setRole(userRole);
            onWalletConnected(userAddress, userRole); // ✅ Send role to App.js

        } catch (error) {
            console.error("Wallet Connection Failed", error);
        }
    };

    return (
        <div className="wallet-container">
            <button className="wallet-button" onClick={connectWallet}>
                {account ? `Connected: ${account.substring(0, 6)}...${account.slice(-4)}` : "Connect Wallet"}
            </button>
            <p className="wallet-status">
                <strong>Connected Address:</strong> {account || "Not Connected"}
            </p>
        </div>
    );    
};

export default WalletConnect;
