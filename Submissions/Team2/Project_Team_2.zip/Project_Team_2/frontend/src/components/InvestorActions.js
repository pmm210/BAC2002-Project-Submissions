import React, { useState } from "react";
import { ethers } from "ethers";
import { CONTRACT_ADDRESS, CONTRACT_ABI } from "../config";

const InvestorActions = ({ account }) => {
    const [recipient, setRecipient] = useState("");
    const [artwork, setArtwork] = useState("");
    const [amount, setAmount] = useState("");
    const [partitionBalance, setPartitionBalance] = useState("");
    const [allArtworks, setAllArtworks] = useState([]);

    /**
     * @dev Transfer tokens within the same artwork partition
     */
    const transferTokens = async () => {
        if (!recipient || !artwork || !amount) return alert("❌ Enter all details");

        try {
            const provider = new ethers.BrowserProvider(window.ethereum);
            const signer = await provider.getSigner();
            const userAddress = await signer.getAddress();

            const contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer);

            // ✅ Check if both sender and recipient are KYC verified before proceeding
            const isSenderVerified = await contract.isKYCVerified(userAddress);
            const isRecipientVerified = await contract.isKYCVerified(recipient);

            if (!isSenderVerified) return alert("❌ Error: You must be KYC verified to transfer tokens!");
            if (!isRecipientVerified) return alert("❌ Error: Recipient is not KYC verified!");

            // ✅ Check sender's partition balance before transferring
            const senderBalance = await contract.getPartitionBalance(userAddress, artwork);
            if (senderBalance < amount) return alert("❌ Error: Insufficient partition balance!");

            // ✅ Execute token transfer
            const tx = await contract.transferWithinPartition(recipient, artwork, amount);
            await tx.wait();
            alert(`✅ Transfer successful: ${amount} ${artwork} tokens sent to ${recipient}`);
        } catch (error) {
            console.error("❌ Transfer failed:", error);
            alert("❌ Token transfer failed");
        }
    };

    /**
     * @dev Get the balance of a specific artwork partition for the connected wallet
     */
    const checkPartitionBalance = async () => {
        if (!account || !artwork) return alert("❌ Enter the artwork name");

        try {
            const provider = new ethers.BrowserProvider(window.ethereum);
            const signer = await provider.getSigner();
            const userAddress = await signer.getAddress(); // ✅ Get dynamically connected MetaMask account

            const contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, provider);
            const balance = await contract.getPartitionBalance(userAddress, artwork);

            // ✅ If balance is zero, notify the user instead of showing nothing
            if (balance.toString() === "0") {
                setPartitionBalance(`❌ No tokens available for ${artwork}`);
            } else {
                setPartitionBalance(`${artwork}: ${balance.toString()} tokens`);
            }
        } catch (error) {
            console.error("❌ Failed to fetch partition balance", error);
            alert("❌ Failed to fetch partition balance");
        }
    };

    /**
     * @dev Fetch all artwork partitions
     */
    const getAllArtworks = async () => {
        try {
            const provider = new ethers.BrowserProvider(window.ethereum);
            const contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, provider);

            const artworks = await contract.getAllArtworks();
            if (artworks.length === 0) return alert("❌ No artworks have been created yet.");

            setAllArtworks(artworks);
        } catch (error) {
            console.error("❌ Failed to fetch artworks", error);
            alert("❌ Failed to fetch artworks");
        }
    };

    return (
        <div className="container">
            <h2>Investor Actions</h2>
    
            {/* ✅ Transfer Tokens */}
            <div className="action-group">
                <h3>Transfer Artwork Tokens</h3>
                <input type="text" placeholder="Recipient Address" value={recipient} onChange={(e) => setRecipient(e.target.value)} />
                <input type="text" placeholder="Artwork Name" value={artwork} onChange={(e) => setArtwork(e.target.value)} />
                <input type="number" placeholder="Amount" value={amount} onChange={(e) => setAmount(e.target.value)} />
                <button onClick={transferTokens}>Transfer Tokens</button>
            </div>
    
            {/* ✅ Check Partition Balance */}
            <div className="action-group">
                <h3>Check Partition Balance</h3>
                <input type="text" placeholder="Artwork Name" value={artwork} onChange={(e) => setArtwork(e.target.value)} />
                <button onClick={checkPartitionBalance}>Check Balance</button>
                <p className={`alert ${partitionBalance.includes("❌") ? "error" : "success"}`}><strong>Partition Balance:</strong> {partitionBalance}</p>
            </div>
    
            {/* ✅ Get All Artworks */}
            <div className="action-group">
                <h3>All Artwork Partitions</h3>
                <button onClick={getAllArtworks}>Get All Artworks</button>
                <ul>
                    {allArtworks.length === 0 ? <p className="alert error">❌ No artworks found</p> : allArtworks.map((art, index) => (
                        <li key={index}>🎨 {art}</li>
                    ))}
                </ul>
            </div>
        </div>
    );    
};

export default InvestorActions;
