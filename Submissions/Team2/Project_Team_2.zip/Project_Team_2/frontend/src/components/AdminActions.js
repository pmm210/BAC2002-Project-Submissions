import React, { useState } from "react";
import { ethers } from "ethers";
import { CONTRACT_ADDRESS, CONTRACT_ABI } from "../config";

const AdminActions = ({ account }) => {
    const [investor, setInvestor] = useState("");
    const [artwork, setArtwork] = useState("");
    const [amount, setAmount] = useState("");
    const [kycStatus, setKycStatus] = useState("");
    const [partitionBalance, setPartitionBalance] = useState("");
    const [allArtworks, setAllArtworks] = useState([]);

    /**
     * @dev Verify and add an investor to the KYC list
     */
    const verifyKYC = async () => {
        if (!investor) return alert("❌ Enter an investor address");

        try {
            const provider = new ethers.BrowserProvider(window.ethereum);
            const signer = await provider.getSigner();
            const contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer);

            const tx = await contract.verifyKYC(investor);
            await tx.wait();
            alert(`✅ KYC Verified for: ${investor}`);
        } catch (error) {
            console.error(error);
            alert("❌ KYC verification failed");
        }
    };

    /**
     * @dev Check if an investor is KYC verified
     */
    const checkKYCStatus = async () => {
        if (!investor) return alert("❌ Enter investor address");

        try {
            const provider = new ethers.BrowserProvider(window.ethereum);
            const contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, provider);

            const isVerified = await contract.isKYCVerified(investor);
            setKycStatus(isVerified ? "✅ Verified" : "❌ Not Verified");
        } catch (error) {
            console.error(error);
            alert("❌ Failed to check KYC status");
        }
    };

    /**
     * @dev Check the partition balance for a given artwork
     */
    const checkPartitionBalance = async () => {
        if (!investor || !artwork) return alert("❌ Enter both investor address and artwork name");

        try {
            const provider = new ethers.BrowserProvider(window.ethereum);
            const contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, provider);

            const balance = await contract.getPartitionBalance(investor, artwork);
            setPartitionBalance(`${artwork}: ${balance.toString()} tokens`);
        } catch (error) {
            console.error(error);
            alert("❌ Failed to fetch partition balance");
        }
    };

    /**
     * @dev Create a new artwork partition
     */
    const createPartition = async () => {
        if (!artwork || !amount || !investor) return alert("❌ Enter all details");

        try {
            const provider = new ethers.BrowserProvider(window.ethereum);
            const contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, provider);

            const isVerified = await contract.isKYCVerified(investor);
            if (!isVerified) return alert("❌ Error: Investor is not KYC verified");

            const signer = await provider.getSigner();
            const contractWithSigner = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer);

            const tx = await contractWithSigner.createPartition(artwork, amount, investor);
            await tx.wait();
            alert(`✅ Partition Created: ${artwork} with ${amount} tokens`);
        } catch (error) {
            console.error(error);
            alert("❌ Failed to create partition");
        }
    };

    /**
     * @dev Burn tokens if 100% owned
     */
    const burnTokens = async () => {
        if (!artwork || !investor) return alert("❌ Enter artwork and investor address");

        try {
            const provider = new ethers.BrowserProvider(window.ethereum);
            const contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, provider);

            const balance = await contract.getPartitionBalance(investor, artwork);
            const allArtworks = await contract.getAllArtworks();

            if (!allArtworks.includes(artwork)) return alert("❌ Error: Artwork does not exist");
            if (balance.toString() === "0") return alert("❌ Error: Investor does not own this artwork");

            const signer = await provider.getSigner();
            const contractWithSigner = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer);

            const tx = await contractWithSigner.burnArtworkTokensFrom(investor, artwork);
            await tx.wait();
            alert(`🔥 Burned all tokens for ${artwork} owned by ${investor}`);
        } catch (error) {
            console.error(error);
            alert("❌ Token burning failed");
        }
    };

    /**
     * @dev Fetch all artwork partitions
     */
    const getAllArtworks = async () => {
        try {
            const provider = new ethers.BrowserProvider(window.ethereum);
            const contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, provider);

            const artworks = await contract.getAllArtworks();
            if (artworks.length === 0) return alert("❌ No artworks found");

            setAllArtworks(artworks);
        } catch (error) {
            console.error("❌ Failed to fetch artworks", error);
            alert("❌ Failed to fetch artworks");
        }
    };

    return (
        <div className="container">
            <h2>Admin Actions</h2>

            {/* ✅ Verify KYC Section */}
            <div className="action-group">
                <h3>Verify KYC</h3>
                <input type="text" placeholder="Enter Investor Address" value={investor} onChange={(e) => setInvestor(e.target.value)} />
                <button onClick={verifyKYC}>Verify KYC</button>
            </div>

            {/* ✅ Check KYC Status */}
            <div className="action-group">
                <h3>Check KYC Status</h3>
                <input type="text" placeholder="Enter Investor Address" value={investor} onChange={(e) => setInvestor(e.target.value)} />
                <button onClick={checkKYCStatus}>Check KYC</button>
                <p className={`alert ${kycStatus.includes("✅") ? "success" : "error"}`}><strong>KYC Status:</strong> {kycStatus}</p>
            </div>

            {/* ✅ Create Artwork Partition */}
            <div className="action-group">
                <h3>Create Artwork Partition</h3>
                <input type="text" placeholder="Investor Address" value={investor} onChange={(e) => setInvestor(e.target.value)} />
                <input type="text" placeholder="Artwork Name" value={artwork} onChange={(e) => setArtwork(e.target.value)} />
                <input type="number" placeholder="Token Amount" value={amount} onChange={(e) => setAmount(e.target.value)} />
                <button onClick={createPartition}>Create Partition</button>
            </div>

            {/* ✅ Check Partition Balance */}
            <div className="action-group">
                <h3>Check Partition Balance</h3>
                <input type="text" placeholder="Investor Address" value={investor} onChange={(e) => setInvestor(e.target.value)} />
                <input type="text" placeholder="Artwork Name" value={artwork} onChange={(e) => setArtwork(e.target.value)} />
                <button onClick={checkPartitionBalance}>Check Balance</button>
                <p><strong>Partition Balance:</strong> {partitionBalance}</p>
            </div>

            {/* ✅ Burn Tokens */}
            <div className="action-group">
                <h3>Burn Tokens (Only if 100% owned)</h3>
                <input type="text" placeholder="Investor Address" value={investor} onChange={(e) => setInvestor(e.target.value)} />
                <input type="text" placeholder="Artwork Name" value={artwork} onChange={(e) => setArtwork(e.target.value)} />
                <button onClick={burnTokens}>Burn Tokens</button>
            </div>

            {/* ✅ Get All Artworks */}
            <div className="action-group">
                <h3>All Artwork Partitions</h3>
                <button onClick={getAllArtworks}>Get All Artworks</button>
                <ul>
                    {allArtworks.length === 0 ? <p className="alert error">❌ No artworks found</p> : allArtworks.map((art, index) => (
                        <li key={index}>🎨 {art}</li>
                    ))}
                </ul>
            </div>
        </div>
    );

};

export default AdminActions;
