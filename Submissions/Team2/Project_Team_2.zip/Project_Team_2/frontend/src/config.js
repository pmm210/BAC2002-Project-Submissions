import abi from "./contracts/ERC1400Token.json";

export const CONTRACT_ADDRESS = process.env.REACT_APP_CONTRACT_ADDRESS;
export const CONTRACT_ABI = abi.abi;