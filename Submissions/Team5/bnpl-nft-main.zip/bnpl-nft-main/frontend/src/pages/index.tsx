import React, { useEffect, useState, useCallback } from 'react';
import { useApp } from '@/context/AppContext';
import { NFTGrid } from '@/components/nft/NFTGrid';
import { PaymentModal } from '@/components/shared/PaymentModal';
import { TransactionModal } from '@/components/shared/TransactionModal';
import { useWallet } from '@/hooks/useWallet';
import useContracts, { getNFTStandard, LoanCreationParams } from '@/hooks/useContracts';
import { NFTListing, PaymentSchedule, Transaction } from '@/types';
import { Address, PublicClient } from 'viem';
import { usePublicClient } from 'wagmi';

export default function Marketplace() {
  const {
    listings,
    addTransaction,
    updateTransaction,
    addNotification,
    setLoading,
    setError,
    dispatch,
  } = useApp();
  const { isConnected, address } = useWallet();
  const publicClient = usePublicClient();

  useEffect(() => {
    console.log("Currently connected wallet:", address);
  }, [address]);
  

  const { 
    createLoan, 
    createLoanForEscrow,
    getActiveListings, 
    getListing,
    checkEscrowHasLoan,
    checkERC1155Balance,
    checkERC721Owner 
  } = useContracts();

  const [selectedListing, setSelectedListing] = React.useState<NFTListing | null>(null);
  const [selectedSchedule, setSelectedSchedule] = React.useState<PaymentSchedule | null>(null);
  const [showPaymentModal, setShowPaymentModal] = React.useState(false);
  const [showTransactionModal, setShowTransactionModal] = React.useState(false);
  const [currentTransaction, setCurrentTransaction] = React.useState<Transaction | null>(null);

  const [marketplaceListings, setMarketplaceListings] = useState<NFTListing[]>([]);
  const [lastFetchTime, setLastFetchTime] = useState<number>(0);

  const loadListings = useCallback(async () => {
    try {
      setLoading(true);
      
      const activeListings = await getActiveListings(0, 10);
      console.log('Raw active listings from getActiveListings:', activeListings);
      
      // Array to hold filtered listings that haven't been purchased yet
      const availableListings: NFTListing[] = [];
      
      // Process each listing and check if it has an associated loan
      for (const listing of activeListings) {
        try {
          // Check if this escrow has a loan already
          const hasLoan = await checkEscrowHasLoan(listing.loanId);
          console.log(`Listing ${listing.loanId}: Has loan = ${hasLoan}`);
          
          // Skip listings that already have a loan (already purchased)
          if (hasLoan) {
            console.log(`Skipping listing ${listing.loanId} as it already has an associated loan`);
            continue;
          }
          
          // This listing is still available, format and add it
          const allowedFrequencies = listing.metadata.allowedFrequencies || [];
          
          availableListings.push({
            id: listing.loanId.toString(),
            nft: {
              contractAddress: listing.nftContract,
              tokenId: listing.tokenId,
              standard: listing.standard === 0 ? 'ERC721' : 'ERC1155',
              title: listing.metadata.title || `NFT #${listing.tokenId.toString()}`,
              description: listing.metadata.description || '',
              image: listing.metadata.nft.image || '',
              collection: listing.metadata.nft.collection,
              owner: listing.seller
            },
            totalPrice: BigInt(listing.metadata.totalPrice),
            allowedDurations: listing.metadata.allowedDurations,
            allowedFrequencies: allowedFrequencies as ("weekly" | "bi-weekly" | "monthly")[],
            penaltyRate: listing.metadata.penaltyRate,
            listingDuration: listing.metadata.listingDuration,
            createdAt: new Date(listing.metadata.createdAt),
            status: listing.metadata.status || 'available',
            seller: listing.seller,
            active: true,
            isCompleted: false,
            isDelisted: false,
            viewCount: 0,
            metadataURI: listing.metadataURI
          });
        } catch (err) {
          console.error(`Error processing listing ${listing.loanId}:`, err);
          // Continue with next listing if there's an error with this one
        }
      }
      
      setMarketplaceListings(availableListings);
      console.debug('Loaded available listings:', availableListings.map(l => l.id));
      
    } catch (err) {
      console.error('Error loading marketplace listings:', err);
      setError(err instanceof Error ? err.message : 'Failed to load listings');
    } finally {
      setLoading(false);
    }
  }, [getActiveListings, checkEscrowHasLoan, setError, setLoading, setMarketplaceListings]);

  useEffect(() => {
    const abortController = new AbortController();
    let timeoutId: NodeJS.Timeout;

    const fetchData = async () => {
      if (!isConnected) return;

      const now = Date.now();
      if (now - lastFetchTime < 5000) return;

      timeoutId = setTimeout(async () => {
        if (abortController.signal.aborted) return;
        try {
          await loadListings();
          setLastFetchTime(Date.now());
        } catch (err) {
          if (!abortController.signal.aborted) {
            setError(err instanceof Error ? err.message : 'Failed to load listings');
          }
        }
      }, 1000);
    };

    fetchData();
    return () => {
      clearTimeout(timeoutId);
      abortController.abort();
    };
  }, [isConnected, loadListings, setLoading, lastFetchTime]);

  const handleBuy = async (listing: NFTListing, schedule: PaymentSchedule) => {
    if (!isConnected) {
      addNotification({
        id: Date.now().toString(),
        type: 'error',
        title: 'Wallet Not Connected',
        message: 'Please connect your wallet to purchase NFTs.',
        autoHide: true,
        timestamp: new Date(),
      });
      return;
    }
  
    try {
      console.log('Starting buy process for listing:', listing);
      await loadListings(); // Refresh listings before validation
      const listingExists = await validateListingInEscrow(listing);
      console.log('Listing exists result:', listingExists);
      
      if (!listingExists) {
        throw new Error("This NFT is not available for purchase");
      }
  
      setSelectedListing(listing);
      setSelectedSchedule(schedule);
      setShowPaymentModal(true);
    } catch (err: any) {
      console.error('Listing verification error:', err);
      addNotification({
        id: Date.now().toString(),
        type: 'error',
        title: 'Cannot Purchase NFT',
        message: err.message || 'Failed to verify NFT listing',
        autoHide: true,
        timestamp: new Date(),
      });
    }
  };

  const validateListingInEscrow = async (listing: NFTListing) => {
    console.log('Entering validateListingInEscrow for listing ID:', listing.id);
    try {
      console.log('Validating listing:', { id: listing.id });
      const escrowDetails = await getListing(BigInt(listing.id));
      console.log('Escrow details:', escrowDetails);
      
      if (!escrowDetails) {
        console.log('Listing validation failed: No escrow details found');
        return false;
      }
      if (!escrowDetails.isActive) {
        console.log('Listing validation failed: Escrow not active');
        return false;
      }
      
      const hasLoan = await checkEscrowHasLoan(BigInt(listing.id));
      console.log('Has loan check:', hasLoan);
      if (hasLoan) {
        console.log('Listing validation failed: Escrow already has a loan');
        return false;
      }
      
      console.log('Listing validated successfully');
      return true;
    } catch (err) {
      console.error("Error validating listing:", err);
      return false;
    }
  };

  const handlePaymentSubmit = async (amount: bigint) => {
    let modalTimeout;
    
    try {
      setShowPaymentModal(false);
      
      if (!selectedListing || !selectedSchedule || !address) {
        throw new Error('Missing required information for purchase');
      }
  
      console.group('Wallet Validation');
      console.log('Connected Wallet:', address);
      console.log('Seller Wallet:', selectedListing.seller);
      console.log('Same Wallet:', address.toLowerCase() === selectedListing.seller.toLowerCase());
      console.groupEnd();
  
      // Validate wallet connection
      if (!window.ethereum?.isConnected?.()) {
        throw new Error('Wallet provider not connected');
      }
  
      if (!window.ethereum?.selectedAddress) {
        throw new Error('No wallet account selected');
      }
  
      if (window.ethereum.selectedAddress.toLowerCase() !== address.toLowerCase()) {
        throw new Error('Connected wallet does not match selected account');
      }
  
      console.debug('Purchase validation:', {
        selectedListing: !!selectedListing,
        selectedSchedule: !!selectedSchedule,
        address,
        amount: amount.toString()
      });
  
      // Validate addresses
      if (!/^0x[a-fA-F0-9]{40}$/.test(address)) {
        console.error('Invalid buyer address:', address);
        throw new Error('Invalid buyer wallet address');
      }
      if (!/^0x[a-fA-F0-9]{40}$/.test(selectedListing.seller)) {
        console.error('Invalid seller address:', selectedListing.seller);
        throw new Error('Invalid seller address in NFT listing');
      }
  
      if (address.toLowerCase() === selectedListing.seller.toLowerCase()) {
        console.error('Buyer and seller addresses match:', address);
        throw new Error('You cannot purchase your own listing');
      }
  
      // Verify listing is still active and available
      const isActive = await validateListingInEscrow(selectedListing);
      if (!isActive) {
        throw new Error('This NFT is no longer available for purchase');
      }
  
      // Calculate the initial payment that will be sent
      const INITIAL_PAYMENT_NUMERATOR = BigInt(3333);
      const INITIAL_PAYMENT_DENOMINATOR = BigInt(10000);
      const initialPayment = (selectedListing.totalPrice * INITIAL_PAYMENT_NUMERATOR) / INITIAL_PAYMENT_DENOMINATOR;
  
      // Verify buyer has sufficient funds
      if (publicClient) {
        const buyerBalance = await publicClient.getBalance({ address });
        
        console.debug('Payment verification:', {
          escrowId: selectedListing.id,
          totalPrice: selectedListing.totalPrice.toString(),
          penaltyRate: selectedListing.penaltyRate,
          initialPayment: initialPayment.toString(),
          buyerBalance: buyerBalance.toString(),
          hasSufficientFunds: buyerBalance >= initialPayment
        });
  
        if (buyerBalance < initialPayment) {
          throw new Error(`Insufficient funds: Need ${initialPayment.toString()} wei but only have ${buyerBalance.toString()}`);
        }
      }
  
      const transaction: Transaction = {
        hash: '',
        type: 'buy',
        status: 'pending',
        timestamp: new Date(),
        data: {
          nft: selectedListing.nft,
          amount,
          schedule: selectedSchedule,
        },
      };
  
      console.debug('Creating transaction record:', transaction);
      addTransaction(transaction);
      setCurrentTransaction(transaction);
      setShowTransactionModal(true);
  
      // Set a timeout to auto-close the modal if it takes too long
      modalTimeout = setTimeout(() => {
        if (showTransactionModal) {
          setShowTransactionModal(false);
          addNotification({
            id: Date.now().toString(),
            type: 'info',
            title: 'Transaction Processing',
            message: 'Your transaction has been submitted and is processing. Check your wallet for confirmation.',
            autoHide: true,
            timestamp: new Date(),
          });
        }
      }, 30000); // 30 seconds timeout
  
      console.debug('Attempting to create loan for escrow...', {
        escrowId: selectedListing.id,
        totalPrice: selectedListing.totalPrice.toString(),
        penaltyRate: selectedListing.penaltyRate,
        initialPayment: initialPayment.toString()
      });
  
      try {
        // Pre-validate escrow state
        const hasLoan = await checkEscrowHasLoan(BigInt(selectedListing.id));
        console.debug('Escrow has loan check:', hasLoan);
        if (hasLoan) {
          throw new Error('This NFT has already been purchased');
        }
  
        // Perform the transaction
        const tx = await createLoanForEscrow(
          BigInt(selectedListing.id),
          selectedListing.totalPrice,
          selectedListing.penaltyRate
        );
        
        clearTimeout(modalTimeout);
        
        console.debug('Transaction sent with hash:', tx.transactionHash);
  
        // Update transaction with hash
        updateTransaction({
          ...transaction,
          hash: tx.transactionHash,
          status: 'success',
          timestamp: new Date(),
        });
  
        addNotification({
          id: Date.now().toString(),
          type: 'success',
          title: 'Purchase Submitted',
          message: 'Your purchase has been submitted to the blockchain!',
          autoHide: true,
          timestamp: new Date(),
        });
        
        setShowTransactionModal(false);
        
        // Refresh listings after a short delay to allow transaction to be processed
        setTimeout(() => loadListings(), 5000);
        
      } catch (contractErr: any) {
        clearTimeout(modalTimeout);
        
        console.error('Contract interaction error:', {
          message: contractErr.message,
          data: contractErr.data,
          details: contractErr.details,
          reason: contractErr.reason || (contractErr.data && contractErr.data.message) || 'Unknown reason'
        });
        
        // Handle specific contract errors
        if (contractErr.message.includes('Escrow not active')) {
          throw new Error('This NFT is no longer available for purchase');
        } else if (contractErr.message.includes('Loan already exists')) {
          throw new Error('This NFT has already been purchased');
        } else if (contractErr.message.includes('insufficient funds')) {
          throw new Error('Insufficient funds for initial payment');
        } else if (contractErr.message.includes('Seller cannot be buyer') || 
                  contractErr.message.includes('cannot buy your own')) {
          throw new Error('You cannot purchase your own listing');
        } else {
          throw contractErr; // Re-throw for general handling
        }
      }
      
    } catch (err: any) {
      console.error('Purchase error in handlePaymentSubmit:', {
        message: err.message,
        stack: err.stack,
        rawError: err
      });
      
      let errorMessage = 'Failed to process payment';
      
      // Structured error message handling
      if (err?.message?.includes('same as seller') || 
          err?.message?.includes('cannot purchase your own') || 
          err?.message?.includes('Seller cannot be buyer')) {
        errorMessage = 'You cannot purchase your own NFT listing';
      } else if (err?.message?.includes('Buyer address cannot be empty')) {
        errorMessage = 'Please connect your wallet to purchase';
      } else if (err?.message?.includes('insufficient funds') || 
                err?.message?.includes('Insufficient funds')) {
        errorMessage = 'You do not have enough ETH to make this purchase';
      } else if (err?.message?.includes('already been purchased') ||
                err?.message?.includes('Loan already exists')) {
        errorMessage = 'This NFT has already been purchased by someone else';
      } else if (err?.message?.includes('no longer available')) {
        errorMessage = 'This NFT is no longer available for purchase';
      } else if (err?.message) {
        errorMessage = err.message;
      }
      
      if (currentTransaction) {
        updateTransaction({
          ...currentTransaction,
          status: 'failed',
          error: errorMessage
        });
      }
  
      setError(errorMessage);
      
      addNotification({
        id: Date.now().toString(),
        type: 'error',
        title: 'Purchase Failed',
        message: errorMessage,
        autoHide: true,
        timestamp: new Date(),
      });
  
      setShowPaymentModal(false);
      setShowTransactionModal(false);
    } finally {
      // Cleanup timeout
      if (modalTimeout) clearTimeout(modalTimeout);
      
      // Ensure modals are properly closed if there's an unexpected error
      if (showPaymentModal) setShowPaymentModal(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">NFT Marketplace</h1>
          <p className="mt-1 text-sm text-gray-500">
            Browse and buy NFTs with flexible payment plans
          </p>
        </div>
      </div>

      <NFTGrid
        listings={marketplaceListings}
        onBuy={handleBuy}
      />

      {selectedListing && showPaymentModal && (
        <PaymentModal
          loan={{
            id: BigInt(0),
            nft: selectedListing.nft,
            seller: selectedListing.seller,
            buyer: address!,
            schedule: selectedSchedule!,
            remainingBalance: selectedListing.totalPrice,
            nextPaymentDue: new Date(),
            status: 'active',
            totalPenalties: BigInt(0),
            missedPayments: 0,
            escrowBalance: BigInt(0)
          }}
          isOpen={showPaymentModal}
          onClose={() => setShowPaymentModal(false)}
          onSubmit={handlePaymentSubmit}
        />
      )}

      {currentTransaction && showTransactionModal && (
        <TransactionModal
          transaction={currentTransaction}
          isOpen={showTransactionModal}
          onClose={() => {
            setShowTransactionModal(false);
            setCurrentTransaction(null);
          }}
        />
      )}
    </div>
  );
}