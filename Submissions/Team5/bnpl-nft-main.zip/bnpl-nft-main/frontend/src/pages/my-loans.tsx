import React, { useEffect, useState, useCallback, useRef } from 'react';
import { Transaction } from '../types';
import { useApp } from '@/context/AppContext';
import { LoanList } from '@/components/loan/LoanList';
import { PaymentModal } from '@/components/shared/PaymentModal';
import { TransactionModal } from '@/components/shared/TransactionModal';
import { useWallet } from '@/hooks/useWallet';
import useContracts, { LoanStatus } from '@/hooks/useContracts';
import { Loan } from '@/types';
import { getContract } from 'viem';
import { usePublicClient, useWalletClient } from 'wagmi';
import LoanManagerABI from '../abis/LoanManager.json'; 
import { CONTRACTS } from '../config/constants'; 


export default function MyLoans() {

  // Add these hooks to your component
  const publicClient = usePublicClient();
  const { data: walletClient } = useWalletClient();
  // Memoize the contract hooks to prevent re-renders
  const {
    loans,
    addTransaction,
    updateTransaction,
    addNotification,
    setLoading: appSetLoading,
    setError: appSetError,
    dispatch,
  } = useApp();
  
  const { isConnected, address } = useWallet();
  const contractsRef = useRef(useContracts());

  
  // Keep refs to contract functions to prevent dependency changes
  const { makePayment, getLoan, calculatePenalty, loanManager } = contractsRef.current;

  // Local component state
  const [selectedLoan, setSelectedLoan] = useState<Loan | null>(null);
  const [isEarlyPayoff, setIsEarlyPayoff] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showTransactionModal, setShowTransactionModal] = useState(false);
  const [currentTransaction, setCurrentTransaction] = useState<Transaction | null>(null);
  const [userLoans, setUserLoans] = useState<Loan[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  
  // Use refs for values that shouldn't trigger re-renders
  const isInitialLoadDoneRef = useRef(false);
  const lastFetchTimeRef = useRef(0);
  const isLoadingRef = useRef(false);
  const loansLoadedRef = useRef(false);

  // Track component mounted state to prevent updates after unmount
  const isMountedRef = useRef(true);
  
  // Function to fetch loans associated with the connected wallet
const loadLoans = useCallback(async () => {
  // Check preconditions
  if (!isConnected || !address || isLoadingRef.current) {
    return;
  }

  // Debounce frequent calls
  const now = Date.now();
  if (now - lastFetchTimeRef.current < 15000) { // 15 second minimum between fetches
    console.log('Debouncing loan fetch - too recent');
    return;
  }
  
  // Mark as loading
  isLoadingRef.current = true;
  setIsLoading(true);
  appSetLoading(true);
  
  try {
    console.log('Fetching loans for wallet (as buyer):', address);
    
    // Array to hold fetched loans
    const fetchedLoans: Loan[] = [];
    
    // Get the NFTEscrow contract instance
    const { nftEscrow } = contractsRef.current;
    if (!nftEscrow) {
      throw new Error("NFT Escrow contract not initialized");
    }
    
    // Get highest escrow ID from NFTEscrow contract
    const escrowCount = await nftEscrow.read.escrowCount() as bigint;
    console.log('Total escrows in system:', escrowCount.toString());
    
    if (escrowCount === BigInt(0)) {
      console.log('No escrows in the system yet');
      if (isMountedRef.current) {
        setUserLoans([]);
        dispatch({ type: 'SET_LOANS', payload: [] });
        loansLoadedRef.current = true;
        isInitialLoadDoneRef.current = true;
      }
      return;
    }
    
    // Check if each escrow has a loan for the current user
    const checkPromises = [];
    
    // Limit to reasonable number
    const maxEscrowsToCheck = Math.min(Number(escrowCount), 100);
    console.log(`Will check up to ${maxEscrowsToCheck} escrows for loans...`);
    
    for (let i = 1; i <= maxEscrowsToCheck; i++) {
      const escrowId = BigInt(i);
      checkPromises.push(
        (async () => {
          try {
            if (!isMountedRef.current) return null;
            
            // First check if escrow has a loan (using loanManager from your existing code)
            const hasLoan = await contractsRef.current.checkEscrowHasLoan(escrowId);
            if (!hasLoan) {
              // Skip escrows without loans
              return null;
            }
            
            console.log(`Escrow ${escrowId.toString()} has a loan, checking details...`);
            
            // If it has a loan, get the loan details
            const loanData = await contractsRef.current.getLoan(escrowId);

            // Add detailed logging about buyer addresses
            console.log(`Loan details for escrow ${escrowId.toString()}:`, {
              buyer: loanData.buyer || 'UNDEFINED',
              currentWallet: address,
              hasValidBuyer: !!loanData.buyer
            });
            
            // Skip if loan data is empty
            if (!loanData || !loanData.buyer) {
              return null;
            }
            
            // Check if current wallet is the buyer of this loan
            if (loanData.buyer.toLowerCase() !== address.toLowerCase()) {
              console.log(`Loan for escrow ${escrowId.toString()} belongs to a different buyer: ${loanData.buyer}`);
              return null;
            }
            
            console.log(`Found loan for escrow #${escrowId.toString()} for current user as buyer`, loanData);
            
            // Get the listing metadata from escrow
            let nftImage = '';
            let nftTitle = `NFT #${loanData.tokenId.toString()}`;
            let nftDescription = '';
            let collectionName = 'Collection';
            let collectionSymbol = 'SYM';

            try {
              // Get the escrow listing with metadata
              const escrowListing = await contractsRef.current.getListing(escrowId);
              if (escrowListing && escrowListing.metadata && escrowListing.metadata.nft) {
                nftImage = escrowListing.metadata.nft.image || '';
                nftTitle = escrowListing.metadata.nft.title || nftTitle;
                nftDescription = escrowListing.metadata.description || '';
                
                if (escrowListing.metadata.nft.collection) {
                  collectionName = escrowListing.metadata.nft.collection.name || collectionName;
                  collectionSymbol = escrowListing.metadata.nft.collection.symbol || collectionSymbol;
                }
                
                console.log(`Loaded metadata for NFT: ${nftTitle}, image: ${nftImage}`);
              }
            } catch (metadataError) {
              console.error(`Error loading metadata for escrow ${escrowId}:`, metadataError);
              // Continue with default values if metadata load fails
            }
            
            // Process current penalty
            const currentPenalty = await contractsRef.current.calculatePenalty(escrowId);
            
            // Format loan for display
            return {
              id: escrowId,
              nft: {
                contractAddress: loanData.nftContract,
                tokenId: loanData.tokenId,
                standard: loanData.standard === 0 ? 'ERC721' as const : 'ERC1155' as const,
                title: nftTitle,
                description: nftDescription,
                image: nftImage || `https://via.placeholder.com/400x400?text=NFT+${loanData.tokenId.toString()}`,
                collection: { 
                  name: collectionName, 
                  symbol: collectionSymbol 
                },
                owner: loanData.seller
              },
              seller: loanData.seller,
              buyer: loanData.buyer,
              schedule: {
                frequency: 'monthly' as const,
                duration: 30,
                totalPrice: loanData.totalPrice,
                initialPayment: BigInt(loanData.totalPrice) - BigInt(loanData.remainingBalance),
                installmentAmount: loanData.installmentAmount,
                penaltyRate: Number(loanData.penaltyPercentage)
              },
              remainingBalance: loanData.remainingBalance,
              nextPaymentDue: new Date(Number(loanData.nextPaymentDue) * 1000),
              status: loanData.status === 0 ? 'active' as const : 
                     loanData.status === 1 ? 'completed' as const : 'defaulted' as const,
              totalPenalties: loanData.totalPenalties,
              missedPayments: loanData.missedPayments,
              escrowBalance: BigInt(0)
            };
          } catch (loanError) {
            console.error(`Error checking loan for escrow ${i}:`, loanError);
            return null;
          }
        })()
      );
    }
    
    // Use Promise.allSettled for robustness
    const results = await Promise.allSettled(checkPromises);
    
    // Filter successful results and remove nulls
    results.forEach(result => {
      if (result.status === 'fulfilled' && result.value) {
        fetchedLoans.push(result.value);
      }
    });
    
    console.log(`Found ${fetchedLoans.length} loans for user ${address}`);
    
    // Update state only if component is still mounted
    if (isMountedRef.current) {
      setUserLoans(fetchedLoans);
      dispatch({ type: 'SET_LOANS', payload: fetchedLoans });
      
      // Mark as loaded
      loansLoadedRef.current = true;
      isInitialLoadDoneRef.current = true;
    }
  } catch (err) {
    console.error('Error loading loans:', err);
    if (isMountedRef.current) {
      appSetError(err instanceof Error ? err.message : 'Failed to load loans');
    }
  } finally {
    // Reset loading state if still mounted
    if (isMountedRef.current) {
      setIsLoading(false);
      appSetLoading(false);
      isLoadingRef.current = false;
      lastFetchTimeRef.current = Date.now();
    }
  }
}, [address, isConnected, dispatch, appSetError, appSetLoading]);

  // Initial load when component mounts & wallet connects
  useEffect(() => {
    if (isConnected && address && !isInitialLoadDoneRef.current) {
      // One-time load on initial connection
      loadLoans();
    }
  }, [isConnected, address, loadLoans]);

  // Set up single refresh timer when component mounts
  useEffect(() => {
    // Load loans on a fixed schedule, but only once loaded initially
    const timer = setInterval(() => {
      if (isConnected && 
          loansLoadedRef.current && 
          !isLoadingRef.current && 
          isMountedRef.current) {
        console.log('Periodic loan refresh triggered');
        loadLoans();
      }
    }, 60000); // Check every 60 seconds
    
    // Cleanup function
    return () => {
      clearInterval(timer);
      isMountedRef.current = false;
    };
  }, []); // Empty dependency array - only run once on mount

  const handleMakePayment = (loan: Loan) => {
    setSelectedLoan(loan);
    setIsEarlyPayoff(false);
    setShowPaymentModal(true);
  };

  const handlePayoffEarly = (loan: Loan) => {
    setSelectedLoan(loan);
    setIsEarlyPayoff(true);
    setShowPaymentModal(true);
  };

  const handlePaymentSubmit = async (amount: bigint) => {
    try {
      setShowPaymentModal(false);
      if (!selectedLoan) return;
  
      // Check for required dependencies
      if (!publicClient || !walletClient || !address) {
        addNotification({
          id: Date.now().toString(),
          type: 'error',
          title: 'Connection Issue',
          message: 'Please make sure your wallet is connected',
          autoHide: true,
          timestamp: new Date(),
        });
        return;
      }
  
      // Create transaction record
      const transaction: Transaction = {
        hash: '',
        type: 'payment',
        status: 'pending',
        timestamp: new Date(),
        data: {
          nft: selectedLoan.nft,
          loan: selectedLoan,
          amount,
        },
      };
  
      addTransaction(transaction);
      setCurrentTransaction(transaction);
      setShowTransactionModal(true);
  
      // Get contract address
      const chainId = walletClient.chain.id;
      const loanManagerAddress = CONTRACTS[chainId]?.LOAN_MANAGER;
      
      if (!loanManagerAddress) {
        throw new Error(`Contract not configured for chain ID ${chainId}`);
      }
  
      console.log('Preparing direct contract call with:', {
        loanId: selectedLoan.id.toString(),
        amount: amount.toString(),
        contractAddress: loanManagerAddress
      });
  
      // Simulate the transaction first to catch potential errors
      const { request } = await publicClient.simulateContract({
        address: loanManagerAddress,
        abi: LoanManagerABI,
        functionName: 'makePayment',
        args: [selectedLoan.id],
        value: amount,
        account: walletClient.account
      });
  
      // Send the transaction
      const hash = await walletClient.writeContract(request);
      console.log('Payment transaction sent with hash:', hash);
  
      // Wait for receipt
      const receipt = await publicClient.waitForTransactionReceipt({ hash });
      console.log('Payment transaction completed:', receipt);
  
      // Update transaction status
      updateTransaction({
        ...transaction,
        hash,
        status: 'success',
        timestamp: new Date(),
      });
  
      // Add success notification
      addNotification({
        id: Date.now().toString(),
        type: 'success',
        title: 'Payment Successful',
        message:
          amount >= selectedLoan.remainingBalance
            ? 'Your loan has been fully paid off!'
            : 'Your payment was processed successfully!',
        autoHide: true,
        timestamp: new Date(),
      });
  
      // Refresh loans after payment
      lastFetchTimeRef.current = 0; // Reset fetch time to force refresh
      setTimeout(() => loadLoans(), 5000);
    } catch (err) {
      console.error('Payment error:', err);
      
      if (currentTransaction) {
        updateTransaction({
          ...currentTransaction,
          status: 'failed',
          error: err instanceof Error ? err.message : 'Unknown error'
        });
      }
  
      appSetError(err instanceof Error ? err.message : 'Failed to process payment');
  
      addNotification({
        id: Date.now().toString(),
        type: 'error',
        title: 'Payment Failed',
        message: err instanceof Error ? err.message : 'Failed to process payment',
        autoHide: true,
        timestamp: new Date(),
      });
    } finally {
      setShowTransactionModal(false);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">My Loans</h1>
        <p className="mt-1 text-sm text-gray-500">
          Manage your active loans and payment schedules
        </p>
      </div>

      {isConnected ? (
        isLoading && !isInitialLoadDoneRef.current ? (
          <div className="text-center py-8">
            <p className="text-gray-500">Loading your loans...</p>
          </div>
        ) : userLoans.length > 0 ? (
          <LoanList loans={userLoans} onMakePayment={handleMakePayment} onPayoffEarly={handlePayoffEarly} />
        ) : (
          <div className="text-center py-8">
            <p className="text-gray-500">You don't have any active loans.</p>
            <p className="text-sm text-gray-400 mt-2">Visit the marketplace to browse NFTs available for purchase.</p>
          </div>
        )
      ) : (
        <div className="text-center py-8">
          <p className="text-gray-500">Connect your wallet to view your loans.</p>
        </div>
      )}

      {selectedLoan && showPaymentModal && (
        <PaymentModal
          loan={selectedLoan}
          isOpen={showPaymentModal}
          onClose={() => setShowPaymentModal(false)}
          onSubmit={handlePaymentSubmit}
          isEarlyPayoff={isEarlyPayoff}
        />
      )}

      {currentTransaction && showTransactionModal && (
        <TransactionModal
          transaction={currentTransaction}
          isOpen={showTransactionModal}
          onClose={() => {
            setShowTransactionModal(false);
            setCurrentTransaction(null);
          }}
        />
      )}
    </div>
  );
}