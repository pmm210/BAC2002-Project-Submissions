import { AppProps } from 'next/app';
import { WagmiProvider, createConfig, http } from 'wagmi';
import { arbitrumSepolia, sepolia } from 'wagmi/chains';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { injected } from 'wagmi/connectors';
import { AppProvider } from '../context/AppContext';
import { State, serialize, deserialize } from 'wagmi';
import { WalletProvider } from '../providers/WalletProvider';
import { Layout } from '../components/layout/Layout';
import '../styles/globals.css';

const config = createConfig({
  chains: [arbitrumSepolia, sepolia],  
  transports: {
    [arbitrumSepolia.id]: http('https://arbitrum-sepolia.infura.io/v3/84972b43321a4dfabe95067738bbdf2e'),
    [sepolia.id]: http('https://sepolia.infura.io/v3/84972b43321a4dfabe95067738bbdf2e'), 
  },
  connectors: [
    injected()
  ],
});

const queryClient = new QueryClient();

export default function App({ Component, pageProps }: AppProps) {
  return (
    <WagmiProvider config={config}>
      <QueryClientProvider client={queryClient}>
        <WalletProvider>
          <AppProvider>
            <Layout>
              <Component {...pageProps} />
            </Layout>
          </AppProvider>
        </WalletProvider>
      </QueryClientProvider>
    </WagmiProvider>
  );
}