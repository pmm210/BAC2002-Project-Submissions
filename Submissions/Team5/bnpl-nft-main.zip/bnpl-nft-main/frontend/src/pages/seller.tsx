import React, { useEffect, useState, useCallback } from 'react';
import { useApp } from '@/context/AppContext';
import { NFT, NFTListing, Transaction } from '@/types';
import { parseEther, type Address } from 'viem';
import { useWallet } from '@/hooks/useWallet';
import useNFTs from '@/hooks/useNFTs';
import useContracts, { Listing, ListingMetadata } from '@/hooks/useContracts';
import { PAYMENT_SCHEDULE } from '@/config/constants';
import { DashboardOverview } from '@/components/seller/DashboardOverview';
import { NFTSelector } from '@/components/seller/NFTSelector';
import { ListingForm } from '@/components/seller/ListingForm';
import { ListingManager } from '@/components/seller/ListingManager';
import { TransactionModal } from '@/components/shared/TransactionModal';
import { CompletedListings } from '@/components/seller/CompletedListings';
import { WithdrawFunds } from '@/components/seller/WithdrawFunds';

type DashboardView = 'overview' | 'create' | 'select-nft' | 'manage' | 'history' | 'withdraw';

export default function SellerDashboard() {
  const {
    listings,
    addTransaction,
    updateTransaction,
    addNotification,
    isLoading,
    setLoading,
    setError,
  } = useApp();
  const { isConnected, address } = useWallet();
  const [currentView, setCurrentView] = useState<DashboardView>('overview');
  const { nfts: walletNFTs, isLoading: isLoadingNFTs, refetch: refetchNFTs } = useNFTs(address, {
    enabled: currentView === 'select-nft',
    debug: true
  });
  const { 
    depositNFTWithMetadata, 
    releaseNFT, 
    updateListingMetadata,
    getActiveListings
  } = useContracts();
  
  // Helper to safely serialize objects containing BigInt
  const safeStringify = (obj: any) => {
    return JSON.stringify(obj, (_, value) => 
      typeof value === 'bigint' ? value.toString() : value
    );
  };

  // Helper to parse JSON and convert stringified BigInts back to BigInt
  const safeParse = (json: string) => {
    return JSON.parse(json, (_, value) => {
      if (typeof value === 'string' && /^\d+n$/.test(value)) {
        return BigInt(value.slice(0, -1));
      }
      return value;
    });
  };

  const [selectedNFT, setSelectedNFT] = useState<NFT | null>(null);
  const [showTransactionModal, setShowTransactionModal] = useState(false);
  const [currentTransaction, setCurrentTransaction] = useState<any>(null);
  const [sellerListings, setSellerListings] = useState<NFTListing[]>([]);
  const [metrics, setMetrics] = useState({
    totalNFTsListed: 0,
    activeBNPL: 0,
    totalValueLocked: BigInt(0),
    earnedPenalties: BigInt(0),
    completedSales: 0,
    defaultedLoans: 0,
    averageDuration: 0,
    totalRevenue: BigInt(0),
  });
  const [lastFetchTime, setLastFetchTime] = useState<number>(0);

  const loadSellerData = useCallback(async () => {
    try {
      setLoading(true);
      
      // Get all active listings
      const activeListings = await getActiveListings(0, 20);
      
      // Filter for this seller's listings
      const filteredListings = activeListings.filter(
        listing => listing.seller.toLowerCase() === address?.toLowerCase()
      );
      
      // Add debug logs to help track issues
      console.log(`Found ${activeListings.length} total active listings`);
      console.log(`Found ${filteredListings.length} listings for this seller`);
      
      // Convert to NFTListing format and store them
      const formattedListings: NFTListing[] = filteredListings.map(listing => {
        // Helper function to validate frequency strings
        const mapFrequency = (freq: string): "weekly" | "bi-weekly" | "monthly" => {
          if (freq === "weekly" || freq === "bi-weekly" || freq === "monthly") {
            return freq as "weekly" | "bi-weekly" | "monthly";
          }
          // Default to weekly if invalid value
          return "weekly";
        };

        // Map allowed frequencies to valid values
        const validFrequencies = (listing.metadata.allowedFrequencies || [])
          .map(freq => mapFrequency(freq))
          .filter(freq => !!freq) as ("weekly" | "bi-weekly" | "monthly")[];

        return {
          id: listing.loanId.toString(),
          nft: {
            contractAddress: listing.nftContract,
            tokenId: listing.tokenId,
            standard: listing.standard === 0 ? 'ERC721' : 'ERC1155',
            title: listing.metadata.title || `NFT #${listing.tokenId.toString()}`,
            description: listing.metadata.description || '',
            image: listing.metadata.nft.image || '',
            collection: listing.metadata.nft.collection,
            owner: listing.seller
          },
          totalPrice: BigInt(listing.metadata.totalPrice),
          allowedDurations: listing.metadata.allowedDurations,
          allowedFrequencies: validFrequencies,  // Use the validated frequencies
          penaltyRate: listing.metadata.penaltyRate,
          listingDuration: listing.metadata.listingDuration,
          createdAt: new Date(listing.metadata.createdAt),
          status: listing.metadata.status || 'available',
          seller: listing.seller,
          active: true,
          isCompleted: false,
          isDelisted: false,
          viewCount: 0
        };
      });
      
      // Save the formatted listings to state
      setSellerListings(formattedListings);
      
      // Update metrics
      setMetrics(prev => ({
        ...prev,
        totalNFTsListed: filteredListings.length,
        activeBNPL: filteredListings.length,
        totalValueLocked: filteredListings.reduce(
          (sum, l) => sum + BigInt(l.metadata.totalPrice || '0'),
          BigInt(0)
        ),
        averageDuration: filteredListings.reduce(
          (sum, l) => sum + (l.metadata.listingDuration || 30), 0
        ) / (filteredListings.length || 1)
      }));
      
      console.log('Seller data loaded successfully:', {
        activeListings: formattedListings.length,
        totalValueLocked: filteredListings.reduce(
          (sum, l) => sum + BigInt(l.metadata.totalPrice || '0'),
          BigInt(0)
        ).toString()
      });
    } catch (err) {
      console.error('Error loading seller data:', err);
      setError(err instanceof Error ? err.message : 'Failed to load seller data');
    } finally {
      setLoading(false);
    }
  }, [address, getActiveListings, setError, setLoading]);

  useEffect(() => {
    const abortController = new AbortController();
    let timeoutId: NodeJS.Timeout;

    const fetchData = async () => {
      if (!isConnected || !address || isLoading) return;

      // Only fetch if at least 5 seconds have passed since last fetch
      const now = Date.now();
      if (now - lastFetchTime < 5000) return;

      timeoutId = setTimeout(async () => {
        if (abortController.signal.aborted) return;
        try {
          await loadSellerData();
          setLastFetchTime(Date.now());
        } catch (err) {
          if (!abortController.signal.aborted) {
            setError(err instanceof Error ? err.message : 'Failed to load seller data');
          }
        }
      }, 1000); // Additional 1-second delay
    };

    fetchData();
    return () => {
      clearTimeout(timeoutId);
      abortController.abort();
    };
  }, [isConnected, address, loadSellerData, isLoading, lastFetchTime, setError]);

  const handleCreateListing = () => {
    setCurrentView('select-nft');
  };

  const handleNFTSelect = (nft: NFT) => {
    if (!nft.contractAddress) {
      // This is a refresh action triggered by the refresh button
      refetchNFTs(true); // Force refresh by passing true
      return;
    }
    
    // Check if NFT is already listed
    const isAlreadyListed = sellerListings.some(listing => 
      listing.nft.contractAddress.toLowerCase() === nft.contractAddress.toLowerCase() && 
      listing.nft.tokenId.toString() === nft.tokenId.toString()
    );

    if (isAlreadyListed) {
      setError('This NFT is already listed');
      addNotification({
        id: Date.now().toString(),
        type: 'error',
        title: 'Already Listed',
        message: 'This NFT has already been listed',
        autoHide: true,
        timestamp: new Date(),
      });
      return;
    }

    // Serialize NFT with BigInt handling before storing in state
    const serialized = safeStringify(nft);
    setSelectedNFT(safeParse(serialized));
    setCurrentView('create');
  };

  const handleListingSubmit = async (formData: any) => {
    try {
      if (!selectedNFT || !address) {
        setError('Please connect your wallet and select an NFT');
        return;
      }
  
      if (selectedNFT.owner.toLowerCase() !== address.toLowerCase()) {
        setError('You can only list NFTs owned by your connected wallet');
        return;
      }
      
      const nft = {
        ...selectedNFT,
        tokenId: BigInt(selectedNFT.tokenId)
      };
  
      const transaction: Transaction = {
        hash: '',
        type: 'list' as const,
        status: 'pending',
        timestamp: new Date(),
        data: {
          nft: nft,
        },
      };
  
      addTransaction(transaction);
      setCurrentTransaction(transaction);
      setShowTransactionModal(true);
  
      const totalPrice = typeof formData.totalPrice === 'bigint' 
        ? formData.totalPrice 
        : parseEther(formData.totalPrice.toString() || '0');
  
      const metadata: ListingMetadata = {
        title: formData.title || `NFT #${selectedNFT.tokenId}`,
        description: formData.description || '',
        totalPrice: totalPrice.toString(),
        allowedDurations: formData.allowedDurations?.map(Number) || [3, 6, 12],
        allowedFrequencies: Array.isArray(formData.allowedFrequencies) 
          ? formData.allowedFrequencies.map(String) 
          : ['monthly'],
        penaltyRate: Number(formData.penaltyRate) || 5,
        listingDuration: Number(formData.listingDuration) || 30,
        seller: address || '',
        createdAt: new Date().toISOString(),
        status: 'available',
        nft: {
          contractAddress: selectedNFT.contractAddress,
          tokenId: selectedNFT.tokenId.toString(),
          standard: selectedNFT.standard,
          title: selectedNFT.title || `NFT #${selectedNFT.tokenId}`,
          image: selectedNFT.image || '',
          collection: selectedNFT.collection || {
            name: 'Unknown',
            symbol: 'UNK'
          }
        },
        buyerRequirements: {
          minEthBalance: (formData.buyerRequirements?.minEthBalance?.toString() || '0'),
          minTransactionCount: Number(formData.buyerRequirements?.minTransactionCount) || 0
        }
      };
  
      console.log('Depositing NFT with metadata:', JSON.stringify(metadata, null, 2));
      
      const { receipt, loanId, metadataURI } = await depositNFTWithMetadata(
        selectedNFT.contractAddress as Address,
        BigInt(selectedNFT.tokenId),
        address as Address,
        BigInt(1),
        selectedNFT.standard === 'ERC1155' ? 1 : 0,
        metadata
      );
      console.log('NFT deposited successfully with loanId:', loanId.toString(), 'metadataURI:', metadataURI);
      
      updateTransaction({
        ...transaction,
        hash: receipt.transactionHash,
        status: 'success',
        timestamp: new Date(),
        data: {
          ...transaction.data,
          listing: {
            loanId, // Keep as bigint
            metadataURI,
            totalPrice,
            allowedDurations: formData.allowedDurations,
            allowedFrequencies: Array.isArray(formData.allowedFrequencies) 
              ? formData.allowedFrequencies.map((freq: string) => PAYMENT_SCHEDULE.FREQUENCIES.indexOf(freq as any))
              : [],
            penaltyRate: formData.penaltyRate
          }
        }
      });
  
      addNotification({
        id: Date.now().toString(),
        type: 'success',
        title: 'Listing Created',
        message: 'Your NFT has been listed successfully!',
        autoHide: true,
        timestamp: new Date(),
      });
  
      await loadSellerData();
      setCurrentView('manage');
      setShowTransactionModal(false);
      setCurrentTransaction(null);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to create listing';
      
      updateTransaction({
        ...currentTransaction,
        status: 'failed',
        error: errorMessage
      });
  
      setError(errorMessage);
      
      addNotification({
        id: Date.now().toString(),
        type: 'error',
        title: 'Listing Failed',
        message: errorMessage,
        autoHide: true,
        timestamp: new Date(),
      });
      
      setShowTransactionModal(false);
      setCurrentTransaction(null);
    }
  };

  const handleDelistNFT = async (listing: NFTListing) => {
    try {
      if (!address) return;
      
      const transaction: Transaction = {
        hash: '',
        type: 'list' as const,
        status: 'pending',
        timestamp: new Date(),
        data: { nft: listing.nft },
      };

      addTransaction(transaction);
      setCurrentTransaction(transaction);
      setShowTransactionModal(true);

      // Release the NFT back to the seller (current user)
      const tx = await releaseNFT(BigInt(listing.id), address as Address);
      
      updateTransaction({
        ...transaction,
        hash: tx.transactionHash,
        status: 'success',
        timestamp: new Date(),
      });

      addNotification({
        id: Date.now().toString(),
        type: 'success',
        title: 'NFT Delisted',
        message: 'Your NFT has been delisted successfully!',
        autoHide: true,
        timestamp: new Date(),
      });
      
      // Refresh listings data
      await loadSellerData();
      // Also refresh wallet NFTs since the NFT is now back in your wallet
      await refetchNFTs();
      
      // Close the transaction modal
      setShowTransactionModal(false);
    } catch (err) {
      updateTransaction({
        ...currentTransaction,
        status: 'failed',
      });

      setError(err instanceof Error ? err.message : 'Failed to delist NFT');
      
      addNotification({
        id: Date.now().toString(),
        type: 'error',
        title: 'Delist Failed',
        message: err instanceof Error ? err.message : 'Failed to delist NFT',
        autoHide: true,
        timestamp: new Date(),
      });
    }
  };

  return (
    <div className="space-y-8">
      {/* Navigation Tabs */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          {[
            { id: 'overview', name: 'Overview' },
            { id: 'manage', name: 'Active Listings' },
            { id: 'history', name: 'Completed Sales' },
            { id: 'withdraw', name: 'Withdraw Funds' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setCurrentView(tab.id as DashboardView)}
              className={`
                whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm
                ${currentView === tab.id
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}
              `}
            >
              {tab.name}
            </button>
          ))}
        </nav>
      </div>

      {/* Main Content */}
      {currentView === 'overview' && (
        <DashboardOverview
          metrics={metrics}
          onCreateListing={handleCreateListing}
        />
      )}

      {currentView === 'select-nft' && (
        <div>
          <div className="mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Select NFT to List</h2>
            <p className="mt-1 text-sm text-gray-500">
              Choose an NFT from your wallet to create a BNPL listing
            </p>
          </div>
          <NFTSelector
            nfts={walletNFTs.filter(nft => 
              !sellerListings.some(listing => 
                listing.nft.contractAddress.toLowerCase() === nft.contractAddress.toLowerCase() && 
                listing.nft.tokenId === nft.tokenId.toString()
              )
            )}
            onSelect={handleNFTSelect}
            isLoading={isLoadingNFTs}
          />
        </div>
      )}

      {currentView === 'create' && selectedNFT && (
        <div>
          <div className="mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Create Listing</h2>
            <p className="mt-1 text-sm text-gray-500">
              Configure the BNPL terms for your NFT listing
            </p>
          </div>
          <ListingForm
            nft={selectedNFT}
            onSubmit={handleListingSubmit}
            onCancel={() => setCurrentView('select-nft')}
          />
        </div>
      )}

      {currentView === 'manage' && (
        <div>
          <div className="mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Manage Listings</h2>
            <p className="mt-1 text-sm text-gray-500">
              View and manage your active NFT listings
            </p>
          </div>
          {isLoading ? (
            <div className="text-center py-8">
              <p>Loading your listings...</p>
            </div>
          ) : sellerListings.length > 0 ? (
            <ListingManager
              listings={sellerListings}
              onDelist={handleDelistNFT}
            />
          ) : (
            <div className="text-center py-8 border rounded-lg">
              <p className="text-gray-500">You don't have any active listings.</p>
              <button
                onClick={handleCreateListing}
                className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                Create a listing
              </button>
            </div>
          )}
        </div>
      )}
      
      {currentView === 'history' && (
        <div>
          <div className="mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Completed Sales</h2>
            <p className="mt-1 text-sm text-gray-500">
              View your completed and defaulted sales history
            </p>
          </div>
          <CompletedListings />
        </div>
      )}
      
      {currentView === 'withdraw' && (
        <div>
          <div className="mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Withdraw Funds</h2>
            <p className="mt-1 text-sm text-gray-500">
              Withdraw your earned funds from completed sales and penalties
            </p>
          </div>
          <WithdrawFunds />
        </div>
      )}

      {currentTransaction && showTransactionModal && (
        <TransactionModal
          transaction={currentTransaction}
          isOpen={showTransactionModal}
          onClose={() => {
            setShowTransactionModal(false);
            setCurrentTransaction(null);
          }}
        />
      )}
    </div>
  );
}