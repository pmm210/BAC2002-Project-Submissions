import { PAYMENT_SCHEDULE, NFT_STANDARDS } from '../config/constants';
import { Address } from 'viem';
import { Listing } from '../hooks/useContracts';

export type PaymentFrequency = typeof PAYMENT_SCHEDULE.FREQUENCIES[number];
export type NFTStandard = keyof typeof NFT_STANDARDS;

export interface Notification {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title?: string;
  message: string;
  autoHide?: boolean;
  duration?: number;
  timestamp: Date;
}

export interface NFT {
  contractAddress: Address;
  tokenId: bigint | string;
  standard: NFTStandard;
  title: string;
  description: string;
  image: string;
  collection: {
    name: string;
    symbol: string;
  };
  owner: Address;
  listingHistory?: ListingHistoryItem[];
  balance?: bigint | string;
  isListed?: boolean;
}

export interface ListingHistoryItem {
  id: bigint;
  price: bigint;
  timestamp: Date;
}

export interface PaymentSchedule {
  duration: number;
  frequency: PaymentFrequency;
  totalPrice: bigint;
  initialPayment: bigint;
  installmentAmount: bigint;
  penaltyRate: number;
}

export interface Loan {
  id: bigint;
  nft: NFT;
  seller: Address;
  buyer: Address;
  schedule: PaymentSchedule;
  status: 'active' | 'completed' | 'defaulted';
  nextPaymentDue: Date;
  remainingBalance: bigint;
  missedPayments: number;
  totalPenalties: bigint;
  escrowBalance: bigint;
}

export interface NFTListing {
  id: string;
  nft: NFT;
  seller: Address;
  totalPrice: bigint;
  allowedDurations: number[];
  allowedFrequencies: PaymentFrequency[];
  penaltyRate: number;
  active: boolean;
  createdAt: Date;
  activeLoan?: Loan;
  isCompleted: boolean;
  isDelisted: boolean;
  viewCount: number;
  lastViewed?: Date;
  remainingBalance?: bigint;
  status: 'available' | 'in_progress' | 'completed' | 'delisted';
  listingDuration?: number; // Making this optional since it might not exist in all listings
  metadataURI?: string; // Added for IPFS metadata reference
}

export interface Transaction {
  hash: string;
  type: 'list' | 'buy' | 'payment' | 'default' | 'withdraw'; 
  status: 'pending' | 'success' | 'failed';
  timestamp: Date;
  data: {
    nft?: NFT;
    loan?: Loan;
    amount?: bigint;
    schedule?: PaymentSchedule;
    listing?: Listing;
  };
  error?: string;
}

export interface UserPreferences {
  notifications: {
    paymentReminders: boolean;
    penaltyWarnings: boolean;
    defaultRiskAlerts: boolean;
    transactionUpdates: boolean;
  };
  defaultPaymentSchedule: {
    duration: number;
    frequency: PaymentFrequency;
  };
}
