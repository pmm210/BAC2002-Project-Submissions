import { useState, useEffect, useCallback } from 'react';
import { useAccount } from 'wagmi';
import { Loan, UserPreferences } from '../types';

export function useNotifications() {
  const { address } = useAccount();
  const [preferences, setPreferences] = useState<UserPreferences>({
    notifications: {
      paymentReminders: true,
      penaltyWarnings: true,
      defaultRiskAlerts: true,
      transactionUpdates: true,
    },
    defaultPaymentSchedule: {
      duration: 3,
      frequency: 'monthly',
    },
  });

  // Load preferences from localStorage
  useEffect(() => {
    if (address) {
      const stored = localStorage.getItem(`preferences_${address}`);
      if (stored) {
        setPreferences(JSON.parse(stored));
      }
    }
  }, [address]);

  // Save preferences to localStorage
  const updatePreferences = useCallback((newPreferences: UserPreferences) => {
    if (address) {
      setPreferences(newPreferences);
      localStorage.setItem(`preferences_${address}`, JSON.stringify(newPreferences));
    }
  }, [address]);

  const checkPaymentDue = useCallback((loan: Loan) => {
    if (!preferences.notifications.paymentReminders) return null;

    const now = new Date();
    const dueDate = new Date(loan.nextPaymentDue);
    const daysUntilDue = Math.ceil((dueDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

    if (daysUntilDue <= 3 && daysUntilDue > 0) {
      return {
        type: 'warning',
        message: `Payment due in ${daysUntilDue} day${daysUntilDue > 1 ? 's' : ''}`,
        loan,
      };
    }
    return null;
  }, [preferences]);

  const checkPenaltyRisk = useCallback((loan: Loan) => {
    if (!preferences.notifications.penaltyWarnings) return null;

    const now = new Date();
    const dueDate = new Date(loan.nextPaymentDue);
    if (now > dueDate) {
      return {
        type: 'error',
        message: 'Payment overdue - penalty will be applied',
        loan,
      };
    }
    return null;
  }, [preferences]);

  const checkDefaultRisk = useCallback((loan: Loan) => {
    if (!preferences.notifications.defaultRiskAlerts) return null;

    if (loan.missedPayments >= 2) {
      return {
        type: 'error',
        message: 'High risk of default - immediate action required',
        loan,
      };
    }
    return null;
  }, [preferences]);

  const getNotifications = useCallback((loans: Loan[]) => {
    const notifications = [];

    for (const loan of loans) {
      const paymentNotification = checkPaymentDue(loan);
      const penaltyNotification = checkPenaltyRisk(loan);
      const defaultNotification = checkDefaultRisk(loan);

      if (paymentNotification) notifications.push(paymentNotification);
      if (penaltyNotification) notifications.push(penaltyNotification);
      if (defaultNotification) notifications.push(defaultNotification);
    }

    return notifications;
  }, [checkPaymentDue, checkPenaltyRisk, checkDefaultRisk]);

  return {
    preferences,
    updatePreferences,
    getNotifications,
  };
}

export default useNotifications;
