import { useEffect, useState, useCallback } from 'react';
import { usePublicClient } from 'wagmi';
import { NFT } from '@/types';
import { getKnownNFTCollections } from '@/config/constants';
import { Address, getContract, parseEventLogs } from 'viem';

// Standard ERC1155 ABI (minimal for ownership checking)
const ERC1155_ABI = [
  {
    "inputs": [],
    "stateMutability": "nonpayable",
    "type": "constructor"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": true,
        "internalType": "address",
        "name": "operator",
        "type": "address"
      },
      {
        "indexed": true,
        "internalType": "address",
        "name": "from",
        "type": "address"
      },
      {
        "indexed": true,
        "internalType": "address",
        "name": "to",
        "type": "address"
      },
      {
        "indexed": false,
        "internalType": "uint256",
        "name": "id",
        "type": "uint256"
      },
      {
        "indexed": false,
        "internalType": "uint256",
        "name": "value",
        "type": "uint256"
      }
    ],
    "name": "TransferSingle",
    "type": "event"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "account",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "id",
        "type": "uint256"
      }
    ],
    "name": "balanceOf",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "name": "uri",
    "outputs": [
      {
        "internalType": "string",
        "name": "",
        "type": "string"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  }
] as const;

interface FetchNFTsOptions {
  enabled?: boolean;
  debug?: boolean;
  fromBlock?: bigint;
}

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export function useNFTs(address?: Address, options: FetchNFTsOptions = {}) {
  const { enabled = true, debug = false, fromBlock = BigInt(0) } = options;
  const [nfts, setNfts] = useState<NFT[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const publicClient = usePublicClient();

  // Helper to safely serialize objects containing BigInt
  const safeStringify = (obj: any) => {
    return JSON.stringify(obj, (_, value) => {
      if (typeof value === 'bigint') {
        return value.toString();
      }
      // Handle nested BigInts in objects
      if (value && typeof value === 'object') {
        for (const k in value) {
          if (typeof value[k] === 'bigint') {
            value[k] = value[k].toString();
          }
        }
      }
      return value;
    });
  };

  // Helper to parse JSON and convert stringified BigInts back to BigInt
  const safeParse = (json: string) => {
    return JSON.parse(json, (_, value) => {
      if (typeof value === 'string' && /^\d+$/.test(value)) {
        return BigInt(value);
      }
      return value;
    });
  };

  const fetchNFTs = useCallback(async (forceRefresh = false) => {
    if (!address || !publicClient || !enabled) return;

    const cacheKey = `nfts_${address.toLowerCase()}_${publicClient.chain.id}`;
    
    if (!forceRefresh) {
      const cachedNFTs = localStorage.getItem(cacheKey);
      if (cachedNFTs) {
        try {
          const { data, timestamp } = safeParse(cachedNFTs);
          if (Date.now() - timestamp < 60 * 60 * 1000) { // 1-hour TTL
            // Ensure any cached BigInts are converted to strings
            const stringifiedData = data.map((nft: NFT) => ({
              ...nft,
              tokenId: typeof nft.tokenId === 'bigint' ? nft.tokenId.toString() : nft.tokenId
            }));
            setNfts(stringifiedData);
            return;
          }
        } catch (err) {
          console.error('Error parsing cached NFTs:', err);
        }
      }
    } else {
      localStorage.removeItem(cacheKey);
    }

    setIsLoading(true);
    setError(null);
    const foundNFTs: NFT[] = [];

    try {
      // Get collections for the current chain
      const currentChainId = publicClient.chain.id;
      console.log(`Using chainId ${currentChainId} to fetch NFT collections`);
      const collections = getKnownNFTCollections(currentChainId);
      
      for (const contract of collections) {
        // Add debug logging here
        console.log("Checking contract for NFTs:", { 
          name: contract.name,
          address: contract.address,
          standard: contract.standard,
          yourAddress: address,
          chainId: currentChainId
        });
        
        if (contract.standard !== 'ERC1155' || contract.address === '0x0000000000000000000000000000000000000000') {
          if (debug) console.log(`Skipping non-ERC1155 or undeployed contract: ${contract.name}`);
          continue;
        }
        await delay(100); // 100ms delay between contracts (10 requests/second max)

        const nftContract = getContract({
          address: contract.address,
          abi: ERC1155_ABI,
          client: publicClient,
        });

        // Fetch TransferSingle events to the user's address
        const logs = await publicClient.getLogs({
          address: contract.address,
          event: {
            type: 'event',
            name: 'TransferSingle',
            inputs: [
              { indexed: true, name: 'operator', type: 'address' },
              { indexed: true, name: 'from', type: 'address' },
              { indexed: true, name: 'to', type: 'address' },
              { indexed: false, name: 'id', type: 'uint256' },
              { indexed: false, name: 'value', type: 'uint256' },
            ],
          },
          fromBlock: fromBlock,
          toBlock: 'latest',
        });

        const parsedLogs = parseEventLogs({
          abi: ERC1155_ABI,
          logs,
        });

        const ownedTokenIds = new Set<bigint>();
        for (const log of parsedLogs) {
          if (log.args.to?.toLowerCase() === address.toLowerCase() && log.args.value > 0n) {
            ownedTokenIds.add(log.args.id);
          }
          // Account for transfers away
          if (log.args.from?.toLowerCase() === address.toLowerCase()) {
            ownedTokenIds.delete(log.args.id);
          }
        }

        // If no events were found from logs, try direct balance checks
        if (ownedTokenIds.size === 0) {
          // Try checking token #3 directly since we know it exists
          try {
            const tokenId = BigInt(3);
            const balance = await nftContract.read.balanceOf([address, tokenId]);
            console.log(`Direct balance check for token #3: ${balance.toString()}`);
            if (balance > 0n) {
              ownedTokenIds.add(tokenId);
            }
          } catch (err) {
            console.error("Error checking token #3 balance:", err);
          }
        }

        // Verify ownership and fetch metadata
        for (const tokenId of ownedTokenIds) {
          const balance = await nftContract.read.balanceOf([address, tokenId]);
          if (balance > 0n) {
            let metadata = { name: `Token #${tokenId}`, description: '', image: '' };
            try {
              const tokenURI = await nftContract.read.uri([tokenId]);
              if (tokenURI) {
                try {
                  // Try to fetch from IPFS gateway
                  const response = await fetch(String(tokenURI).replace('ipfs://', 'https://ipfs.io/ipfs/'));
                  if (response.ok) metadata = await response.json();
                } catch (fetchError) {
                  // If fetching fails, just log the error and continue with default metadata
                  console.log(`Error fetching metadata from IPFS for token ${tokenId}:`, fetchError);
                  // No need to rethrow - we'll use default metadata
                }
              }
            } catch (uriError) {
              if (debug) console.error(`Error fetching URI for token ${tokenId}:`, uriError);
            }
            foundNFTs.push({
              contractAddress: contract.address,
              tokenId,
              standard: 'ERC1155',
              title: metadata.name || `${contract.name} #${tokenId}`,
              description: metadata.description || '',
              image: metadata.image || 'https://rose-implicit-cat-131.mypinata.cloud/ipfs/bafybeih5y2ez3aalylhr5iqypu7opixknglffaf6fd7b22jffo2ped323m',
              collection: { name: contract.name, symbol: contract.symbol },
              owner: address,
            });
          }
        }
      }

      const sortedNFTs = foundNFTs.sort((a, b) => {
        const nameCompare = a.collection.name.localeCompare(b.collection.name);
        if (nameCompare !== 0) return nameCompare;
        
        // Compare tokenIds as strings to avoid BigInt issues
        const aId = typeof a.tokenId === 'bigint' ? a.tokenId.toString() : String(a.tokenId);
        const bId = typeof b.tokenId === 'bigint' ? b.tokenId.toString() : String(b.tokenId);
        return aId.localeCompare(bId);
      });
      
      // Convert BigInt tokenIds to strings before storing in state
      const stringifiedNFTs = sortedNFTs.map(nft => {
        const converted: any = {
          ...nft,
          tokenId: typeof nft.tokenId === 'bigint' ? nft.tokenId.toString() : nft.tokenId
        };
        
        if (nft.balance) {
          converted.balance = typeof nft.balance === 'bigint' ? nft.balance.toString() : nft.balance;
        }
        
        return converted;
      });
      
      setNfts(stringifiedNFTs);
      localStorage.setItem(cacheKey, safeStringify({
        data: stringifiedNFTs,
        timestamp: Date.now()
      }));
    } catch (err) {
      console.error('Error fetching NFTs:', err);
      setError(err instanceof Error ? err : new Error('Failed to fetch NFTs'));
    } finally {
      setIsLoading(false);
    }
  }, [address, publicClient, enabled, debug, fromBlock]);

  useEffect(() => {
    fetchNFTs();
  }, [fetchNFTs]);

  return { nfts, isLoading, error, refetch: fetchNFTs };
}

// Helper to convert NFT tokenId back to BigInt when needed
export function parseNFTTokenId(nft: NFT): bigint {
  return typeof nft.tokenId === 'string' ? BigInt(nft.tokenId) : nft.tokenId;
}

export default useNFTs;