import { useEffect, useMemo } from 'react';
import { useAccount, usePublicClient, useWalletClient } from 'wagmi';
import { getContract, Address, parseEther } from 'viem';
import type { PublicClient, WalletClient, Hash, TransactionReceipt, Log } from 'viem';
import { CONTRACTS, PAYMENT_SCHEDULE } from '../config/constants';
import LoanManagerABI from '../abis/LoanManager.json';
import NFTEscrowABI from '../abis/NFTEscrow.json';
import { pinJSONToIPFS as uploadToIPFS, fetchFromIPFS, getIPFSUrl } from '../lib/pinata';

// Add ERC721 and ERC1155 ABIs for interface checks
const ERC721_ABI = [
  {
    "inputs": [
      { "internalType": "address", "name": "owner", "type": "address" },
      { "internalType": "address", "name": "operator", "type": "address" }
    ],
    "name": "isApprovedForAll",
    "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "address", "name": "operator", "type": "address" },
      { "internalType": "bool", "name": "approved", "type": "bool" }
    ],
    "name": "setApprovalForAll",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "uint256", "name": "tokenId", "type": "uint256" }
    ],
    "name": "ownerOf",
    "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
    "stateMutability": "view",
    "type": "function"
  }
];

const ERC1155_ABI = [
  {
    "inputs": [
      { "internalType": "address", "name": "account", "type": "address" },
      { "internalType": "address", "name": "operator", "type": "address" }
    ],
    "name": "isApprovedForAll",
    "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "address", "name": "operator", "type": "address" },
      { "internalType": "bool", "name": "approved", "type": "bool" }
    ],
    "name": "setApprovalForAll",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "address", "name": "account", "type": "address" },
      { "internalType": "uint256", "name": "id", "type": "uint256" }
    ],
    "name": "balanceOf",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  }
];

// Enums matching the smart contract
export enum NFTStandard { 
  ERC721 = 0, 
  ERC1155 = 1 
}

export enum LoanStatus { 
  ACTIVE = 0, 
  COMPLETED = 1, 
  DEFAULTED = 2 
}

export function getNFTStandard(standard: string | number): NFTStandard {
  if (typeof standard === 'string') {
    return standard === 'ERC1155' ? NFTStandard.ERC1155 : NFTStandard.ERC721;
  }
  return standard === 1155 ? NFTStandard.ERC1155 : NFTStandard.ERC721;
}

// Contract types
export type Loan = {
  seller: Address;
  buyer: Address;
  nftContract: Address;
  tokenId: bigint;
  amount: bigint;
  standard: NFTStandard;
  totalPrice: bigint;
  penaltyPercentage: number;
  remainingBalance: bigint;
  installmentAmount: bigint;
  nextPaymentDue: bigint;
  missedPayments: number;
  totalPenalties: bigint;
  status: LoanStatus;
};

export type LoanCreationParams = {
  nftContract: Address;
  tokenId: bigint;
  amount: bigint;
  totalPrice: bigint;
  penaltyPercentage: number;
  buyer: Address;
  seller: Address;
  standard: NFTStandard;
  metadataURI?: string;
};

export type LoanMonitoringResult = {
  loan: Loan;
  penalty: bigint;
  formattedStatus: {
    loanId: string;
    status: string;
    remainingBalance: string;
    nextPaymentDue: string;
    timeUntilPayment: number;
    currentPenalty: string;
    missedPayments: number;
    totalPenalties: string;
  };
};

export type ListingMetadata = {
  title: string;
  description: string;
  totalPrice: string;
  allowedDurations: number[];
  allowedFrequencies: string[];
  penaltyRate: number;
  listingDuration: number;
  seller: string;
  createdAt: string;
  status?: 'available' | 'in_progress' | 'completed' | 'delisted';
  nft: {
    contractAddress: string;
    tokenId: string;
    standard: string;
    title: string;
    image: string;
    collection: {
      name: string;
      symbol: string;
    };
  };
  buyerRequirements?: {
    minEthBalance: string;
    minTransactionCount: number;
  };
};

export type ListingWithMetadata = {
  loanId: bigint;
  nftContract: Address;
  tokenId: bigint;
  amount: bigint;
  standard: NFTStandard;
  seller: Address;
  isActive: boolean;
  metadataURI: string;
  metadata: ListingMetadata;
};

export type ListingParams = {
  loanId: bigint;
  totalPrice: bigint;
  allowedDurations: number[];
  allowedFrequencies: string[];
  penaltyRate: number;
  title: string;
  description: string;
  listingDuration: number;
  nft: {
    contractAddress: Address;
    tokenId: bigint;
    standard: string;
    title: string;
    image: string;
    collection: {
      name: string;
      symbol: string;
    };
  };
  buyerRequirements?: {
    minEthBalance: bigint;
    minTransactionCount: number;
  };
};

export type Listing = {
  loanId: bigint;
  totalPrice: bigint;
  allowedDurations: number[];
  allowedFrequencies: number[];
  penaltyRate: number;
  metadataURI: string;
};

const INITIAL_PAYMENT_NUMERATOR = BigInt(3333);
const INITIAL_PAYMENT_DENOMINATOR = BigInt(10000);

export function useContracts() {
  const { chain, address: userAddress } = useAccount();
  const publicClient = usePublicClient();
  const { data: walletClient } = useWalletClient();

  const chainId = chain?.id;
  const contracts = chainId ? CONTRACTS[chainId] : null;

  // Contract initialization with debug logging
  const loanManager = useMemo(() => {
    if (!contracts?.LOAN_MANAGER || !publicClient) {
      console.debug('LoanManager initialization failed:', {
        contractAddress: contracts?.LOAN_MANAGER,
        publicClient: !!publicClient
      });
      return null;
    }
    
    console.debug('Initializing LoanManager at:', contracts.LOAN_MANAGER);
    return getContract({
      address: contracts.LOAN_MANAGER as Address,
      abi: LoanManagerABI,
      client: publicClient,
    });
  }, [contracts?.LOAN_MANAGER, publicClient]);

  // NFT Escrow contract initialization
  const nftEscrow = useMemo(() => {
    if (!contracts?.NFT_ESCROW || !publicClient) {
      console.debug('NFTEscrow initialization failed:', {
        contractAddress: contracts?.NFT_ESCROW,
        publicClient: !!publicClient
      });
      return null;
    }
    
    console.debug('Initializing NFTEscrow at:', contracts.NFT_ESCROW);
    return getContract({
      address: contracts.NFT_ESCROW as Address,
      abi: NFTEscrowABI,
      client: publicClient,
    });
  }, [contracts?.NFT_ESCROW, publicClient]);

  // Helper function to check ERC721 approval
  const checkERC721Approval = async (nftContract: Address, owner: Address, operator: Address): Promise<boolean> => {
    if (!publicClient) throw new Error('Public client not available');
    
    try {
      const isApproved = await publicClient.readContract({
        address: nftContract,
        abi: ERC721_ABI,
        functionName: 'isApprovedForAll',
        args: [owner, operator]
      });
      
      return isApproved as boolean;
    } catch (error: any) {
      console.error('Error checking ERC721 approval:', error);
      return false;
    }
  };

  // Helper function to check ERC721 owner
  const checkERC721Owner = async (nftContract: Address, tokenId: bigint): Promise<Address> => {
    if (!publicClient) throw new Error('Public client not available');
    
    try {
      const owner = await publicClient.readContract({
        address: nftContract,
        abi: ERC721_ABI,
        functionName: 'ownerOf',
        args: [tokenId]
      });
      
      return owner as Address;
    } catch (error: any) {
      console.error(`Error checking owner of token ${tokenId}:`, error);
      
      if (error.message && error.message.includes('nonexistent token')) {
        throw new Error(`Token ID ${tokenId} does not exist in contract ${nftContract}`);
      }
      
      throw error;
    }
  };

  // Helper function to set ERC721 approval
  const setERC721Approval = async (nftContract: Address, operator: Address, approved: boolean = true): Promise<TransactionReceipt> => {
    if (!walletClient || !publicClient) throw new Error('Wallet or public client not available');
    
    try {
      console.debug(`Setting ERC721 approval for ${operator} to ${approved}`);
      
      const { request } = await publicClient.simulateContract({
        address: nftContract,
        abi: ERC721_ABI,
        functionName: 'setApprovalForAll',
        args: [operator, approved],
        account: walletClient.account
      });
      
      const hash = await walletClient.writeContract(request);
      console.debug('Approval transaction sent:', hash);
      
      const receipt = await publicClient.waitForTransactionReceipt({ hash });
      console.debug('Approval complete:', receipt);
      
      return receipt;
    } catch (error: any) {
      console.error('Error setting ERC721 approval:', error);
      throw error;
    }
  };

  // Helper function to check ERC1155 approval
  const checkERC1155Approval = async (nftContract: Address, owner: Address, operator: Address): Promise<boolean> => {
    if (!publicClient) throw new Error('Public client not available');
    
    try {
      const isApproved = await publicClient.readContract({
        address: nftContract,
        abi: ERC1155_ABI,
        functionName: 'isApprovedForAll',
        args: [owner, operator]
      });
      
      return isApproved as boolean;
    } catch (error: any) {
      console.error('Error checking ERC1155 approval:', error);
      return false;
    }
  };

  // Helper function to check ERC1155 balance
  const checkERC1155Balance = async (nftContract: Address, account: Address, tokenId: bigint): Promise<bigint> => {
    if (!publicClient) throw new Error('Public client not available');
    
    try {
      const balance = await publicClient.readContract({
        address: nftContract,
        abi: ERC1155_ABI,
        functionName: 'balanceOf',
        args: [account, tokenId]
      });
      
      return balance as bigint;
    } catch (error: any) {
      console.error(`Error checking balance of token ${tokenId} for account ${account}:`, error);
      throw error;
    }
  };

  // Helper function to set ERC1155 approval
  const setERC1155Approval = async (nftContract: Address, operator: Address, approved: boolean = true): Promise<TransactionReceipt> => {
    if (!walletClient || !publicClient) throw new Error('Wallet or public client not available');
    
    try {
      console.debug(`Setting ERC1155 approval for ${operator} to ${approved}`);
      
      const { request } = await publicClient.simulateContract({
        address: nftContract,
        abi: ERC1155_ABI,
        functionName: 'setApprovalForAll',
        args: [operator, approved],
        account: walletClient.account
      });
      
      const hash = await walletClient.writeContract(request);
      console.debug('Approval transaction sent:', hash);
      
      const receipt = await publicClient.waitForTransactionReceipt({ hash });
      console.debug('Approval complete:', receipt);
      
      return receipt;
    } catch (error: any) {
      console.error('Error setting ERC1155 approval:', error);
      throw error;
    }
  };

  const createLoan = async ({
    nftContract,
    tokenId,
    amount,
    totalPrice,
    penaltyPercentage,
    buyer,
    seller,
    standard,
    metadataURI = ''
  }: LoanCreationParams & { metadataURI?: string }): Promise<TransactionReceipt> => {
    if (!loanManager || !walletClient || !publicClient) {
      throw new Error('Contract or wallet not available');
    }
    
    if (!buyer) {
      throw new Error('Buyer address cannot be empty');
    }
    
    console.debug('Verifying buyer/seller addresses:', {
      buyer,
      seller,
      areEqual: buyer === seller
    });
    
    if (buyer.toLowerCase() === seller.toLowerCase()) {
      throw new Error('You cannot buy your own NFT listing - buyer and seller addresses match');
    }

    console.debug('Creating loan with params:', {
      nftContract,
      tokenId: tokenId.toString(),
      amount: amount.toString(),
      totalPrice: totalPrice.toString(),
      penaltyPercentage,
      buyer,
      seller,
      standard
    });
    
    console.log("Wallet addresses:", {
      connectedAccount: walletClient.account.address,
      buyerParameter: buyer,
      sellerAddress: seller
    });
    console.log("Transaction sender will be:", walletClient.account.address);

    try {
      // First verify the NFT is approved for transfer to escrow
      if (!nftEscrow) {
        throw new Error('NFT Escrow contract not available');
      }

      console.debug('NFT Escrow contract address:', nftEscrow.address);

      const isApproved = standard === NFTStandard.ERC721 
        ? await checkERC721Approval(nftContract, buyer, nftEscrow.address)
        : await checkERC1155Approval(nftContract, buyer, nftEscrow.address);
      
      if (!isApproved) {
        console.log('Requesting NFT approval from wallet...');
        if (standard === NFTStandard.ERC721) {
          await setERC721Approval(nftContract, nftEscrow.address);
        } else {
          await setERC1155Approval(nftContract, nftEscrow.address);
        }
        console.log('NFT approval completed');
      }

      // Verify buyer has sufficient balance for initial payment
      const buyerBalance = await publicClient.getBalance({ address: buyer });
      const initialPayment = (totalPrice * INITIAL_PAYMENT_NUMERATOR) / INITIAL_PAYMENT_DENOMINATOR;
      
      console.debug('Payment verification:', {
        buyerBalance: buyerBalance.toString(),
        initialPayment: initialPayment.toString(),
        hasSufficientFunds: buyerBalance >= initialPayment
      });

      if (buyerBalance < initialPayment) {
        throw new Error(`Insufficient funds: Need ${initialPayment.toString()} wei but only have ${buyerBalance.toString()}`);
      }

      // Verify buyer has approved escrow for NFT transfers
      const isBuyerApproved = standard === NFTStandard.ERC721 
        ? await checkERC721Approval(nftContract, buyer, nftEscrow.address)
        : await checkERC1155Approval(nftContract, buyer, nftEscrow.address);

      if (!isBuyerApproved) {
        throw new Error('Buyer has not approved NFT transfers to escrow contract');
      }

      // Simulate the transaction first to catch potential reverts
      console.debug('Simulating contract call with:', {
        nftContract,
        tokenId: tokenId.toString(),
        amount: amount.toString(),
        totalPrice: totalPrice.toString(),
        penaltyPercentage,
        buyer,
        standard,
        initialPayment: initialPayment.toString()
      });
      const { request } = await publicClient.simulateContract({
        address: loanManager.address,
        abi: loanManager.abi,
        functionName: 'createLoan',
        args: [nftContract, tokenId, amount, totalPrice, penaltyPercentage, buyer, standard, metadataURI],
        value: initialPayment,
        account: walletClient.account
      });
      console.debug('Simulation successful, preparing transaction...');

      // Send the transaction and wait for confirmation
      console.debug('Sending transaction...');
      const hash = await walletClient.writeContract(request);
      console.debug('Loan creation transaction sent:', hash);
      console.debug('Waiting for transaction receipt...');

      // Wait for transaction receipt with timeout
      const receipt = await Promise.race<TransactionReceipt>([
        publicClient.waitForTransactionReceipt({ hash }),
        new Promise<never>((_, reject) => 
          setTimeout(() => reject(new Error('Transaction timeout')), 30000)
        )
      ]);

      if (receipt.status === 'reverted') {
        throw new Error('Transaction reverted');
      }

      console.debug('Loan creation complete:', receipt);
      return receipt;
    } catch (error: any) {
      console.error('Error creating loan:', error);
      
      // Parse contract revert reasons if available
      let errorMessage = 'Failed to create loan';
      if (error?.details) {
        errorMessage = error.details;
      } else if (error?.message?.includes('reverted')) {
        if (error.message.includes('ERC721: transfer caller is not owner nor approved')) {
          errorMessage = 'NFT transfer not approved - please approve the escrow contract';
        } else if (error.message.includes('ERC1155: caller is not owner nor approved')) {
          errorMessage = 'NFT transfer not approved - please approve the escrow contract';
        } else if (error.message.includes('Insufficient payment')) {
          errorMessage = 'Insufficient initial payment amount';
        } else if (error.message.includes('Invalid NFT standard')) {
          errorMessage = 'Invalid NFT type specified';
        } else if (error.message.includes('Seller cannot be buyer')) {
          errorMessage = 'You cannot purchase your own listing';
        } else {
          try {
            const revertReason = error?.data?.message?.match(/reverted with reason string '(.+?)'/)?.[1];
            if (revertReason) {
              errorMessage = revertReason;
            }
          } catch (parseError) {
            console.error('Error parsing revert reason:', parseError);
          }
        }
      } else if (error.message.includes('timeout')) {
        errorMessage = 'Transaction timed out - check your wallet connection';
      } else if (error.message.includes('insufficient funds')) {
        errorMessage = 'Insufficient funds for initial payment';
      } else if (error.message) {
        errorMessage = error.message;
      }

      console.error('Loan creation failed:', errorMessage);
      throw new Error(errorMessage);
    }
  };

  const createLoanForEscrow = async (
    escrowId: bigint,
    totalPrice: bigint,
    penaltyPercentage: number
  ) => {
    if (!loanManager || !walletClient || !publicClient) {
      throw new Error('Contract or wallet not available');
    }
  
    try {
      const initialPayment = (totalPrice * INITIAL_PAYMENT_NUMERATOR) / INITIAL_PAYMENT_DENOMINATOR;
      
      const buyerBalance = await publicClient.getBalance({ address: walletClient.account.address });
      console.debug('Payment verification for escrow loan:', {
        buyerBalance: buyerBalance.toString(),
        initialPayment: initialPayment.toString(),
        hasSufficientFunds: buyerBalance >= initialPayment
      });
  
      if (buyerBalance < initialPayment) {
        throw new Error(`Insufficient funds: Need ${initialPayment.toString()} wei but only have ${buyerBalance.toString()}`);
      }
  
      console.debug('Simulating createLoanForEscrow call with:', {
        escrowId: escrowId.toString(),
        totalPrice: totalPrice.toString(),
        penaltyPercentage,
        initialPayment: initialPayment.toString()
      });
      
      const { request } = await publicClient.simulateContract({
        address: loanManager.address,
        abi: loanManager.abi,
        functionName: 'createLoanForEscrow',
        args: [escrowId, totalPrice, penaltyPercentage],
        value: initialPayment,
        account: walletClient.account
      });
      
      console.debug('Simulation successful, preparing to send transaction...');
  
      const hash = await walletClient.writeContract(request);
      console.debug('Transaction sent, hash:', hash);
      
      // Just return the transaction hash without waiting for receipt
      return { 
        transactionHash: hash
      };
      
    } catch (error: any) {
      console.error('Full error details in createLoanForEscrow:', {
        message: error.message,
        details: error.details,
        stack: error.stack,
        rawError: error
      });
      
      let errorMessage = 'Failed to create loan';
      if (error?.details) {
        errorMessage = error.details;
      } else if (error?.message?.includes('reverted')) {
        if (error.message.includes('Escrow not active')) {
          errorMessage = 'This NFT is no longer available for purchase';
        } else if (error.message.includes('Loan already exists')) {
          errorMessage = 'This NFT has already been purchased';
        } else if (error.message.includes('Insufficient payment')) {
          errorMessage = 'Insufficient initial payment amount';
        } else {
          try {
            const revertReason = error?.data?.message?.match(/reverted with reason string '(.+?)'/)?.[1];
            if (revertReason) errorMessage = revertReason;
          } catch (parseError) {
            console.error('Error parsing revert reason:', parseError);
          }
        }
      } else if (error.message.includes('timeout')) {
        errorMessage = 'Transaction timed out - check your wallet connection';
      } else if (error.message.includes('insufficient funds')) {
        errorMessage = 'Insufficient funds for initial payment';
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      throw new Error(errorMessage);
    }
  };

  const makePayment = async (loanId: bigint, amount: bigint): Promise<TransactionReceipt> => {

    console.log('Payment dependencies check:', {
      loanManagerAvailable: !!loanManager,
      walletClientAvailable: !!walletClient,
      publicClientAvailable: !!publicClient
    });
    
    if (!loanManager || !walletClient || !publicClient) 
      throw new Error('Contract or wallet not available');

    console.debug('Processing payment for loan:', loanId.toString());

    try {
      const loan = await getLoan(loanId);
      const penalty = await calculatePenalty(loanId);
      const totalDue = loan.installmentAmount + penalty;
      const fullPaymentDue = loan.remainingBalance + penalty;

      console.debug('Payment details:', {
        installmentAmount: loan.installmentAmount.toString(),
        penalty: penalty.toString(),
        totalDue: totalDue.toString(),
        fullPaymentDue: fullPaymentDue.toString(),
        userPayment: amount.toString(),
      });

      if (amount < totalDue) {
        throw new Error('Insufficient payment: Amount must cover at least the installment + penalty');
      }

      const { request } = await publicClient.simulateContract({
        address: loanManager.address,
        abi: loanManager.abi,
        functionName: 'makePayment',
        args: [loanId],
        value: amount,
        account: walletClient.account
      });
      
      const hash = await walletClient.writeContract(request);
      console.debug('Payment transaction sent:', hash);

      const receipt = await publicClient.waitForTransactionReceipt({ hash });
      console.debug('Payment complete:', receipt);

      return receipt;
    } catch (error: any) {
      console.error('Error making payment:', error);
      throw error;
    }
  };

  const getLoan = async (loanId: bigint): Promise<Loan> => {
    if (!loanManager || !publicClient) throw new Error('Contract not available');
  
    try {
      console.log(`Fetching loan data for loan ID: ${loanId.toString()}`);
      const loanData = await publicClient.readContract({
        address: loanManager.address,
        abi: loanManager.abi,
        functionName: 'loans',
        args: [loanId]
      });
      console.log(`Raw loan data from contract:`, loanData);
      
      // Check if it's an array/tuple response (typical for Solidity structs)
      if (Array.isArray(loanData)) {
        console.log(`Loan data is an array with ${loanData.length} items`);
        
        // Map the array positions to the Loan struct fields
        // This mapping should match your contract's Loan struct order
        return {
          seller: loanData[0] as Address,
          buyer: loanData[1] as Address,
          nftContract: loanData[2] as Address,
          tokenId: loanData[3] as bigint,
          amount: loanData[4] as bigint,
          standard: loanData[5] as number,
          totalPrice: loanData[6] as bigint,
          penaltyPercentage: Number(loanData[7]),
          remainingBalance: loanData[8] as bigint,
          installmentAmount: loanData[9] as bigint,
          nextPaymentDue: loanData[10] as bigint,
          missedPayments: Number(loanData[11]),
          totalPenalties: loanData[12] as bigint,
          status: Number(loanData[14]) // Assuming status is at index 14
        };
      } else if (typeof loanData === 'object' && loanData !== null) {
        // It's already an object with named properties
        console.log(`Loan data is an object with keys:`, Object.keys(loanData));
        return loanData as Loan;
      } else {
        console.log(`Unexpected loan data format: ${typeof loanData}`);
        throw new Error(`Unexpected loan data format: ${typeof loanData}`);
      }
    } catch (err) {
      console.error(`Error fetching loan ${loanId}:`, err);
      throw err;
    }
  };

  const calculatePenalty = async (loanId: bigint): Promise<bigint> => {
    if (!loanManager || !publicClient) throw new Error('Contract not available');

    try {
      const penalty = await publicClient.readContract({
        address: loanManager.address,
        abi: loanManager.abi,
        functionName: 'calculatePenalty',
        args: [loanId]
      });
      return penalty as bigint;
    } catch (error: any) {
      console.error('Error calculating penalty:', error);
      throw error;
    }
  };

  const monitorLoan = async (loanId: bigint): Promise<LoanMonitoringResult> => {
    if (!loanManager || !publicClient) throw new Error('Contract not available');
    
    try {
      const loan = await getLoan(loanId);
      const penalty = await calculatePenalty(loanId);
      const now = Math.floor(Date.now() / 1000);
      
      const formattedStatus = {
        loanId: loanId.toString(),
        status: LoanStatus[loan.status],
        remainingBalance: loan.remainingBalance.toString(),
        nextPaymentDue: new Date(Number(loan.nextPaymentDue) * 1000).toISOString(),
        timeUntilPayment: Number(loan.nextPaymentDue) - now,
        currentPenalty: penalty.toString(),
        missedPayments: loan.missedPayments,
        totalPenalties: loan.totalPenalties.toString()
      };

      console.debug('Loan status:', formattedStatus);
      
      return { loan, penalty, formattedStatus };
    } catch (error: any) {
      console.error('Error monitoring loan:', error);
      throw error;
    }
  };

  const checkEscrowHasLoan = async (escrowId: bigint): Promise<boolean> => {
    if (!loanManager || !publicClient) throw new Error('Contract not available');
    
    try {
      const result = await publicClient.readContract({
        address: loanManager.address,
        abi: loanManager.abi,
        functionName: 'escrowHasLoan',
        args: [escrowId]
      });
      console.log('Raw escrowHasLoan result for escrowId', escrowId.toString(), ':', result);
      return result as boolean;
    } catch (error: any) {
      console.error(`Error checking if escrow ${escrowId} has loan:`, error);
      return false;
    }
  };

  // NFT Escrow functions with IPFS integration
  const depositNFTWithMetadata = async (
    nftContract: Address,
    tokenId: bigint,
    seller: Address,
    amount: bigint,
    standard: number,
    metadata: ListingMetadata,
    autoApprove: boolean = true,
    skipOwnershipCheck: boolean = true
  ): Promise<{ receipt: TransactionReceipt; loanId: bigint; metadataURI: string }> => {
    if (!nftEscrow || !walletClient || !publicClient) 
      throw new Error('Contract or wallet not available');
  
    console.debug('Preparing to deposit NFT with metadata:', {
      nftContract,
      tokenId: tokenId.toString(),
      amount: amount.toString(),
      standard,
      metadata,
      autoApprove,
      skipOwnershipCheck
    });
  
    // Add this diagnostic code right here
    console.log('Creating listing with NFT details:', {
      nftContract,
      tokenId: tokenId.toString(),
      ownerAddress: walletClient.account.address,
      chainId
    });
  
    // Then try to check if the NFT is detected
    try {
      if (standard === NFTStandard.ERC721) {
        const owner = await checkERC721Owner(nftContract, tokenId);
        console.log('NFT owner check result:', owner);
      } else {
        const balance = await checkERC1155Balance(nftContract, walletClient.account.address, tokenId);
        console.log('NFT balance check result:', balance.toString());
      }
    } catch (error) {
      console.error('NFT ownership verification failed:', error);
    }
    // End of diagnostic code

  try {
    const metadataURI = await uploadToIPFS(metadata);
    console.debug('Metadata uploaded to IPFS:', metadataURI);

    const nftStandard = standard === NFTStandard.ERC1155 ? 1 : 0;

    if (nftStandard === 0) {
      const isApproved = await checkERC721Approval(nftContract, seller, nftEscrow.address);
      console.debug(`ERC721 approval for ${nftEscrow.address}: ${isApproved}`);
      
      if (!isApproved) {
        if (autoApprove) {
          console.log('Setting ERC721 approval before deposit...');
          await setERC721Approval(nftContract, nftEscrow.address, true);
          console.log('ERC721 approval set successfully');
        } else {
          throw new Error(`Seller has not approved the contract for ERC721 transfers. Please call setERC721Approval first.`);
        }
      }
    } else if (nftStandard === 1) {
      const isApproved = await checkERC1155Approval(nftContract, seller, nftEscrow.address);
      console.debug(`ERC1155 approval for ${nftEscrow.address}: ${isApproved}`);
      
      if (!isApproved) {
        if (autoApprove) {
          console.log('Setting ERC1155 approval before deposit...');
          await setERC1155Approval(nftContract, nftEscrow.address, true);
          console.log('ERC1155 approval set successfully');
        } else {
          throw new Error(`Seller has not approved the contract for ERC1155 transfers. Please call setERC1155Approval first.`);
        }
      }
    }

    if (!skipOwnershipCheck) {
      try {
        if (nftStandard === 0) {
          const owner = await checkERC721Owner(nftContract, tokenId);
          console.debug(`ERC721 token ${tokenId} owner: ${owner}`);
          
          if (owner.toLowerCase() !== seller.toLowerCase()) {
            throw new Error(`Seller ${seller} does not own the NFT with tokenId ${tokenId}`);
          }
        } else if (nftStandard === 1) {
          const balance = await checkERC1155Balance(nftContract, seller, tokenId);
          console.debug(`ERC1155 token ${tokenId} balance for ${seller}: ${balance}`);
          
          if (balance < amount) {
            throw new Error(`Seller ${seller} does not have enough of tokenId ${tokenId}. Required: ${amount}, Available: ${balance}`);
          }
        }
      } catch (error: any) {
        console.error('Error verifying NFT ownership:', error);
        throw new Error(`Failed to verify NFT ownership: ${error.message || 'Unknown error'}`);
      }
    } else {
      console.log('Skipping ownership verification as requested.');
    }

    try {
      console.debug('Simulating deposit NFT contract call with args:', {
        nftContract,
        tokenId: tokenId.toString(),
        seller,
        amount: amount.toString(),
        standard: nftStandard,
        metadataURI
      });
      
      const { request, result } = await publicClient.simulateContract({
        address: nftEscrow.address,
        abi: nftEscrow.abi,
        functionName: 'depositNFT',
        args: [nftContract, tokenId, seller, amount, nftStandard, metadataURI],
        account: walletClient.account
      });

      const hash = await walletClient.writeContract(request);
      console.debug('NFT deposit transaction sent:', hash);

      const receipt = await publicClient.waitForTransactionReceipt({ hash });
      console.debug('NFT deposit complete:', receipt);

      // Use the return value from the contract call directly
      // This is the correct loanId based on the contract logic
      const loanId = BigInt(result);
      console.log('Returned loanId from contract call:', loanId.toString());
      
      // Skip any event parsing - we trust the contract's return value
      
      console.log('Deposited NFT with loanId:', loanId.toString(), 'metadataURI:', metadataURI);
      return { receipt, loanId, metadataURI };
    } catch (error: any) {
      console.error('Contract error during deposit:', error);
      
      if (error.message?.includes('ERC721: owner query for nonexistent token')) {
        throw new Error(`Token ID ${tokenId} does not exist in the contract ${nftContract}`);
      } else if (error.message?.includes('caller is not token owner')) {
        throw new Error(`Seller ${seller} is not the owner of token ID ${tokenId}`);
      } else if (error.message?.includes('reverted')) {
        throw new Error(`Contract error: Transaction reverted. Check token existence, permissions, or contract restrictions.`);
      } else {
        throw new Error(`Contract error: ${error.message || 'Unknown error'}`);
      }
    }
  } catch (error: any) {
    console.error('Error depositing NFT with metadata:', error);
    throw error;
  }
};

  const updateListingMetadata = async (
    loanId: bigint,
    metadata: ListingMetadata
  ): Promise<{ receipt: TransactionReceipt, metadataURI: string }> => {
    if (!nftEscrow || !walletClient || !publicClient) 
      throw new Error('Contract or wallet not available');

    try {
      const metadataURI = await uploadToIPFS(metadata);
      console.debug('Updated metadata uploaded to IPFS:', metadataURI);

      const { request } = await publicClient.simulateContract({
        address: nftEscrow.address,
        abi: nftEscrow.abi,
        functionName: 'updateListingMetadata',
        args: [loanId, metadataURI],
        account: walletClient.account
      });
      
      const hash = await walletClient.writeContract(request);
      console.debug('Metadata update transaction sent:', hash);
      
      const receipt = await publicClient.waitForTransactionReceipt({ hash });
      console.debug('Metadata update complete:', receipt);
      
      return { receipt, metadataURI };
    } catch (error: any) {
      console.error('Error updating listing metadata:', error);
      throw error;
    }
  };

  const releaseNFT = async (
    loanId: bigint,
    recipient: Address
  ): Promise<TransactionReceipt> => {
    if (!nftEscrow || !walletClient || !publicClient) 
      throw new Error('Contract or wallet not available');

    console.debug('Releasing NFT from escrow:', {
      loanId: loanId.toString(),
      recipient
    });

    try {
      const { request } = await publicClient.simulateContract({
        address: nftEscrow.address,
        abi: nftEscrow.abi,
        functionName: 'releaseNFT',
        args: [loanId, recipient],
        account: walletClient.account
      });
      
      const hash = await walletClient.writeContract(request);
      console.debug('NFT release transaction sent:', hash);
      
      const receipt = await publicClient.waitForTransactionReceipt({ hash });
      console.debug('NFT release complete:', receipt);
      
      return receipt;
    } catch (error: any) {
      console.error('Error releasing NFT:', error);
      throw error;
    }
  };

  const getActiveListings = async (startIndex: number, limit: number): Promise<ListingWithMetadata[]> => {
    if (!nftEscrow || !publicClient) throw new Error('Contract not available');
    
    try {
      console.debug('Fetching active listing IDs with params:', { startIndex, limit });
      
      const result = await publicClient.readContract({
        address: nftEscrow.address,
        abi: nftEscrow.abi,
        functionName: 'getActiveListings',
        args: [startIndex, limit],
      }) as [bigint[], string[]];
      
      // Log the full result
      console.log('Raw getActiveListings result:', JSON.stringify(result, (key, value) => 
        typeof value === 'bigint' ? value.toString() : value
      ));
      
      const [activeIds, metadataURIs] = result;
      
      console.debug('Found active listings:', activeIds.map(id => id.toString()));
      console.debug('With metadata URIs:', metadataURIs);

      if (activeIds.length === 0) {
        console.debug('No active listings found.');
        return [];
      }

      const listings: ListingWithMetadata[] = [];
      
      for (let i = 0; i < activeIds.length; i++) {
        const loanId = activeIds[i];
        const metadataURI = metadataURIs[i];
        
        try {
          const escrowDetails = await publicClient.readContract({
            address: nftEscrow.address,
            abi: nftEscrow.abi,
            functionName: 'escrows',
            args: [loanId],
          }) as any;
          
          const nftContract = escrowDetails.nftContract || escrowDetails[0];
          const tokenId = escrowDetails.tokenId || escrowDetails[1];
          const amount = escrowDetails.amount || escrowDetails[2];
          const standard = escrowDetails.standard || escrowDetails[3];
          const seller = escrowDetails.seller || escrowDetails[4];
          const isActive = escrowDetails.isActive || escrowDetails[5];
          
          if (!isActive) continue;
          
          let metadata: ListingMetadata;
          try {
            metadata = await fetchFromIPFS<ListingMetadata>(metadataURI);
          } catch (ipfsError) {
            console.error(`Error fetching IPFS metadata for listing ${loanId}:`, ipfsError);
            
            metadata = {
              title: `Listing ${loanId.toString()}`,
              description: 'Metadata unavailable',
              totalPrice: '0',
              allowedDurations: [30],
              allowedFrequencies: ['weekly'],
              penaltyRate: 5,
              listingDuration: 30,
              seller: seller.toString(),
              createdAt: new Date().toISOString(),
              nft: {
                contractAddress: nftContract.toString(),
                tokenId: tokenId.toString(),
                standard: standard === 0 ? 'ERC721' : 'ERC1155',
                title: 'Unknown NFT',
                image: '',
                collection: {
                  name: 'Unknown Collection',
                  symbol: 'UNK'
                }
              }
            };
          }
          
          listings.push({
            loanId,
            nftContract,
            tokenId,
            amount,
            standard,
            seller,
            isActive,
            metadataURI,
            metadata
          });
        } catch (error) {
          console.error(`Error processing listing for loanId ${loanId}:`, error);
        }
      }
      
      return listings;
    } catch (error) {
      console.error('Error fetching active listings:', error);
      return [];
    }
  };

  const getListing = async (loanId: bigint): Promise<ListingWithMetadata | null> => {
    if (!nftEscrow || !publicClient) throw new Error('Contract not available');
    
    try {
      console.debug(`Fetching listing details for ID: ${loanId}`);
      
      const result = await publicClient.readContract({
        address: nftEscrow.address,
        abi: nftEscrow.abi,
        functionName: 'getListing',
        args: [loanId]
      });
      
      console.debug(`Raw listing data for ID ${loanId}:`, result);
      
      let nftContract, tokenId, amount, standard, seller, isActive, metadataURI;
      
      if (typeof result === 'object' && result !== null) {
        const typedResult = result as any;
        nftContract = typedResult.nftContract;
        tokenId = typedResult.tokenId;
        amount = typedResult.amount;
        standard = typedResult.standard;
        seller = typedResult.seller;
        isActive = typedResult.isActive;
        metadataURI = typedResult.metadataURI;
      } else {
        console.error(`Unexpected result format for listing ${loanId}:`, result);
        return null;
      }
      
      if (!isActive) return null;
      
      let metadata;
      try {
        metadata = await fetchFromIPFS<ListingMetadata>(metadataURI);
      } catch (ipfsError) {
        console.error(`IPFS error for listing ${loanId}:`, ipfsError);
        metadata = {} as ListingMetadata;
      }
      
      return {
        loanId,
        nftContract,
        tokenId,
        amount,
        standard,
        seller,
        isActive,
        metadataURI,
        metadata
      };
    } catch (error) {
      console.error('Error fetching active listings:', error);
      // Log contract address and chain ID for debugging
      console.error('Contract:', nftEscrow.address, 'on chain:', chainId);
      return null;
    }
  };

  const extractLoanIdFromReceipt = (receipt: TransactionReceipt): bigint => {
    try {
      // Safer implementation that looks for topics directly
      // First, look for events with at least 2 topics (event signature + indexed param)
      for (const log of receipt.logs) {
        try {
          // Check if we have enough topics - the NFTDeposited event should have at least 2
          if (log.topics.length >= 2) {
            // Try to extract from the second topic which usually contains the first indexed parameter
            const loanIdHex = log.topics[1];
            if (loanIdHex) {
              return BigInt(loanIdHex);
            }
          }
        } catch (error) {
          // Continue to next log if this one fails
          continue;
        }
      }
      
      // Fallback: try to find a log with enough topics
      const nftDepositedEvent = receipt.logs.find(log => {
        return log.topics.length >= 2;
      });
      
      if (!nftDepositedEvent || !nftDepositedEvent.topics[1]) {
        console.error('Could not find suitable event log in receipt');
        throw new Error('Could not extract loanId from transaction receipt');
      }
      
      const loanIdHex = nftDepositedEvent.topics[1];
      return BigInt(loanIdHex);
    } catch (error) {
      console.error('Error extracting loanId from receipt:', error);
      return BigInt(0);
    }
  };

  return {
    // Contract instances
    loanManager,
    nftEscrow,
    
    // Loan Manager functions
    createLoan,
    createLoanForEscrow,
    makePayment,
    getLoan,
    calculatePenalty,
    monitorLoan,
    checkEscrowHasLoan,
    
    // NFT Escrow functions with IPFS
    depositNFTWithMetadata,
    updateListingMetadata,
    releaseNFT,
    getActiveListings,
    getListing,
    
    // Helper functions
    getNFTStandard,
    extractLoanIdFromReceipt,
    
    // NFT Approval functions
    checkERC721Approval,
    checkERC1155Approval,
    setERC721Approval,
    setERC1155Approval,
    
    // NFT Ownership functions
    checkERC721Owner,
    checkERC1155Balance,
    
    // Contract info
    contracts,
    chainId,
    userAddress,
    
    // Constants
    NFTStandard,
    LoanStatus,
  };
}

export default useContracts;