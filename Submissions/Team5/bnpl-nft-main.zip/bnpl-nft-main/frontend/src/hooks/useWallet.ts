import { useEffect, useState } from 'react';
import { useAccount, useConnect, useDisconnect, useChainId, useSwitchChain } from 'wagmi';
import { injected } from 'wagmi/connectors';
import { SUPPORTED_CHAINS, DEFAULT_CHAIN } from '../config/constants';

export function useWallet() {
  const account = useAccount();
  const chainId = useChainId();
  const { connectAsync } = useConnect();
  const { disconnectAsync } = useDisconnect();
  const { switchChainAsync } = useSwitchChain();
  const [isWrongNetwork, setIsWrongNetwork] = useState(false);

  useEffect(() => {
    if (account.isConnected && chainId) {
      setIsWrongNetwork(!SUPPORTED_CHAINS.includes(chainId));
    } else {
      setIsWrongNetwork(false);
    }
  }, [chainId, account.isConnected]);

  const connectWallet = async () => {
    try {
      await connectAsync({
        connector: injected()
      });
    } catch (error) {
      console.error('Failed to connect wallet:', error);
      throw error;
    }
  };

  const handleDisconnect = async () => {
    try {
      await disconnectAsync();
    } catch (error) {
      console.error('Failed to disconnect:', error);
    }
  };

  const switchToDefaultNetwork = async () => {
    try {
      await switchChainAsync({
        chainId: DEFAULT_CHAIN
      });
    } catch (error) {
      console.error('Failed to switch network:', error);
    }
  };

  return {
    address: account.address,
    isConnected: account.isConnected,
    isWrongNetwork,
    connectWallet,
    disconnect: handleDisconnect,
    switchToDefaultNetwork,
    currentChain: chainId,
  };
}

export default useWallet;