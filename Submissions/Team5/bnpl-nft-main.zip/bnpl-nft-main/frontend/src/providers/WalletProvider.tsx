import React, { createContext, useState, useContext, ReactNode } from 'react';

// Define the shape of the context
export type WalletContextType = {
  address: string | null;
  isConnected: boolean;
  connectWallet: () => void;
  disconnect: () => void;
};

// Create the context with a default value of undefined
const WalletContext = createContext<WalletContextType | undefined>(undefined);

// Define the WalletProvider component
interface WalletProviderProps {
  children: ReactNode;
}

export const WalletProvider: React.FC<WalletProviderProps> = ({ children }) => {
  const [address, setAddress] = useState<string | null>(null);
  const [isConnected, setIsConnected] = useState<boolean>(false);

  // Connect wallet logic
  const connectWallet = async () => {
    try {
      // Assuming you're using a wallet connector like MetaMask
      if (window.ethereum) {
        // Request access to the user's wallet
        const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
        if (accounts && accounts[0]) {
          setAddress(accounts[0]);
          setIsConnected(true);
        }
      } else {
        alert('Please install a wallet like MetaMask!');
      }
    } catch (error) {
      console.error('Failed to connect wallet:', error);
    }
  };

  // Disconnect wallet logic
  const disconnect = () => {
    setAddress(null);
    setIsConnected(false);
  };

  return (
    <WalletContext.Provider value={{ address, isConnected, connectWallet, disconnect }}>
      {children}
    </WalletContext.Provider>
  );
};

// Custom hook to use the WalletContext
export const useWallet = (): WalletContextType => {
  const context = useContext(WalletContext);
  if (!context) {
    throw new Error('useWallet must be used within WalletProvider');
  }
  return context;
};
