import { PinataSDK } from "pinata";
import type { UploadResponse } from "pinata";

require('dotenv').config();
console.log("PINATA_JWT:", process.env.PINATA_JWT);
console.log("PINATA_GATEWAY:", process.env.PINATA_GATEWAY);


// Use direct Pinata API URL
const PINATA_API_URL = "https://api.pinata.cloud";

// Interface for the response from Pinata
interface PinataFileUploadResponse {
  IpfsHash: string;  // The IPFS hash returned from Pinata
  id: string;
  name: string;
  cid: string;
  size: number;
  [key: string]: any; // Allow additional properties
}

// Type guard to safely check the upload response
export function hasIpfsHash(obj: any): obj is PinataFileUploadResponse {
  return obj && typeof obj.IpfsHash === 'string';
}

// Create a proxy URL constant (points to your local proxy server)
const pinata = new PinataSDK({
  pinataJwt: process.env.PINATA_JWT!,
  pinataGateway: process.env.PINATA_GATEWAY!,
});

// Upload a file to Pinata via the proxy server
export async function uploadFileToIPFS(file: File): Promise<PinataFileUploadResponse> {
  try {
    const formData = new FormData();
    formData.append("file", file);

    const response = await fetch(`${PINATA_API_URL}/pinning/pinFileToIPFS`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.PINATA_JWT}`
      },
      body: formData,
    });

    if (!response.ok) {
      throw new Error(`Upload failed with status: ${response.status}`);
    }

    const upload: PinataFileUploadResponse = await response.json();
    console.log("File uploaded:", upload);

    // Verify the upload response has the expected structure
    if (!hasIpfsHash(upload)) {
      throw new Error("Upload response missing IpfsHash property");
    }

    return upload; // Contains IpfsHash and other details
  } catch (error) {
    console.error("Pinata upload error:", error);
    throw new Error("Failed to upload file to IPFS");
  }
}

export async function pinJSONToIPFS(json: object): Promise<string> {
  const MAX_RETRIES = 3;
  let lastError: Error | null = null;

  // Validate Pinata JWT token
  if (!process.env.PINATA_JWT || !process.env.PINATA_JWT.match(/^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+$/)) {
    throw new Error('Invalid or missing Pinata JWT token. Please check your environment variables.');
  }

  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      // Validate input
      if (!json || typeof json !== 'object') {
        throw new Error('Invalid JSON input');
      }

      // Stringify with BigInt handling
      const jsonString = JSON.stringify(json, (key, value) => {
        if (typeof value === 'bigint') return value.toString();
        // Handle nested BigInts in objects
        if (value && typeof value === 'object') {
          for (const k in value) {
            if (typeof value[k] === 'bigint') {
              value[k] = value[k].toString();
            }
          }
        }
        return value;
      });

      console.debug("Attempt", attempt, "Uploading JSON to Pinata:", jsonString);

      const response = await fetch(`${PINATA_API_URL}/pinning/pinJSONToIPFS`, {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Accept": "application/json",
          "Authorization": `Bearer ${process.env.PINATA_JWT}`
        },
        body: jsonString,
      });

      if (!response.ok) {
        let errorBody = '';
        try {
          errorBody = await response.text();
          console.error(`JSON upload failed with status ${response.status}:`, errorBody);
        } catch (e) {
          console.error(`Failed to read error response body: ${e}`);
        }
        
        // Retry on 5xx errors
        if (response.status >= 500 && response.status < 600 && attempt < MAX_RETRIES) {
          await new Promise(resolve => setTimeout(resolve, 1000 * attempt)); // Exponential backoff
          continue;
        }

        throw new Error(`JSON upload failed with status ${response.status}: ${errorBody}`);
      }

      const upload = await response.json();
      console.debug("Pinata JSON upload response:", upload);

      if (!upload?.IpfsHash) {
        console.error("Pinata upload response missing IpfsHash:", upload);
        throw new Error("Upload response missing IpfsHash property");
      }

      return `ipfs://${upload.IpfsHash}`;
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      console.error(`Attempt ${attempt} failed:`, lastError);
      
      if (attempt < MAX_RETRIES) {
        await new Promise(resolve => setTimeout(resolve, 1000 * attempt)); // Exponential backoff
      }
    }
  }

  throw new Error(`Failed to upload JSON after ${MAX_RETRIES} attempts: ${lastError?.message || 'Unknown error'}`);
}

// Fetch from IPFS using the Pinata Gateway

export async function fetchFromIPFS<T = any>(ipfsHash: string): Promise<T> {
  if (!ipfsHash || ipfsHash.trim() === '') {
    console.warn("Empty IPFS hash provided");
    return {} as T;
  }

  const cleanHash = ipfsHash.replace(/^ipfs:\/\//, "");
  
  // Try public gateways only since your dedicated gateway returns 403
  const publicGateways = [
    'gateway.pinata.cloud',  // This one worked in your logs
    'ipfs.io',
    'dweb.link',
    'cloudflare-ipfs.com'
  ];

  // Try each gateway until we get a successful response
  for (const gateway of publicGateways) {
    try {
      console.debug(`Trying IPFS gateway: ${gateway} for hash: ${cleanHash}`);
      const response = await fetch(`https://${gateway}/ipfs/${cleanHash}`);

      if (response.ok) {
        const contentType = response.headers.get("content-type");
        
        if (contentType?.includes("application/json")) {
          const data = await response.json();
          console.debug(`Successfully fetched JSON from ${gateway}`);
          return data as T;
        } else {
          const blob = await response.blob();
          console.debug(`Successfully fetched non-JSON content from ${gateway}`);
          return blob as unknown as T;
        }
      } else {
        // Log as debug rather than warning to reduce console noise
        console.debug(`Gateway ${gateway} returned status ${response.status}`);
      }
    } catch (error) {
      console.debug(`Failed to fetch from gateway ${gateway}`);
    }
  }

  // If we've tried all gateways and still failed, return empty object
  console.warn("Failed to fetch from all IPFS gateways for hash:", cleanHash);
  return {} as T;
}


// Get a URL for displaying the IPFS content
export function getIPFSUrl(cid: string): string {
  const cleanHash = cid.replace(/^ipfs:\/\//, "");
  return `https://${process.env.PINATA_GATEWAY}/ipfs/${cleanHash}`;
}

export default {
  uploadFileToIPFS,
  pinJSONToIPFS,
  fetchFromIPFS,
  getIPFSUrl,
  hasIpfsHash,
};
