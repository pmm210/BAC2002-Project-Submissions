import { Address } from 'viem';

export const CHAIN_ID = {
  ETHEREUM_SEPOLIA: 11155111,
  ARBITRUM_SEPOLIA: 421614
};

export const CONTRACTS: Record<number, {
  NFT_ESCROW: Address;
  LOAN_MANAGER: Address;
}> = {
  [CHAIN_ID.ETHEREUM_SEPOLIA]: {
    NFT_ESCROW: '0xeeec6ca18cb84d994d7a8f3156e87d720b2971aa' as Address,
    LOAN_MANAGER: '0x610bd53e12b87339ce68e200cc66bfdfe10910d6' as Address
  },
  [CHAIN_ID.ARBITRUM_SEPOLIA]: {
    NFT_ESCROW: '0x507e65bFE0E31EB0aF57b6Bf24288f677fE02579' as Address,
    LOAN_MANAGER: '0x28b7c0cBCB04AC1E7FbA6d099C6FDB0Aa906a880' as Address
  }
};

export const SUPPORTED_CHAINS = [
  CHAIN_ID.ETHEREUM_SEPOLIA,
  CHAIN_ID.ARBITRUM_SEPOLIA
];

// You can change this to your preferred default chain
export const DEFAULT_CHAIN = CHAIN_ID.ETHEREUM_SEPOLIA;

export const PAYMENT_SCHEDULE = {
  MIN_DURATION: 1,
  MAX_DURATION: 12,
  FREQUENCIES: ['weekly', 'bi-weekly', 'monthly'] as const,
  DEFAULT_FREQUENCY: 'monthly' as const,
  DEFAULT_DURATION: 3
};

export const PENALTY_RATE = {
  MIN: 1,
  MAX: 10,
  DEFAULT: 5
};

export const GRACE_PERIOD_DAYS = 3;

export const NFT_STANDARDS = {
  ERC721: 'ERC721',
  ERC1155: 'ERC1155'
} as const;

// Updated NFT Collections with only testnets
export const NFT_COLLECTIONS: Record<number, Array<{
  address: Address;
  standard: typeof NFT_STANDARDS[keyof typeof NFT_STANDARDS];
  name: string;
  symbol: string;
}>> = {
  [CHAIN_ID.ETHEREUM_SEPOLIA]: [
    {
      address: '0xff2C6fa0e5d132Ac1066857aabe3964d317A563F' as Address,
      standard: 'ERC721' as const,
      name: 'MockNFT',
      symbol: 'MNFT'
    },
    {
      address: '0xff2C6fa0e5d132Ac1066857aabe3964d317A563F' as Address,
      standard: 'ERC1155' as const,
      name: 'MockERC1155',
      symbol: 'M1155'
    }
  ],
  [CHAIN_ID.ARBITRUM_SEPOLIA]: [
    {
      address: '0x8e983D104d09715B598be423c06e89B1edcf01c5' as Address,
      standard: 'ERC721' as const,
      name: 'MockNFT',
      symbol: 'MNFT'
    },
    {
      address: '0x8e983D104d09715B598be423c06e89B1edcf01c5' as Address,
      standard: 'ERC1155' as const,
      name: 'MockERC1155',
      symbol: 'M1155'
    }
  ]
};

// Helper function to get collections for the current chain
export const getKnownNFTCollections = (chainId: number = DEFAULT_CHAIN) => {
  return NFT_COLLECTIONS[chainId] || [];
};

// For backward compatibility (can be removed if updating all imports across your app)
export const KNOWN_NFT_COLLECTIONS = getKnownNFTCollections();