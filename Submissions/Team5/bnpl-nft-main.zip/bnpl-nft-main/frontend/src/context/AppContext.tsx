// Import necessary libraries and types
import React, { createContext, useContext, useReducer, useCallback } from 'react';
import { NFTListing, Loan, Transaction, Notification } from '@/types';

// Define the shape of the application state
interface AppState {
  listings: NFTListing[];
  loans: Loan[];
  transactions: Transaction[];
  notifications: Notification[];
  isLoading: boolean;
  error: string | null;
}

// Define action types for the reducer
type AppAction =
  | { type: 'SET_LISTINGS'; payload: NFTListing[] }
  | { type: 'ADD_LISTING'; payload: NFTListing }
  | { type: 'UPDATE_LISTING'; payload: NFTListing }
  | { type: 'REMOVE_LISTING'; payload: string }
  | { type: 'SET_LOANS'; payload: Loan[] }
  | { type: 'ADD_LOAN'; payload: Loan }
  | { type: 'UPDATE_LOAN'; payload: Loan }
  | { type: 'ADD_TRANSACTION'; payload: Transaction }
  | { type: 'UPDATE_TRANSACTION'; payload: Transaction }
  | { type: 'ADD_NOTIFICATION'; payload: Notification }
  | { type: 'REMOVE_NOTIFICATION'; payload: string }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_ERROR'; payload: string | null };

// Define the context type that includes state and actions
interface AppContextType extends AppState {
  addListing: (listing: NFTListing) => void;
  updateListing: (listing: NFTListing) => void;
  removeListing: (listingId: string) => void;
  addLoan: (loan: Loan) => void;
  updateLoan: (loan: Loan) => void;
  addTransaction: (transaction: Transaction) => void;
  updateTransaction: (transaction: Transaction) => void;
  addNotification: (notification: Notification) => void;
  removeNotification: (notificationId: string) => void;
  setLoading: (isLoading: boolean) => void;
  setError: (error: string | null) => void;
  dispatch: React.Dispatch<AppAction>;
}

// Define the initial state of the application
const initialState: AppState = {
  listings: [],
  loans: [],
  transactions: [],
  notifications: [],
  isLoading: false,
  error: null,
};

// Define the reducer function to handle state updates
function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'SET_LISTINGS':
      return { ...state, listings: action.payload };
    case 'ADD_LISTING':
      return { ...state, listings: [...state.listings, action.payload] };
    case 'UPDATE_LISTING':
      return {
        ...state,
        listings: state.listings.map((listing) =>
          listing.id === action.payload.id ? action.payload : listing
        ),
      };
    case 'REMOVE_LISTING':
      return {
        ...state,
        listings: state.listings.filter((listing) => listing.id !== action.payload),
      };
    case 'SET_LOANS':
      return { ...state, loans: action.payload };
    case 'ADD_LOAN':
      return { ...state, loans: [...state.loans, action.payload] };
    case 'UPDATE_LOAN':
      return {
        ...state,
        loans: state.loans.map((loan) =>
          loan.id === action.payload.id ? action.payload : loan
        ),
      };
    case 'ADD_TRANSACTION':
      return {
        ...state,
        transactions: [...state.transactions, action.payload],
      };
    case 'UPDATE_TRANSACTION':
      return {
        ...state,
        transactions: state.transactions.map((tx) =>
          tx.hash === action.payload.hash ? action.payload : tx
        ),
      };
    case 'ADD_NOTIFICATION':
      return {
        ...state,
        notifications: [...state.notifications, action.payload],
      };
    case 'REMOVE_NOTIFICATION':
      return {
        ...state,
        notifications: state.notifications.filter((n) => n.id !== action.payload),
      };
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    case 'SET_ERROR':
      return { ...state, error: action.payload };
    default:
      return state;
  }
}

// Define the AppContext and export it
const AppContext = createContext<AppContextType | undefined>(undefined);

// Define the AppProvider component
export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  const addListing = useCallback((listing: NFTListing) => {
    dispatch({ type: 'ADD_LISTING', payload: listing });
  }, []);

  const updateListing = useCallback((listing: NFTListing) => {
    dispatch({ type: 'UPDATE_LISTING', payload: listing });
  }, []);

  const removeListing = useCallback((listingId: string) => {
    dispatch({ type: 'REMOVE_LISTING', payload: listingId });
  }, []);

  const addLoan = useCallback((loan: Loan) => {
    dispatch({ type: 'ADD_LOAN', payload: loan });
  }, []);

  const updateLoan = useCallback((loan: Loan) => {
    dispatch({ type: 'UPDATE_LOAN', payload: loan });
  }, []);

  const addTransaction = useCallback((transaction: Transaction) => {
    dispatch({ type: 'ADD_TRANSACTION', payload: transaction });
  }, []);

  const updateTransaction = useCallback((transaction: Transaction) => {
    dispatch({ type: 'UPDATE_TRANSACTION', payload: transaction });
  }, []);

  const addNotification = useCallback((notification: Notification) => {
    dispatch({ type: 'ADD_NOTIFICATION', payload: notification });
  }, []);

  const removeNotification = useCallback((notificationId: string) => {
    dispatch({ type: 'REMOVE_NOTIFICATION', payload: notificationId });
  }, []);

  const setLoading = useCallback((isLoading: boolean) => {
    dispatch({ type: 'SET_LOADING', payload: isLoading });
  }, []);

  const setError = useCallback((error: string | null) => {
    dispatch({ type: 'SET_ERROR', payload: error });
  }, []);

  // Define the context value that includes state and actions
  const value = {
    ...state,
    addListing,
    updateListing,
    removeListing,
    addLoan,
    updateLoan,
    addTransaction,
    updateTransaction,
    addNotification,
    removeNotification,
    setLoading,
    setError,
    dispatch,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

// Define the useApp hook
export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}

export default AppContext;
