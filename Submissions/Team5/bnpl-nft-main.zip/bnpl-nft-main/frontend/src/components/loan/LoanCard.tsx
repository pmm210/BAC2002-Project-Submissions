import React from 'react';
import Image from 'next/image';
import { formatEther } from 'ethers';
import { formatDistanceToNow } from 'date-fns';
import { Loan } from '@/types';

interface LoanCardProps {
  loan: Loan;
  onMakePayment: (loan: Loan) => void;
  onPayoffEarly: (loan: Loan) => void;
}

export function LoanCard({ loan, onMakePayment, onPayoffEarly }: LoanCardProps) {
  const isOverdue = new Date() > loan.nextPaymentDue;
  const timeToNextPayment = formatDistanceToNow(loan.nextPaymentDue, { addSuffix: true });

  const getStatusColor = () => {
    switch (loan.status) {
      case 'active':
        return isOverdue ? 'text-red-600' : 'text-green-600';
      case 'completed':
        return 'text-blue-600';
      case 'defaulted':
        return 'text-red-600';
      default:
        return 'text-gray-600';
    }
  };

  const getStatusText = () => {
    switch (loan.status) {
      case 'active':
        return isOverdue ? 'Payment Overdue' : 'Active';
      case 'completed':
        return 'Completed';
      case 'defaulted':
        return 'Defaulted';
      default:
        return 'Unknown';
    }
  };

  return (
    <div className="overflow-hidden bg-white rounded-lg shadow-lg">
      {/* Image container with conditional content */}
      <div className="relative w-full h-48">
        {loan.status === 'completed' ? (
          <div className="w-full h-full flex items-center justify-center bg-blue-50">
            <div className="text-center">
              <div className="text-blue-500 text-4xl mb-2">✓</div>
              <p className="text-blue-700 font-medium">Purchase Complete</p>
            </div>
          </div>
        ) : (
          <Image 
            src={loan.nft.image} 
            alt={loan.nft.title}
            fill
            sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
            style={{ objectFit: 'cover' }}
          />
        )}
      </div>

      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">{loan.nft.title}</h3>
            <p className="text-sm text-gray-500">{loan.nft.collection.name}</p>
          </div>
          <span className={`px-3 py-1 text-sm font-medium rounded-full ${getStatusColor()} bg-opacity-10`}>
            {getStatusText()}
          </span>
        </div>

        {loan.status === 'active' && (
          <>
            <div className="mb-4 space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Next Payment Due:</span>
                <span className={`text-sm font-medium ${isOverdue ? 'text-red-600' : 'text-gray-900'}`}>
                  {timeToNextPayment}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Remaining Balance:</span>
                <span className="text-sm font-medium text-gray-900">
                  {formatEther(loan.remainingBalance)} ETH
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Next Payment Amount:</span>
                <span className="text-sm font-medium text-gray-900">
                  {formatEther(loan.schedule.installmentAmount)} ETH
                </span>
              </div>
              {loan.totalPenalties > 0 && (
                <div className="flex justify-between">
                  <span className="text-sm text-red-600">Total Penalties:</span>
                  <span className="text-sm font-medium text-red-600">
                    {formatEther(loan.totalPenalties)} ETH
                  </span>
                </div>
              )}
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => onMakePayment(loan)}
                className="flex-1 px-4 py-2 text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              >
                Make Payment
              </button>
              <button
                onClick={() => onPayoffEarly(loan)}
                className="flex-1 px-4 py-2 text-blue-600 bg-blue-100 rounded-lg hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              >
                Pay Off Early
              </button>
            </div>
          </>
        )}

        {loan.status === 'completed' && (
          <div className="p-3 mt-4 text-sm text-center text-green-700 bg-green-100 rounded-lg">
            Loan successfully completed! NFT is now in your wallet.
          </div>
        )}

        {loan.status === 'defaulted' && (
          <div className="p-3 mt-4 text-sm text-center text-red-700 bg-red-100 rounded-lg">
            Loan defaulted. NFT returned to seller.
          </div>
        )}
      </div>
    </div>
  );
}

export default LoanCard;