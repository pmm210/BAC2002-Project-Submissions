import React, { useState } from 'react';
import LoanCard from './LoanCard';
import { Loan } from '@/types';
import { formatEther } from 'ethers';

interface LoanListProps {
  loans: Loan[];
  onMakePayment: (loan: Loan) => void;
  onPayoffEarly: (loan: Loan) => void;
}

export function LoanList({ loans, onMakePayment, onPayoffEarly }: LoanListProps) {
  const [filter, setFilter] = useState<'all' | 'active' | 'completed' | 'defaulted'>('all');
  const [sortBy, setSortBy] = useState<'dueDate' | 'remainingBalance'>('dueDate');

  const filteredLoans = loans.filter(loan => {
    if (filter === 'all') return true;
    return loan.status === filter;
  });

  const sortedLoans = [...filteredLoans].sort((a, b) => {
    if (sortBy === 'dueDate') {
      if (a.status !== 'active' || b.status !== 'active') return 0;
      return a.nextPaymentDue.getTime() - b.nextPaymentDue.getTime();
    } else {
      if (a.status !== 'active' || b.status !== 'active') return 0;
      return Number(a.remainingBalance - b.remainingBalance);
    }
  });

  return (
    <div className="space-y-6">
      {/* Filters and Sort Controls */}
      <div className="flex flex-wrap items-center gap-4 p-4 bg-white rounded-lg shadow">
        <div>
          <label className="block mb-1 text-sm font-medium text-gray-700">Status</label>
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value as any)}
            className="px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">All Loans</option>
            <option value="active">Active</option>
            <option value="completed">Completed</option>
            <option value="defaulted">Defaulted</option>
          </select>
        </div>

        <div>
          <label className="block mb-1 text-sm font-medium text-gray-700">Sort By</label>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="dueDate">Next Payment Due</option>
            <option value="remainingBalance">Remaining Balance</option>
          </select>
        </div>

        <div className="flex-1 text-right">
          <p className="text-sm text-gray-600">
            Showing {filteredLoans.length} of {loans.length} loans
          </p>
        </div>
      </div>

      {/* Loans Grid */}
      {sortedLoans.length === 0 ? (
        <div className="p-8 text-center bg-white rounded-lg shadow">
          <p className="text-lg text-gray-500">No loans found</p>
          {filter !== 'all' && (
            <button
              onClick={() => setFilter('all')}
              className="mt-2 text-sm text-blue-600 hover:text-blue-800"
            >
              View all loans
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {sortedLoans.map((loan) => (
            <div className="min-h-[400px]" key={loan.id}>
              <LoanCard
                loan={loan}
                onMakePayment={onMakePayment}
                onPayoffEarly={onPayoffEarly}
              />
            </div>
          ))}
        </div>
      )}

      {/* Summary Section for Active Loans */}
      {filter === 'active' && (
        <div className="p-4 bg-white rounded-lg shadow">
          <h3 className="mb-3 text-lg font-semibold">Active Loans Summary</h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div className="p-3 bg-blue-50 rounded-lg">
              <p className="text-sm text-blue-600">Total Active Loans</p>
              <p className="text-2xl font-semibold text-blue-700">
                {loans.filter(l => l.status === 'active').length}
              </p>
            </div>
            <div className="p-3 bg-green-50 rounded-lg">
              <p className="text-sm text-green-600">Total Value Locked</p>
              <p className="text-2xl font-semibold text-green-700">
                {formatEther(
                  loans
                    .filter(l => l.status === 'active')
                    .reduce((acc, loan) => acc + loan.remainingBalance, BigInt(0))
                )} ETH
              </p>
            </div>
            <div className="p-3 bg-yellow-50 rounded-lg">
              <p className="text-sm text-yellow-600">Upcoming Payments (7 days)</p>
              <p className="text-2xl font-semibold text-yellow-700">
                {loans.filter(l => 
                  l.status === 'active' && 
                  l.nextPaymentDue.getTime() - Date.now() <= 7 * 24 * 60 * 60 * 1000
                ).length}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default LoanList;
