import React, { useEffect, useState } from 'react';
import { formatDistanceToNow } from 'date-fns';

interface DebugInfo {
  loanId?: string | number;
  currentTimeLocal?: string;
  currentTimeMs?: number;
  nextPaymentDueRaw?: number;
  nextPaymentDueFormatted?: string;
  nextPaymentDueMs?: number;
  gracePeriodEndFormatted?: string;
  gracePeriodEndMs?: number;
  isOverdue?: boolean;
  isPastGracePeriod?: boolean;
  shouldApplyPenalty?: boolean;
  totalPenalties?: string;
  penaltyRate?: number | string;
  blockchainTimestamp?: string;
}

interface LoanType {
  id?: string | number;
  nextPaymentDue?: number;
  totalPenalties?: bigint | number | string;
  penaltyPercentage?: number;
  schedule?: {
    penaltyRate?: number;
  };
}

interface ContractType {
  provider?: {
    getBlockNumber: () => Promise<number>;
    getBlock: (blockNumber: number) => Promise<{timestamp: number}>;
  };
}

interface LoanPenaltyDebuggerProps {
  loan?: LoanType;
  contract?: ContractType;
}

const LoanPenaltyDebugger: React.FC<LoanPenaltyDebuggerProps> = ({ loan, contract }) => {
  const [currentTime, setCurrentTime] = useState<Date>(new Date());
  const [paymentDueDate, setPaymentDueDate] = useState<Date | null>(null);
  const [gracePeriodEnd, setGracePeriodEnd] = useState<Date | null>(null);
  const [gracePeriod] = useState<number>(3 * 24 * 60 * 60 * 1000); // 3 days in milliseconds
  const [debugInfo, setDebugInfo] = useState<DebugInfo>({});
  
  useEffect(() => {
    // Update current time every second
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    
    // Clean up timer
    return () => clearInterval(timer);
  }, []);
  
  useEffect(() => {
    async function fetchLoanDetails() {
      try {
        if (!loan || !loan.nextPaymentDue) return;
        
        // Convert blockchain timestamp to JavaScript Date
        // Note: blockchain timestamps are in seconds, JS uses milliseconds
        const nextPaymentDue = new Date(Number(loan.nextPaymentDue) * 1000);
        setPaymentDueDate(nextPaymentDue);
        
        // Calculate grace period end
        const graceEnd = new Date(nextPaymentDue.getTime() + gracePeriod);
        setGracePeriodEnd(graceEnd);
        
        // Get current block timestamp if possible
        let blockTimestamp: number | null = null;
        if (contract && contract.provider) {
          const blockNumber = await contract.provider.getBlockNumber();
          const block = await contract.provider.getBlock(blockNumber);
          blockTimestamp = block.timestamp;
        }
        
        // Debug information
        setDebugInfo({
          loanId: loan.id,
          currentTimeLocal: currentTime.toString(),
          currentTimeMs: currentTime.getTime(),
          nextPaymentDueRaw: Number(loan.nextPaymentDue),
          nextPaymentDueFormatted: nextPaymentDue.toString(),
          nextPaymentDueMs: nextPaymentDue.getTime(),
          gracePeriodEndFormatted: graceEnd.toString(),
          gracePeriodEndMs: graceEnd.getTime(),
          isOverdue: currentTime > nextPaymentDue,
          isPastGracePeriod: currentTime > graceEnd,
          shouldApplyPenalty: currentTime > graceEnd,
          totalPenalties: loan.totalPenalties?.toString() || '0',
          penaltyRate: loan.penaltyPercentage || loan.schedule?.penaltyRate || '?',
          blockchainTimestamp: blockTimestamp ? new Date(blockTimestamp * 1000).toString() : 'Not available',
        });
      } catch (error) {
        console.error("Error fetching loan details:", error);
      }
    }
    
    fetchLoanDetails();
  }, [loan, currentTime, contract, gracePeriod]);
  
  // Determine status styles
  const getStatusClass = (isTrue: boolean | undefined): string => {
    return isTrue 
      ? "bg-red-100 text-red-800" 
      : "bg-green-100 text-green-800";
  }

  if (!loan || !paymentDueDate) {
    return <div className="p-4 bg-yellow-100 rounded text-black">Loading loan details...</div>;
  }

  return (
    <div className="p-4 border rounded-lg bg-gray-50 text-black">
      <h2 className="text-lg font-bold mb-4 text-black">Loan Penalty Debugger</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div className="p-3 bg-blue-50 rounded">
          <p className="font-medium text-black">Current Time:</p>
          <p className="text-black">{currentTime.toLocaleString()}</p>
        </div>
        
        <div className="p-3 bg-blue-50 rounded">
          <p className="font-medium text-black">Next Payment Due:</p>
          <p className="text-black">{paymentDueDate.toLocaleString()}</p>
          <p className="text-sm text-black">
            {formatDistanceToNow(paymentDueDate, { addSuffix: true })}
          </p>
        </div>
        
        <div className="p-3 bg-blue-50 rounded">
          <p className="font-medium text-black">Grace Period Ends:</p>
          <p className="text-black">{gracePeriodEnd?.toLocaleString()}</p>
          <p className="text-sm text-black">
            {gracePeriodEnd && formatDistanceToNow(gracePeriodEnd, { addSuffix: true })}
          </p>
        </div>
        
        <div className="p-3 bg-blue-50 rounded">
          <p className="font-medium text-black">Penalty Rate:</p>
          <p className="text-black">{debugInfo.penaltyRate}%</p>
          <p className="font-medium mt-2 text-black">Current Penalties:</p>
          <p className="text-black">{debugInfo.totalPenalties || '0'}</p>
        </div>
      </div>
      
      <div className="flex flex-wrap gap-2 mb-4">
        <div className={`px-3 py-1 rounded-full text-sm ${getStatusClass(debugInfo.isOverdue)}`}>
          {debugInfo.isOverdue ? "Payment Overdue" : "Payment Not Overdue"}
        </div>
        
        <div className={`px-3 py-1 rounded-full text-sm ${getStatusClass(debugInfo.isPastGracePeriod)}`}>
          {debugInfo.isPastGracePeriod ? "Past Grace Period" : "Within Grace Period"}
        </div>
        
        <div className={`px-3 py-1 rounded-full text-sm ${getStatusClass(debugInfo.shouldApplyPenalty)}`}>
          {debugInfo.shouldApplyPenalty ? "Should Apply Penalty" : "Should Not Apply Penalty"}
        </div>
      </div>
      
      <div className="mt-4">
        <h3 className="font-medium mb-2 text-black">Debug Information:</h3>
        <pre className="p-3 bg-gray-100 text-black rounded text-xs overflow-x-auto border border-gray-300">
          {JSON.stringify(debugInfo, null, 2)}
        </pre>
      </div>
    </div>
  );
};

export default LoanPenaltyDebugger;