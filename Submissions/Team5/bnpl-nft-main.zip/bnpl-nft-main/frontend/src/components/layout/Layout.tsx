import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import WalletButton from '../wallet/WalletButton';
import { useWallet } from '@/hooks/useWallet';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout = React.memo(({ children }: LayoutProps) => {
  const pathname = usePathname();
  const { isConnected, isLoading } = useWallet();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const navigation = [
    { name: 'Marketplace', href: '/' },
    { name: 'My Loans', href: '/my-loans' },
    { name: 'Sell NFTs', href: '/seller' },
  ];

  const renderContent = () => {
    if (!mounted || isLoading) {
      return (
        <div className="flex flex-col items-center justify-center p-8 text-center bg-white rounded-lg shadow">
          <h2 className="mb-4 text-2xl font-semibold text-gray-900">Loading Wallet...</h2>
        </div>
      );
    }

    if (!isConnected) {
      return (
        <div className="flex flex-col items-center justify-center p-8 text-center bg-white rounded-lg shadow">
          <h2 className="mb-4 text-2xl font-semibold text-gray-900">Connect Your Wallet</h2>
          <p className="mb-6 text-gray-600">
            Please connect your wallet to access the BNPL NFT marketplace.
          </p>
          <WalletButton />
        </div>
      );
    }

    return children;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow">
        <div className="px-4 mx-auto max-w-7xl sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex-shrink-0">
              <Link href="/" className="text-xl font-bold text-blue-600">
                BNPL NFT
              </Link>
            </div>
            <nav className="hidden md:flex md:space-x-8">
              {navigation.map((item) => {
                const isActive = pathname === item.href;
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={`inline-flex items-center px-1 pt-1 text-sm font-medium ${
                      isActive
                        ? 'text-blue-600 border-b-2 border-blue-600'
                        : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }`}
                  >
                    {item.name}
                  </Link>
                );
              })}
            </nav>
            <div className="flex items-center">
              <WalletButton />
            </div>
          </div>
        </div>
      </header>
      <div className="sm:hidden">
        <div className="px-2 pt-2 pb-3 space-y-1">
          {navigation.map((item) => {
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.name}
                href={item.href}
                className={`block px-3 py-2 text-base font-medium rounded-md ${
                  isActive
                    ? 'text-blue-600 bg-blue-50'
                    : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                }`}
              >
                {item.name}
              </Link>
            );
          })}
        </div>
      </div>
      <main className="py-10">
        <div className="px-4 mx-auto max-w-7xl sm:px-6 lg:px-8">{renderContent()}</div>
      </main>
      <footer className="bg-white">
        <div className="px-4 py-6 mx-auto max-w-7xl sm:px-6 lg:px-8">
          <div className="flex justify-between">
            <p className="text-sm text-gray-500">
              © {new Date().getFullYear()} BNPL NFT. All rights reserved.
            </p>
            <div className="flex space-x-6">
              <a
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-gray-500"
              >
                GitHub
              </a>
              <a
                href="https://docs.example.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-gray-500"
              >
                Documentation
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
});

Layout.displayName = 'Layout';
export default Layout;