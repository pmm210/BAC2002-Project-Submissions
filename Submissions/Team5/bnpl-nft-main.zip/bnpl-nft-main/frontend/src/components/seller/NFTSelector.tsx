import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { NFT, ListingHistoryItem } from '@/types';

interface NFTSelectorProps {
  nfts: NFT[];
  onSelect: (nft: NFT) => void;
  isLoading?: boolean;
}

export function NFTSelector({ nfts, onSelect, isLoading = false }: NFTSelectorProps) {

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCollection, setSelectedCollection] = useState<string>('');
  const [isSearching, setIsSearching] = useState(false);

  const collections = [...new Set(nfts.map(nft => nft.collection.name))];

  const filteredNFTs = nfts.filter(nft => {
     const matchesSearch = 
       nft.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
       nft.tokenId.toString().includes(searchTerm) ||
       nft.collection.name.toLowerCase().includes(searchTerm.toLowerCase());
    
     const matchesCollection = !selectedCollection || nft.collection.name === selectedCollection;

     return matchesSearch && matchesCollection;
  });

  return (
    <div className="space-y-6">
      {/* Search and Filter Controls */}
      <div className="flex flex-col gap-4 p-4 bg-white rounded-lg shadow sm:flex-row sm:items-center">
        <div className="flex-1">
          <label htmlFor="search" className="sr-only">
            Search NFTs
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <svg
                className="w-5 h-5 text-gray-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                />
              </svg>
            </div>
            <input
              type="search"
              id="search"
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              placeholder="Search by name, token ID, or collection..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        <div className="sm:w-64">
          <label htmlFor="collection" className="sr-only">
            Filter by Collection
          </label>
          <select
            id="collection"
            className="block w-full py-2 pl-3 pr-10 text-base border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
            value={selectedCollection}
            onChange={(e) => setSelectedCollection(e.target.value)}
          >
            <option value="">All Collections</option>
            {collections.map((collection) => (
              <option key={collection} value={collection}>
                {collection}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* NFT Grid and Refresh Button */}
      <div className="flex justify-end mb-4">
        <button
          onClick={() => onSelect({} as NFT)} // Triggers refetch in parent
          disabled={isLoading}
          className="flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? (
            <>
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Refreshing...
            </>
          ) : (
            <>
              <svg className="-ml-1 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
              Refresh NFTs
            </>
          )}
        </button>
      </div>

      {isLoading ? (
        <div className="p-8 text-center bg-white rounded-lg shadow">
          <p className="text-lg text-gray-500">Loading your NFTs...</p>
          <div className="mt-4 flex justify-center">
            <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-500"></div>
          </div>
        </div>
      ) : filteredNFTs.length === 0 ? (
        <div className="p-8 text-center bg-white rounded-lg shadow">
          <p className="text-lg text-gray-500">No NFTs found in your wallet</p>
          {(searchTerm || selectedCollection) && (
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedCollection('');
              }}
              className="mt-2 text-sm text-blue-600 hover:text-blue-800"
            >
              Clear filters
            </button>
          )}
          <div className="mt-6 pt-6 border-t border-gray-200">
            <p className="mb-4 text-lg text-gray-500">
              Please make sure your wallet is connected and contains NFTs.
            </p>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filteredNFTs.map((nft) => (
            <div
              key={`${nft.contractAddress}-${nft.tokenId}`}
              className="overflow-hidden bg-white rounded-lg shadow transition-shadow cursor-pointer hover:shadow-md"
              onClick={() => onSelect(nft)}
            >
              <div className="relative w-full pt-[100%]">
                <Image
                  src={nft.image}
                  alt={nft.title}
                  layout="fill"
                  objectFit="cover"
                />
              </div>
              <div className="p-4">
                <h3 className="text-lg font-medium text-gray-900 truncate">
                  {nft.title}
                </h3>
                <p className="text-sm text-gray-500">{nft.collection.name}</p>
                <p className="text-sm text-gray-500">Token ID: {nft.tokenId.toString()}</p>

                {nft.listingHistory && nft.listingHistory.length > 0 && (
                  <div className="mt-2 pt-2 border-t">
                    <p className="text-sm font-medium text-gray-700">Previous Listings</p>
                    <div className="mt-1 space-y-1">
                      {nft.listingHistory.slice(0, 2).map((listing: ListingHistoryItem, index: number) => (
                        <div key={index} className="flex justify-between text-sm">
                          <span className="text-gray-500">
                            {new Date(listing.timestamp).toLocaleDateString()}
                          </span>
                          <span className="font-medium text-gray-900">
                            {listing.price} ETH
                          </span>
                        </div>
                      ))}
                      {nft.listingHistory.length > 2 && (
                        <p className="text-sm text-gray-500">
                          +{nft.listingHistory.length - 2} more listings
                        </p>
                      )}
                    </div>
                  </div>
                )}

                <button
                  className="w-full mt-4 px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelect(nft);
                  }}
                >
                  List NFT
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default NFTSelector;
