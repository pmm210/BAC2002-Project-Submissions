import React, { useState, useEffect } from 'react';
import { useWallet } from '@/hooks/useWallet';
import useContracts, { LoanStatus } from '@/hooks/useContracts';
import { formatEther } from 'viem';

// Define the interface for our completed loan data
interface CompletedLoan {
  loanId: string;
  status: string;
  formattedPrice: string;
  buyer: string;
}

export function CompletedListings() {
  const { address } = useWallet();
  const { getLoan, checkEscrowHasLoan } = useContracts();
  const [completedLoans, setCompletedLoans] = useState<CompletedLoan[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [hasInitialized, setHasInitialized] = useState(false);

  // Fetch data only once when the component mounts
  useEffect(() => {
    // Prevent multiple fetches
    if (hasInitialized || !address) return;
    
    const fetchData = async () => {
      try {
        setIsLoading(true);
        
        // We'll only check loans 1, 2, and 3 based on your logs
        const loanIds = [1, 2, 3];
        const fetchedLoans: CompletedLoan[] = [];
        
        for (const id of loanIds) {
          const loanId = BigInt(id);
          
          try {
            // Check if this loan exists
            const hasLoan = await checkEscrowHasLoan(loanId);
            if (!hasLoan) continue;
            
            // Get loan details
            const loan = await getLoan(loanId);
            
            // Checking if the loan status is 1 (COMPLETED)
            // And if the current user is the seller
            if (loan.status === 1 && loan.seller.toLowerCase() === address.toLowerCase()) {
              fetchedLoans.push({
                loanId: loanId.toString(),
                status: "COMPLETED",
                formattedPrice: formatEther(loan.totalPrice),
                buyer: loan.buyer
              });
            }
          } catch (error) {
            console.warn(`Error fetching loan ${id}:`, error);
          }
        }
        
        // Update state only once with all the loans
        setCompletedLoans(fetchedLoans);
      } catch (error) {
        console.error('Error fetching completed loans:', error);
      } finally {
        setIsLoading(false);
        setHasInitialized(true);
      }
    };
    
    fetchData();
  }, [address, getLoan, checkEscrowHasLoan, hasInitialized]);

  if (isLoading) {
    return (
      <div className="flex justify-center py-8">
        <p className="text-gray-500">Loading completed listings...</p>
      </div>
    );
  }

  if (completedLoans.length === 0) {
    return (
      <div className="text-center py-8 border rounded-lg">
        <p className="text-gray-500">You don't have any completed listings yet.</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Loan ID
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Status
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Total Price
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Buyer
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {completedLoans.map((loan) => (
            <tr key={loan.loanId}>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                {loan.loanId}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm">
                <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                  {loan.status}
                </span>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {loan.formattedPrice} ETH
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {loan.buyer.slice(0, 6)}...{loan.buyer.slice(-4)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}