import React, { useState } from 'react';
import Image from 'next/image';
import { formatEther } from 'ethers';
import { format } from 'date-fns';
import { NFTListing } from '@/types';

interface ListingManagerProps {
  listings: NFTListing[];
  onDelist: (listing: NFTListing) => void;
}

type ListingStatus = 'all' | 'available' | 'in_progress' | 'completed' | 'delisted';
type SortField = 'date' | 'price' | 'status' | 'activity';
type SortDirection = 'asc' | 'desc';

export function ListingManager({ listings, onDelist }: ListingManagerProps) {
  const [status, setStatus] = useState<ListingStatus>('all');
  const [sortField, setSortField] = useState<SortField>('date');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredListings = listings.filter(listing => {
    const matchesStatus =
      status === 'all' ||
      (status === 'available' && listing.status === 'available') ||
      (status === 'in_progress' && listing.status === 'in_progress') ||
      (status === 'completed' && listing.status === 'completed') ||
      (status === 'delisted' && listing.status === 'delisted');
  
    const matchesSearch = searchTerm === '' ||
      listing.nft.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      listing.nft.collection.name.toLowerCase().includes(searchTerm.toLowerCase());
  
    return matchesStatus && matchesSearch;
  });

  const sortedListings = [...filteredListings].sort((a, b) => {
    const multiplier = sortDirection === 'asc' ? 1 : -1;

    switch (sortField) {
      case 'date':
        return (a.createdAt.getTime() - b.createdAt.getTime()) * multiplier;
      case 'price':
        return (Number(a.totalPrice) - Number(b.totalPrice)) * multiplier;
      case 'status':
        return (getStatusPriority(a) - getStatusPriority(b)) * multiplier;
      case 'activity':
        return ((a.viewCount || 0) - (b.viewCount || 0)) * multiplier;
      default:
        return 0;
    }
  });

  function getStatusPriority(listing: NFTListing): number {
    switch (listing.status) {
      case 'delisted': return 0;
      case 'completed': return 1;
      case 'in_progress': return 2;
      case 'available': return 3;
      default: return 4;
    }
  }

  function getStatusBadge(listing: NFTListing) {
    switch (listing.status) {
      case 'delisted':
        return <span className="px-2 py-1 text-sm font-medium text-gray-600 bg-gray-100 rounded-full">Delisted</span>;
      case 'completed':
        return <span className="px-2 py-1 text-sm font-medium text-green-600 bg-green-100 rounded-full">Completed</span>;
      case 'in_progress':
        return <span className="px-2 py-1 text-sm font-medium text-blue-600 bg-blue-100 rounded-full">In Progress</span>;
      case 'available':
        return <span className="px-2 py-1 text-sm font-medium text-yellow-600 bg-yellow-100 rounded-full">Available</span>;
      default:
        return null;
    }
  }

  return (
    <div className="space-y-6">
      {/* Filters and Search */}
      <div className="p-4 bg-white rounded-lg shadow">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
          <div className="flex-1">
            <input
              type="text"
              placeholder="Search listings..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="flex gap-4">
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as ListingStatus)}
              className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Listings</option>
              <option value="available">Available</option>
              <option value="in_progress">In Progress</option>
              <option value="completed">Completed</option>
              <option value="delisted">Delisted</option>
            </select>
            <select
              value={sortField}
              onChange={(e) => setSortField(e.target.value as SortField)}
              className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="date">List Date</option>
              <option value="price">Price</option>
              <option value="status">Status</option>
              <option value="activity">Buyer Activity</option>
            </select>
            <button
              onClick={() => setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc')}
              className="p-2 text-gray-600 border rounded-lg hover:bg-gray-50"
            >
              {sortDirection === 'asc' ? '↑' : '↓'}
            </button>
          </div>
        </div>
      </div>

      {/* Listings Table */}
      <div className="overflow-hidden bg-white rounded-lg shadow">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                NFT
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Price
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Listed Date
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Activity
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {sortedListings.map((listing) => (
              <tr key={`${listing.nft.contractAddress}-${listing.nft.tokenId}`}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="relative flex-shrink-0 w-10 h-10">
                      <Image
                        src={listing.nft.image}
                        alt={listing.nft.title}
                        layout="fill"
                        className="rounded-full"
                      />
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-900">
                        {listing.nft.title}
                      </div>
                      <div className="text-sm text-gray-500">
                        {listing.nft.collection.name}
                      </div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">
                    {formatEther(listing.totalPrice)} ETH
                  </div>
                  {listing.activeLoan && listing.remainingBalance !== undefined && (
                    <div className="text-sm text-gray-500">
                      {formatEther(listing.remainingBalance)} ETH remaining
                    </div>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {getStatusBadge(listing)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {format(listing.createdAt, 'MMM d, yyyy')}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">
                    {listing.viewCount || 0} views
                  </div>
                  {listing.lastViewed && (
                    <div className="text-sm text-gray-500">
                      Last viewed {format(listing.lastViewed, 'MMM d')}
                    </div>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  {!listing.activeLoan && !listing.isCompleted && (
                    <>
                      <button
                        onClick={() => onDelist(listing)}
                        className="text-red-600 hover:text-red-900"
                      >
                        Delist
                      </button>
                    </>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {sortedListings.length === 0 && (
          <div className="p-8 text-center">
            <p className="text-gray-500">No listings found</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default ListingManager;
