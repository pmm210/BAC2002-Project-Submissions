import React, { useState } from 'react';
import Image from 'next/image';
import { parseEther } from 'viem'; // Changed from ethers to viem
import { NFT, PaymentSchedule } from '@/types';

interface ListingFormProps {
  nft: NFT;
  onSubmit: (data: ListingFormData) => Promise<void>;
  onCancel: () => void;
}

export interface ListingFormData {
  title: string;
  description: string;
  totalPrice: bigint;
  allowedDurations: number[];
  allowedFrequencies: string[];
  penaltyRate: number;
  listingDuration: number;
  buyerRequirements: {
    minEthBalance: bigint;
    minTransactionCount: number;
  };
}

export function ListingForm({ nft, onSubmit, onCancel }: ListingFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState<ListingFormData>({
    title: nft.title,
    description: '',
    totalPrice: BigInt(0),
    allowedDurations: [3],
    allowedFrequencies: ['monthly'],
    penaltyRate: 5,
    listingDuration: 30,
    buyerRequirements: {
      minEthBalance: parseEther('0.1'),
      minTransactionCount: 5,
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setIsSubmitting(true);
      setError(null);
      await onSubmit(formData);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create listing');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleDurationToggle = (duration: number) => {
    setFormData((prev) => ({
      ...prev,
      allowedDurations: prev.allowedDurations.includes(duration)
        ? prev.allowedDurations.filter((d) => d !== duration)
        : [...prev.allowedDurations, duration].sort((a, b) => a - b),
    }));
  };

  const handleFrequencyToggle = (frequency: string) => {
    setFormData((prev) => ({
      ...prev,
      allowedFrequencies: prev.allowedFrequencies.includes(frequency)
        ? prev.allowedFrequencies.filter((f) => f !== frequency)
        : [...prev.allowedFrequencies, frequency],
    }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* NFT Preview */}
      <div className="p-4 bg-gray-50 rounded-lg">
        <div className="flex items-start gap-4">
          <div className="relative w-32 h-32 overflow-hidden rounded-lg">
            <Image
              src={nft.image}
              alt={nft.title}
              layout="fill"
              objectFit="cover"
            />
          </div>
          <div>
            <h3 className="font-medium">{nft.title}</h3>
            <p className="text-sm text-gray-500">{nft.collection.name}</p>
            <p className="text-sm text-gray-500">Token ID: {nft.tokenId}</p>
          </div>
        </div>
      </div>

      {/* Basic Details */}
      <div className="space-y-4">
        <div>
          <label className="block mb-1 text-sm font-medium text-gray-700">
            Listing Title
          </label>
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleInputChange}
            className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-black"
            required
          />
        </div>

        <div>
          <label className="block mb-1 text-sm font-medium text-gray-700">
            Total Price (ETH)
          </label>
          <input
            type="number"
            name="totalPrice"
            value={Number(formData.totalPrice) / 1e18}
            onChange={(e) => setFormData(prev => ({
              ...prev,
              totalPrice: parseEther(e.target.value || '0')
            }))}
            className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-black"
            min="0"
            step="0.001"
            required
          />
        </div>
      </div>

      {/* Payment Schedule Options */}
      <div className="space-y-4">
        <h4 className="font-medium">Payment Schedule Options</h4>
        
        <div>
          <label className="block mb-2 text-sm font-medium text-gray-700">
            Allowed Duration (months)
          </label>
          <div className="flex gap-2">
            {[3].map((duration) => (
              <button
                key={duration}
                type="button"
                onClick={() => handleDurationToggle(duration)}
                className={`px-3 py-1 text-sm rounded-full ${
                  formData.allowedDurations.includes(duration)
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {duration}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block mb-2 text-sm font-medium text-gray-700">
            Payment Frequency
          </label>
          <div className="flex gap-2">
            {['monthly'].map((frequency) => (
              <button
                key={frequency}
                type="button"
                onClick={() => handleFrequencyToggle(frequency)}
                className={`px-3 py-1 text-sm rounded-full ${
                  formData.allowedFrequencies.includes(frequency)
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {frequency.charAt(0).toUpperCase() + frequency.slice(1)}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block mb-1 text-sm font-medium text-gray-700">
            Penalty Rate (%)
          </label>
          <input
            type="number"
            name="penaltyRate"
            value={formData.penaltyRate}
            onChange={handleInputChange}
            className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-black"
            min="0"
            max="10"
            required
          />
          <p className="mt-1 text-sm text-gray-500">
            Maximum penalty rate is 10% of the remaining balance
          </p>
        </div>
      </div>

      {error && (
        <div className="p-3 text-sm text-red-600 bg-red-50 rounded-lg">
          {error}
        </div>
      )}

      <div className="flex gap-4">
        <button
          type="submit"
          disabled={isSubmitting}
          className="flex-1 px-4 py-2 text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50"
        >
          {isSubmitting ? 'Creating Listing...' : 'Create Listing'}
        </button>
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2"
        >
          Cancel
        </button>
      </div>
    </form>
  );
}

export default ListingForm;
