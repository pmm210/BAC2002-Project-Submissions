import React, { useState, useEffect } from 'react';
import { useWallet } from '@/hooks/useWallet';
import { useApp } from '@/context/AppContext';
import useContracts from '@/hooks/useContracts';
import { formatEther } from 'viem';
import { usePublicClient, useWalletClient } from 'wagmi';
import type { Transaction } from '@/types';

export function WithdrawFunds() {
  const { address } = useWallet();
  const { addTransaction, updateTransaction, addNotification, setError } = useApp();
  const { loanManager } = useContracts();
  // Use wagmi hooks directly instead of getting them from useContracts
  const publicClient = usePublicClient();
  const { data: walletClient } = useWalletClient();
  
  const [pendingWithdrawal, setPendingWithdrawal] = useState<bigint>(BigInt(0));
  const [isLoading, setIsLoading] = useState(true);
  const [isWithdrawing, setIsWithdrawing] = useState(false);
  const [currentTransaction, setCurrentTransaction] = useState<Transaction | null>(null);

  useEffect(() => {
    const fetchPendingWithdrawal = async () => {
      if (!address || !loanManager || !publicClient) return;
      
      try {
        setIsLoading(true);
        
        // Call the pendingWithdrawals mapping in the contract
        const amount = await publicClient.readContract({
          address: loanManager.address,
          abi: loanManager.abi,
          functionName: 'pendingWithdrawals',
          args: [address]
        });
        
        setPendingWithdrawal(amount as bigint);
      } catch (error) {
        console.error('Error fetching pending withdrawal:', error);
        setError('Failed to fetch pending withdrawals');
      } finally {
        setIsLoading(false);
      }
    };

    fetchPendingWithdrawal();
    
    // Set up an interval to refresh the pending withdrawal amount
    const intervalId = setInterval(fetchPendingWithdrawal, 30000); // Every 30 seconds
    
    return () => clearInterval(intervalId);
  }, [address, loanManager, publicClient, setError]);

  const handleWithdraw = async () => {
    if (!address || !loanManager || !publicClient || !walletClient || pendingWithdrawal <= BigInt(0)) {
      return;
    }
    
    try {
      setIsWithdrawing(true);
      
      // Create a transaction object that conforms to your Transaction interface
      const transaction: Transaction = {
        hash: '',
        type: 'list', // Using 'list' since 'withdraw' is not in your current types
        status: 'pending',
        timestamp: new Date(),
        data: {
          nft: {
            contractAddress: loanManager.address,
            tokenId: '0',
            standard: 'ERC721',
            title: 'Withdraw Funds',
            description: `Withdraw ${formatEther(pendingWithdrawal)} ETH`,
            image: '',
            owner: address,
            collection: {  // Make sure to include the collection property
              name: 'Withdrawals',
              symbol: 'WDRW'
            }
          },
          amount: pendingWithdrawal
        },
      };
      
      setCurrentTransaction(transaction);
      addTransaction(transaction);
      
      // Call the withdraw function on the contract
      const { request } = await publicClient.simulateContract({
        address: loanManager.address,
        abi: loanManager.abi,
        functionName: 'withdraw',
        account: address
      });
      
      const hash = await walletClient.writeContract(request);
      
      // Update the transaction with the hash
      const updatedTransaction: Transaction = {
        ...transaction,
        hash,
      };
      
      setCurrentTransaction(updatedTransaction);
      updateTransaction(updatedTransaction);
      
      // Wait for the transaction receipt
      const receipt = await publicClient.waitForTransactionReceipt({ hash });
      
      if (receipt.status === 'success') {
        // Update the transaction
        const successTransaction: Transaction = {
          ...updatedTransaction,
          status: 'success',
        };
        
        setCurrentTransaction(successTransaction);
        updateTransaction(successTransaction);
        
        // Reset the pending withdrawal amount
        setPendingWithdrawal(BigInt(0));
        
        // Show a success notification
        addNotification({
          id: Date.now().toString(),
          type: 'success',
          title: 'Withdrawal Successful',
          message: `Successfully withdrew ${formatEther(pendingWithdrawal)} ETH`,
          autoHide: true,
          timestamp: new Date(),
        });
      } else {
        throw new Error('Transaction failed');
      }
    } catch (error: any) {
      console.error('Error withdrawing funds:', error);
      
      // Make sure we have a current transaction to update
      if (currentTransaction) {
        const failedTransaction: Transaction = {
          ...currentTransaction,
          status: 'failed',
          error: error.message || 'Failed to withdraw funds',
        };
        
        updateTransaction(failedTransaction);
      }
      
      setError(error.message || 'Failed to withdraw funds');
      
      addNotification({
        id: Date.now().toString(),
        type: 'error',
        title: 'Withdrawal Failed',
        message: error.message || 'Failed to withdraw funds',
        autoHide: true,
        timestamp: new Date(),
      });
    } finally {
      setIsWithdrawing(false);
    }
  };

  return (
    <div className="bg-white shadow overflow-hidden sm:rounded-lg">
      <div className="px-4 py-5 sm:p-6">
        <h3 className="text-lg leading-6 font-medium text-gray-900">Available Funds</h3>
        <div className="mt-2 max-w-xl text-sm text-gray-500">
          <p>Funds from completed sales and penalties are available for withdrawal.</p>
        </div>
        
        <div className="mt-5">
          {isLoading ? (
            <p className="text-gray-500">Loading available funds...</p>
          ) : (
            <div className="rounded-md bg-gray-50 px-6 py-5 sm:flex sm:items-center sm:justify-between">
              <div className="sm:flex sm:items-center">
                <div className="text-sm">
                  <p className="font-medium text-gray-500">Available for withdrawal</p>
                  <p className="text-3xl font-bold text-gray-900 mt-1">{formatEther(pendingWithdrawal)} ETH</p>
                </div>
              </div>
              
              <div className="mt-4 sm:mt-0">
                <button
                  onClick={handleWithdraw}
                  disabled={isWithdrawing || pendingWithdrawal <= BigInt(0)}
                  className={`inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white ${
                    pendingWithdrawal > BigInt(0) && !isWithdrawing
                      ? 'bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500'
                      : 'bg-gray-400 cursor-not-allowed'
                  }`}
                >
                  {isWithdrawing ? 'Processing...' : 'Withdraw Funds'}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}