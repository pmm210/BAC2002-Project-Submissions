import React, { useState } from 'react';
import Image from 'next/image';
import { NFTListing, PaymentSchedule } from '@/types';
import { PAYMENT_SCHEDULE } from '@/config/constants';
import { formatEther } from 'ethers';

import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from "@/components/ui/hover-card";
import { InfoIcon } from "lucide-react";

interface NFTCardProps {
  listing: NFTListing;
  onBuy: (listing: NFTListing, schedule: PaymentSchedule) => void;
}

// Define the type for frequency values
type PaymentFrequency = "weekly" | "bi-weekly" | "monthly";

export function NFTCard({ listing, onBuy }: NFTCardProps) {
  // Initialize with first available values from the listing
  const [selectedDuration, setSelectedDuration] = useState(
    listing.allowedDurations[0] || PAYMENT_SCHEDULE.DEFAULT_DURATION
  );
  const [selectedFrequency, setSelectedFrequency] = useState<PaymentFrequency>(
    (listing.allowedFrequencies[0] || PAYMENT_SCHEDULE.DEFAULT_FREQUENCY) as PaymentFrequency
  );

  const calculatePayments = () => {
    const totalPrice = listing.totalPrice;
    const initialPayment = (totalPrice * BigInt(3333)) / BigInt(10000); // 33.33%
    const remainingBalance = totalPrice - initialPayment;
    const installmentAmount = remainingBalance / BigInt(2); // 2 remaining payments

    return {
      duration: selectedDuration,
      frequency: selectedFrequency,
      totalPrice,
      initialPayment,
      installmentAmount,
      penaltyRate: listing.penaltyRate,
    };
  };

  const handleBuy = () => {
    const schedule = calculatePayments();
    onBuy(listing, schedule);
  };

  return (
    <Card className="overflow-hidden">
      <div className="relative w-full aspect-square">
        <Image
          src={listing.nft.image}
          alt={listing.nft.title}
          layout="fill"
          objectFit="cover"
          className="transition-transform duration-300 hover:scale-105"
        />
      </div>

      <CardHeader>
        <CardTitle className="text-lg">{listing.nft.title}</CardTitle>
        <p className="text-sm text-muted-foreground">{listing.nft.collection.name}</p>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="space-y-1">
          <p className="text-lg font-medium">
            {formatEther(listing.totalPrice)} ETH
          </p>
          <p className="text-sm text-muted-foreground">
            Initial Payment: {formatEther((listing.totalPrice * BigInt(3333)) / BigInt(10000))} ETH
          </p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="duration">Payment Duration</Label>
          <Select
            value={selectedDuration.toString()}
            onValueChange={(value) => setSelectedDuration(Number(value))}
          >
            <SelectTrigger id="duration">
              <SelectValue placeholder="Select duration" />
            </SelectTrigger>
            <SelectContent>
              {listing.allowedDurations.map((duration) => (
                <SelectItem 
                  key={duration} 
                  value={duration.toString()}
                >
                  {duration} Month{duration > 1 ? 's' : ''}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="frequency">Payment Frequency</Label>
          <Select
            value={selectedFrequency}
            onValueChange={(value: PaymentFrequency) => setSelectedFrequency(value)}
          >
            <SelectTrigger id="frequency">
              <SelectValue placeholder="Select frequency" />
            </SelectTrigger>
            <SelectContent>
              {listing.allowedFrequencies.map((frequency) => (
                <SelectItem 
                  key={frequency} 
                  value={frequency as PaymentFrequency}
                >
                  {frequency.charAt(0).toUpperCase() + frequency.slice(1)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-center space-x-2">
          <HoverCard>
            <HoverCardTrigger asChild>
              <Button variant="ghost" size="icon" className="h-auto p-0">
                <InfoIcon className="h-4 w-4" />
              </Button>
            </HoverCardTrigger>
            <HoverCardContent className="w-80">
              <div className="space-y-2">
                <p className="text-sm">
                  Penalty Rate: {listing.penaltyRate}%
                </p>
                <p className="text-sm">
                  Max Penalty: {listing.penaltyRate * 3}%
                </p>
                <p className="text-xs text-muted-foreground">
                  Penalties apply for late payments and may accumulate up to the maximum rate.
                </p>
              </div>
            </HoverCardContent>
          </HoverCard>
          <div className="text-sm text-muted-foreground">
            Penalty Rate: {listing.penaltyRate}%
          </div>
        </div>
      </CardContent>

      <CardFooter>
        <Button 
          className="w-full" 
          onClick={handleBuy}
        >
          Buy Now
        </Button>
      </CardFooter>
    </Card>
  );
}

export default NFTCard;