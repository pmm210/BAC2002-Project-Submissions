import React, { useState } from 'react';
import NFTCard from './NFTCard';
import { NFTListing, PaymentSchedule } from '@/types';
import { ConnectWallet } from "@/components/shared/ConnectWallet";

// Import shadcn components
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";

interface NFTGridProps {
  listings: NFTListing[];
  onBuy: (listing: NFTListing, schedule: PaymentSchedule) => void;
}

interface FilterOptions {
  minPrice: string;
  maxPrice: string;
  collection: string;
  duration: string;
  frequency: string;
}

export function NFTGrid({ listings, onBuy }: NFTGridProps) {
  const [filters, setFilters] = useState<FilterOptions>({
    minPrice: '',
    maxPrice: '',
    collection: '',
    duration: '',
    frequency: '',
  });

  const collections = [...new Set(listings.map(listing => listing.nft.collection.name))];
  const durations = [...new Set(listings.flatMap(listing => listing.allowedDurations))];
  const frequencies = [...new Set(listings.flatMap(listing => listing.allowedFrequencies))];

  const filteredListings = listings.filter(listing => {
    const price = Number(listing.totalPrice);
    const minPrice = filters.minPrice ? Number(filters.minPrice) : 0;
    const maxPrice = filters.maxPrice ? Number(filters.maxPrice) : Infinity;

    return (
      price >= minPrice &&
      price <= maxPrice &&
      (!filters.collection || listing.nft.collection.name === filters.collection) &&
      (!filters.duration || listing.allowedDurations.includes(Number(filters.duration))) &&
      (!filters.frequency || listing.allowedFrequencies.includes(filters.frequency as any))
    );
  });

  return (
    <div className="space-y-6">
      {/* Connect Wallet Section */}
      <div className="flex justify-end">
        <ConnectWallet />
      </div>

      {/* Filter Section */}
      <Card>
        <CardHeader>
          <CardTitle>Filters</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-5">
            {/* Price Filters */}
            <div className="space-y-2">
              <Label htmlFor="minPrice">Min Price (ETH)</Label>
              <Input
                id="minPrice"
                type="number"
                value={filters.minPrice}
                onChange={(e) => setFilters({ ...filters, minPrice: e.target.value })}
                min="0"
                step="0.01"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="maxPrice">Max Price (ETH)</Label>
              <Input
                id="maxPrice"
                type="number"
                value={filters.maxPrice}
                onChange={(e) => setFilters({ ...filters, maxPrice: e.target.value })}
                min="0"
                step="0.01"
              />
            </div>

            {/* Collection Filter */}
            <div className="space-y-2">
              <Label>Collection</Label>
              <Select
                value={filters.collection || "all"} // Use "all" instead of empty string
                onValueChange={(value) => setFilters({ 
                  ...filters, 
                  collection: value === "all" ? "" : value 
                })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="All Collections" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Collections</SelectItem>
                  {collections.map((collection) => (
                    <SelectItem key={collection} value={collection}>
                      {collection}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Duration Filter */}
            <div className="space-y-2">
              <Label>Duration</Label>
              <Select
                value={filters.duration || "all"}
                onValueChange={(value) => setFilters({ 
                  ...filters, 
                  duration: value === "all" ? "" : value 
                })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Any Duration" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Any Duration</SelectItem>
                  {durations.map((duration) => (
                    <SelectItem key={duration} value={duration.toString()}>
                      {duration} Month{duration > 1 ? 's' : ''}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Frequency Filter */}
            <div className="space-y-2">
              <Label>Frequency</Label>
              <Select
                value={filters.frequency || "all"}
                onValueChange={(value) => setFilters({ 
                  ...filters, 
                  frequency: value === "all" ? "" : value 
                })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Any Frequency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Any Frequency</SelectItem>
                  {frequencies.map((frequency) => (
                    <SelectItem key={frequency} value={frequency}>
                      {frequency.charAt(0).toUpperCase() + frequency.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Grid Section */}
      <ScrollArea className="h-[calc(100vh-300px)]">
        {filteredListings.length === 0 ? (
          <Card>
            <CardContent className="flex items-center justify-center h-32">
              <p className="text-lg text-muted-foreground">
                No NFTs found matching your criteria
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
            {filteredListings.map((listing) => (
              <NFTCard
                key={`${listing.nft.contractAddress}-${listing.nft.tokenId}`}
                listing={listing}
                onBuy={onBuy}
              />
            ))}
          </div>
        )}
      </ScrollArea>
    </div>
  );
}

export default NFTGrid;