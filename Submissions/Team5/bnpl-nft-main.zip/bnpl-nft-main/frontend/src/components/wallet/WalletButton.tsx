import dynamic from 'next/dynamic';

// Import WalletButtonComponent with client-side only rendering
const WalletButton = dynamic(
  () => import('./WalletButtonComponent'),
  { 
    ssr: false,
    // Show a placeholder while the component is loading
    loading: () => (
      <div className="wallet-button-placeholder px-4 py-2 rounded-lg bg-gray-100">
        Loading...
      </div>
    )
  }
);

export default WalletButton;