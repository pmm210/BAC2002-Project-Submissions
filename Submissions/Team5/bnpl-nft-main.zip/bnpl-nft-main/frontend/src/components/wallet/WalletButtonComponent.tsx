import React from 'react';
import { useWallet } from '@/hooks/useWallet';

const _WalletButtonComponent = () => {
  const {
    address,
    isConnected,
    isWrongNetwork,
    isLoading,
    connectWallet,
    disconnect,
    switchToDefaultNetwork
  } = useWallet();

  if (isLoading) {
    return (
      <div className="px-4 py-2 rounded-lg bg-gray-100 animate-pulse">
        Connecting...
      </div>
    );
  }

  if (!isConnected) {
    return (
      <button
        onClick={connectWallet}
        disabled={isLoading}
        className="px-4 py-2 font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
      >
        Connect Wallet
      </button>
    );
  }

  if (isWrongNetwork) {
    return (
      <button
        onClick={switchToDefaultNetwork}
        className="px-4 py-2 font-semibold text-white bg-yellow-600 rounded-lg hover:bg-yellow-700 focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:ring-offset-2"
      >
        Switch Network
      </button>
    );
  }

  return (
    <div className="flex items-center space-x-2">
      <span className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg">
        {address?.slice(0, 6)}...{address?.slice(-4)}
      </span>
      <button
        onClick={() => disconnect()}
        className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
      >
        Disconnect
      </button>
    </div>
  );
}

export const WalletButtonComponent = React.memo(_WalletButtonComponent);
export default WalletButtonComponent;