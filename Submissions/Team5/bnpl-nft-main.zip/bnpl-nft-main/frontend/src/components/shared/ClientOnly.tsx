import { useEffect, useState, ReactNode } from 'react';

interface ClientOnlyProps {
  children: ReactNode;
  fallback?: ReactNode;
}

/**
 * ClientOnly is a wrapper component that renders its children only on the client side.
 * This is useful for components that need to access browser APIs or rely on client-side state.
 * 
 * @param children The components to render client-side
 * @param fallback Optional fallback to render during SSR (defaults to null)
 */
export function ClientOnly({ children, fallback = null }: ClientOnlyProps) {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return <>{fallback}</>;
  }

  return <>{children}</>;
}

export default ClientOnly;