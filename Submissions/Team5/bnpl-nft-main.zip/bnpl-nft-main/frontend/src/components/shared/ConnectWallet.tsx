import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from "@/components/ui/card";
import { Wallet, LogOut, AlertCircle, Loader2 } from "lucide-react";
import { useAccount, useConnect, useDisconnect, useChainId, useSwitchChain } from 'wagmi';
import { injected } from 'wagmi/connectors';
import { SUPPORTED_CHAINS, DEFAULT_CHAIN } from '@/config/constants';

export function ConnectWallet() {
  const { address, isConnected } = useAccount();
  const chainId = useChainId();
  const { connectAsync } = useConnect();
  const { disconnectAsync } = useDisconnect();
  const { switchChainAsync } = useSwitchChain();
  
  const [isConnecting, setIsConnecting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Check if on correct network
  const isCorrectNetwork = SUPPORTED_CHAINS.includes(chainId);

  const handleConnect = async () => {
    try {
      setIsConnecting(true);
      setError(null);
      await connectAsync({
        connector: injected()
      });
    } catch (err) {
      // Check for user rejection
      if (err instanceof Error) {
        if (err.message.includes('User rejected') ||
            err.message.includes('User denied') ||
            err.message.includes('rejected the request')) {
          setError('Connection cancelled');
          setTimeout(() => setError(null), 3000); // Clear error after 3 seconds
        } else {
          setError('Failed to connect wallet');
        }
      } else {
        setError('Failed to connect wallet');
      }
    } finally {
      setIsConnecting(false);
    }
  };

  const handleDisconnect = async () => {
    try {
      await disconnectAsync();
    } catch (err) {
      console.error('Failed to disconnect:', err);
    }
  };

  const handleSwitchNetwork = async () => {
    try {
      await switchChainAsync({ chainId: DEFAULT_CHAIN });
    } catch (err) {
      if (err instanceof Error &&
          (err.message.includes('User rejected') ||
           err.message.includes('User denied'))) {
        console.log('User cancelled network switch');
      } else {
        console.error('Failed to switch network:', err);
      }
    }
  };

  if (isConnected && !isCorrectNetwork) {
    return (
      <Card className="w-[300px]">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-yellow-500" />
            Wrong Network
          </CardTitle>
        </CardHeader>
        <CardContent>
          <CardDescription>
            Please switch to {DEFAULT_CHAIN === 42161 ? 'Arbitrum One' : 'Arbitrum Sepolia'} to continue.
          </CardDescription>
        </CardContent>
        <CardFooter>
          <Button
            variant="default"
            className="w-full"
            onClick={handleSwitchNetwork}
          >
            Switch Network
          </Button>
        </CardFooter>
      </Card>
    );
  }

  if (isConnected && address) {
    return (
      <Button 
        variant="outline"
        size="sm"
        className="gap-2"
        onClick={handleDisconnect}
      >
        <span className="font-mono">{`${address.slice(0, 6)}...${address.slice(-4)}`}</span>
        <LogOut className="h-4 w-4" />
      </Button>
    );
  }

  return (
    <div className="space-y-2">
      <Button
        variant="default"
        size="sm"
        className="gap-2"
        onClick={handleConnect}
        disabled={isConnecting}
      >
        {isConnecting ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin" />
            Connecting...
          </>
        ) : (
          <>
            Connect Wallet
            <Wallet className="h-4 w-4" />
          </>
        )}
      </Button>
      {error && (
        <p className="text-sm text-red-500">{error}</p>
      )}
    </div>
  );
}