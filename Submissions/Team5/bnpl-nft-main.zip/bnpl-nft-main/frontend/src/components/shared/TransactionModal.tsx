import React from 'react';
import { Transaction } from '@/types';
import { formatEther } from 'ethers';

interface TransactionModalProps {
  transaction: Transaction;
  isOpen: boolean;
  onClose: () => void;
}

export function TransactionModal({ transaction, isOpen, onClose }: TransactionModalProps) {
  if (!isOpen) return null;

  const getStatusColor = () => {
    switch (transaction.status) {
      case 'pending':
        return 'text-yellow-600 bg-yellow-100';
      case 'success':
        return 'text-green-600 bg-green-100';
      case 'failed':
        return 'text-red-600 bg-red-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIcon = () => {
    switch (transaction.status) {
      case 'pending':
        return (
          <svg className="w-8 h-8 animate-spin" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
            <path
              className="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
            />
          </svg>
        );
      case 'success':
        return (
          <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
        );
      case 'failed':
        return (
          <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        );
    }
  };

  const getTransactionTypeText = () => {
    switch (transaction.type) {
      case 'list':
        return 'NFT Listing';
      case 'buy':
        return 'NFT Purchase';
      case 'payment':
        return 'Loan Payment';
      case 'default':
        return 'Loan Default';
      default:
        return 'Transaction';
    }
  };

  const getStatusText = () => {
    switch (transaction.status) {
      case 'pending':
        return 'Transaction Pending';
      case 'success':
        return 'Transaction Successful';
      case 'failed':
        return 'Transaction Failed';
      default:
        return 'Unknown Status';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="fixed inset-0 bg-black bg-opacity-50" onClick={onClose} />
      
      <div className="relative z-50 w-full max-w-md p-6 mx-4 bg-white rounded-lg shadow-xl">
        <div className="text-center">
          <div className={`inline-flex p-4 rounded-full ${getStatusColor()}`}>
            {getStatusIcon()}
          </div>

          <h3 className="mt-4 text-lg font-medium">{getStatusText()}</h3>
          <p className="mt-1 text-sm text-gray-500">{getTransactionTypeText()}</p>

          <div className="mt-4 space-y-3">
            <div className="p-3 text-sm bg-gray-50 rounded-lg">
              <p className="text-gray-500">Transaction Hash</p>
              <a
                href={`https://arbiscan.io/tx/${transaction.hash}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 break-all hover:text-blue-800"
              >
                {transaction.hash}
              </a>
            </div>

            {transaction.data.nft && (
              <div className="p-3 text-sm bg-gray-50 rounded-lg">
                <p className="text-gray-500">NFT</p>
                <p className="font-medium">{transaction.data.nft.title}</p>
                <p className="text-sm text-gray-500">{transaction.data.nft.collection.name}</p>
              </div>
            )}

            {transaction.data.amount && (
              <div className="p-3 text-sm bg-gray-50 rounded-lg">
                <p className="text-gray-500">Amount</p>
                <p className="font-medium">{formatEther(transaction.data.amount)} ETH</p>
              </div>
            )}
          </div>

          {transaction.status === 'failed' && (
            <div className="mt-4 p-3 text-sm text-red-600 bg-red-50 rounded-lg">
              Transaction failed. Please try again or contact support if the issue persists.
            </div>
          )}

          <button
            onClick={onClose}
            className="w-full px-4 py-2 mt-6 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}

export default TransactionModal;
