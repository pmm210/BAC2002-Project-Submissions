/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: [
      'rose-implicit-cat-131.mypinata.cloud', 
      'other-allowed-domain.com',
      'via.placeholder.com'
    ], 
  },
  env: {
    PINATA_JWT: process.env.PINATA_JWT,
    PINATA_GATEWAY: process.env.PINATA_GATEWAY
  }
};

module.exports = nextConfig;