// FileUploadComponent.jsx
import React, { useState } from 'react';

function FileUploadComponent() {
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  const handleFileUpload = async () => {
    if (!file) {
      setMessage("No file selected.");
      return;
    }

    setLoading(true);
    setMessage('');

    const formData = new FormData();
    formData.append("file", file);

    try {
      // Send the file to the backend server
      const response = await fetch("http://localhost:3001/upload", {
        method: "POST",
        body: formData,
      });

      if (response.ok) {
        const data = await response.json();
        console.log("File uploaded:", data);
        setMessage("File uploaded successfully!");
      } else {
        throw new Error("Failed to upload file");
      }
    } catch (error) {
      console.error("Upload failed:", error);
      setMessage("Upload failed: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <input type="file" onChange={handleFileChange} />
      <button onClick={handleFileUpload} disabled={loading}>
        {loading ? "Uploading..." : "Upload File"}
      </button>
      {message && <p>{message}</p>}
    </div>
  );
}

export default FileUploadComponent;
