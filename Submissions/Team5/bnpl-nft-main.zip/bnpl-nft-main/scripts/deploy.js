const { ethers, network } = require("hardhat");

async function main() {
  // Get deployer account
  const [deployer] = await ethers.getSigners();
  console.log("Deploying contracts with:", deployer.address);
  console.log("Network:", network.name);

  try {
    // Deploy NFTEscrow
    const NFTEscrow = await ethers.getContractFactory("NFTEscrow");
    const nftEscrow = await NFTEscrow.deploy();
    await nftEscrow.waitForDeployment();
    console.log("NFTEscrow deployed to:", nftEscrow.target);

    // Deploy LoanManager
    const LoanManager = await ethers.getContractFactory("LoanManager");
    const loanManager = await LoanManager.deploy(nftEscrow.target);
    await loanManager.waitForDeployment();
    console.log("LoanManager deployed to:", loanManager.target);

    // Transfer ownership - wait for transaction confirmation
    const transferTx = await nftEscrow.transferOwnership(loanManager.target);
    await transferTx.wait();
    console.log("NFTEscrow ownership transferred to LoanManager");

    // Deploy Mock NFTs only on test networks
    if (network.name === "hardhat" || network.name === "localhost" || network.name.includes("sepolia")) {
      const MockERC721 = await ethers.getContractFactory("MockERC721");
      const mockERC721 = await MockERC721.deploy();
      await mockERC721.waitForDeployment();
      console.log("MockERC721 deployed to:", mockERC721.target);

      const MockERC1155 = await ethers.getContractFactory("MockERC1155");
      const mockERC1155 = await MockERC1155.deploy();
      await mockERC1155.waitForDeployment();
      console.log("MockERC1155 deployed to:", mockERC1155.target);

      // Save mock addresses for testing
      deployments.MockERC721 = mockERC721.target;
      deployments.MockERC1155 = mockERC1155.target;
    }

    // Create deployments directory if it doesn't exist
    const fs = require("fs");
    const dir = './deployments';
    if (!fs.existsSync(dir)){
      fs.mkdirSync(dir);
    }

    // Write deployment info
    const deployments = {
      NFTEscrow: nftEscrow.target,
      LoanManager: loanManager.target,
      network: network.name,
      chainId: network.config.chainId,
      deployer: deployer.address,
      timestamp: new Date().toISOString()
    };

    const deploymentPath = `./deployments/${network.name}.json`;
    fs.writeFileSync(
      deploymentPath,
      JSON.stringify(deployments, null, 2)
    );
    console.log(`Deployment info saved to ${deploymentPath}`);

    // Verify contracts if on testnet or mainnet
    if (network.name !== "hardhat" && network.name !== "localhost") {
      console.log("\nVerifying contracts on Etherscan/Arbiscan...");
      try {
        await hre.run("verify:verify", {
          address: nftEscrow.target,
          constructorArguments: []
        });
        await hre.run("verify:verify", {
          address: loanManager.target,
          constructorArguments: [nftEscrow.target]
        });
      } catch (err) {
        console.log("Verification error:", err);
      }
    }
  } catch (error) {
    console.error("Deployment error:", error);
    process.exit(1);
  }
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });