const { ethers } = require("ethers");
const fs = require("fs");

const generateWallet = () => {
    // Create a random wallet
    const wallet = ethers.Wallet.createRandom();
    
    // Create .env content
    const envContent = `PRIVATE_KEY=${wallet.privateKey}\n` +
                      `WALLET_ADDRESS=${wallet.address}\n` +
                      `ARBITRUM_SEPOLIA_RPC_URL=https://sepolia-rollup.arbitrum.io/rpc\n` +
                      `ARBITRUM_MAINNET_RPC_URL=https://arb1.arbitrum.io/rpc\n`;
    
    // Write to .env.test
    fs.writeFileSync(".env.test", envContent);

    console.log("\nNew Test Wallet Created!");
    console.log("Address:", wallet.address);
    console.log("Private Key:", wallet.privateKey);
    console.log("Mnemonic:", wallet.mnemonic.phrase);
    console.log("\nEnvironment variables saved to .env.test");
};

generateWallet();