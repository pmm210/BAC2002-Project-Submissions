/**
 * This script updates the frontend constants with deployed contract addresses.
 * Run this after deploying contracts to update the frontend config.
 */

const fs = require('fs');
const path = require('path');

// Path to the constants.ts file
const constantsPath = path.join(__dirname, '../frontend/src/config/constants.ts');

// Get deployed contract addresses from the latest deployment
function getDeployedAddresses() {
  try {
    // Check the deployments directory for the latest deployment file
    const deploymentsDir = path.join(__dirname, '../deployments');
    if (!fs.existsSync(deploymentsDir)) {
      console.error('Deployments directory not found. Deploy contracts first.');
      process.exit(1);
    }

    const files = fs.readdirSync(deploymentsDir);
    if (files.length === 0) {
      console.error('No deployment files found. Deploy contracts first.');
      process.exit(1);
    }

    // Get the latest deployment file (you might want to filter by network)
    const latestFile = files.sort((a, b) => {
      return fs.statSync(path.join(deploymentsDir, b)).mtime.getTime() - 
             fs.statSync(path.join(deploymentsDir, a)).mtime.getTime();
    })[0];

    const deploymentData = JSON.parse(
      fs.readFileSync(path.join(deploymentsDir, latestFile), 'utf8')
    );

    return {
      network: deploymentData.network,
      chainId: deploymentData.chainId,
      addresses: {
        NFT_ESCROW: deploymentData.NFTEscrow,
        LOAN_MANAGER: deploymentData.LoanManager,
        MockERC721: deploymentData.MockERC721,
        MockERC1155: deploymentData.MockERC1155
      }
    };
  } catch (error) {
    console.error('Error reading deployment data:', error);
    process.exit(1);
  }
}

// Update the constants.ts file with the deployed addresses
function updateConstants(deploymentData) {
  try {
    // Read the constants file
    let constantsContent = fs.readFileSync(constantsPath, 'utf8');

    // Update the NFT_ESCROW and LOAN_MANAGER addresses for the deployed network
    const networkCode = deploymentData.chainId;
    
    // Update the main contracts
    if (deploymentData.addresses.NFT_ESCROW && deploymentData.addresses.LOAN_MANAGER) {
      constantsContent = constantsContent.replace(
        new RegExp(`\\[CHAIN_ID\\.\\w+\\s*:\\s*${networkCode}\\]\\s*:\\s*\\{[^}]*NFT_ESCROW\\s*:\\s*'[^']*'[^}]*\\}`, 'g'),
        `[CHAIN_ID.${deploymentData.network.toUpperCase()}]: {
    NFT_ESCROW: '${deploymentData.addresses.NFT_ESCROW}' as Address,
    LOAN_MANAGER: '${deploymentData.addresses.LOAN_MANAGER}' as Address
  }`
      );
    }

    // Update the MockNFT addresses
    if (deploymentData.addresses.MockERC721) {
      constantsContent = constantsContent.replace(
        /address:\s*'0x0000000000000000000000000000000000000000'\s*,\s*\/\/\s*Update with deployed MockERC721 address/g,
        `address: '${deploymentData.addresses.MockERC721}' as Address, // Deployed MockERC721 address`
      );
    }

    if (deploymentData.addresses.MockERC1155) {
      constantsContent = constantsContent.replace(
        /address:\s*'0x0000000000000000000000000000000000000000'\s*,\s*\/\/\s*Update with deployed MockERC1155 address/g,
        `address: '${deploymentData.addresses.MockERC1155}' as Address, // Deployed MockERC1155 address`
      );
    }

    // Write the updated file
    fs.writeFileSync(constantsPath, constantsContent);
    console.log(`Successfully updated contract addresses in ${constantsPath}`);
    console.log('Updated addresses:');
    console.log(JSON.stringify(deploymentData.addresses, null, 2));
  } catch (error) {
    console.error('Error updating constants:', error);
    process.exit(1);
  }
}

// Main function
function main() {
  console.log('Updating frontend constants with deployed contract addresses...');
  const deploymentData = getDeployedAddresses();
  updateConstants(deploymentData);
  console.log('Done!');
}

main();