const express = require("express");
const cors = require("cors");
const axios = require("axios");
const FormData = require("form-data");
require("dotenv").config();

console.log("PINATA_JWT:", process.env.PINATA_JWT);
console.log("PINATA_GATEWAY:", process.env.PINATA_GATEWAY);

const app = express();
const port = 3001;

// Enable CORS for all routes (you can restrict this to specific domains)
app.use(cors());

// Middleware to handle JSON body
app.use(express.json());

// Route to handle file upload and forward it to Pinata
app.post("/api/pinata/file", async (req, res) => {
  if (!req.files || Object.keys(req.files).length === 0) {
    return res.status(400).send("No files were uploaded.");
  }

  const file = req.files.file; // The file sent from the frontend
  const form = new FormData();
  form.append("file", file.data, file.name);

  try {
    const response = await axios.post("https://uploads.pinata.cloud/v3/files", form, {
      headers: {
        ...form.getHeaders(),
        Authorization: `Bearer ${process.env.PINATA_JWT}`,
      },
    });

    res.json(response.data); // Send back the response from Pinata
  } catch (error) {
    console.error("Error uploading file:", error);
    res.status(500).send("Failed to upload file to Pinata");
  }
});

// Route to handle JSON upload and forward it to Pinata
app.post("/api/pinata/json", async (req, res) => {
  const jsonData = req.body; // The JSON data sent from the frontend
  try {
    const response = await axios.post("https://api.pinata.cloud/pinning/pinJSONToIPFS", jsonData, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.PINATA_JWT}`,
      },
    });

    res.json(response.data); // Send back the response from Pinata
  } catch (error) {
    console.error("Error uploading JSON:", error);
    res.status(500).send("Failed to upload JSON to Pinata");
  }
});



// Route to fetch content from IPFS through Pinata
app.get("/api/pinata/ipfs/:hash", async (req, res) => {
  const hash = req.params.hash;
  try {
    // Forward the request to Pinata Gateway with authentication
    const response = await axios.get(`https://${process.env.PINATA_GATEWAY}/ipfs/${hash}`, {
      headers: {
        Authorization: `Bearer ${process.env.PINATA_JWT}`,
      },
      responseType: 'arraybuffer'  // Handle any type of response (binary or text)
    });
    
    // Set the same content type as the Pinata response
    res.set('Content-Type', response.headers['content-type']);
    res.send(response.data);
  } catch (error) {
    console.error("Error fetching from IPFS:", error);
    res.status(error.response?.status || 500).send("Failed to fetch IPFS content");
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
