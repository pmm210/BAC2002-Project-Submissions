const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("BNPL NFT System", function () {
  let nftEscrow, loanManager, mockERC721, mockERC1155;
  let owner, seller, buyer, otherAccount;
  const MONTH = 30 * 24 * 60 * 60; // 30 days in seconds
  const GRACE_PERIOD = 3 * 24 * 60 * 60; // 3 days in seconds

  beforeEach(async function () {
    [owner, seller, buyer, otherAccount] = await ethers.getSigners();

    // Deploy MockNFTs
    const MockERC721 = await ethers.getContractFactory("MockERC721");
    mockERC721 = await MockERC721.deploy();
    
    const MockERC1155 = await ethers.getContractFactory("MockERC1155");
    mockERC1155 = await MockERC1155.deploy();

    // Deploy NFTEscrow
    const NFTEscrow = await ethers.getContractFactory("NFTEscrow");
    nftEscrow = await NFTEscrow.deploy();

    // Deploy LoanManager
    const LoanManager = await ethers.getContractFactory("LoanManager");
    loanManager = await LoanManager.deploy(nftEscrow.target);

    // Transfer ownership of NFTEscrow to LoanManager
    await nftEscrow.transferOwnership(loanManager.target);

    // Mint NFTs to seller
    await mockERC721.connect(owner).mint(seller.address);
    await mockERC1155.connect(owner).mint(seller.address, 1, 10, "0x");
  });

  describe("Loan Creation", function () {
    it("should create a loan with ERC721", async function () {
      const totalPrice = ethers.parseEther("1");
      const initialPayment = (totalPrice * BigInt(3333)) / BigInt(10000); // 33.33%
      
      await mockERC721.connect(seller).approve(loanManager.target, 1);
      
      await expect(
        loanManager.connect(seller).createLoan(
          mockERC721.target,
          1,
          1, // amount (not used for ERC721)
          totalPrice,
          5, // 5% penalty
          buyer.address,
          0, // ERC721
          { value: initialPayment }
        )
      ).to.emit(loanManager, "LoanCreated");

      const loan = await loanManager.loans(1);
      expect(loan.status).to.equal(0); // ACTIVE
      expect(loan.buyer).to.equal(buyer.address);
      expect(loan.seller).to.equal(seller.address);
    });

    it("should create a loan with ERC1155", async function () {
      const totalPrice = ethers.parseEther("1");
      const initialPayment = (totalPrice * BigInt(3333)) / BigInt(10000);
      
      await mockERC1155.connect(seller).setApprovalForAll(loanManager.target, true);
      
      await expect(
        loanManager.connect(seller).createLoan(
          mockERC1155.target,
          1,
          5, // amount of tokens
          totalPrice,
          5,
          buyer.address,
          1, // ERC1155
          { value: initialPayment }
        )
      ).to.emit(loanManager, "LoanCreated");

      const loan = await loanManager.loans(1);
      expect(loan.amount).to.equal(5);
      expect(loan.standard).to.equal(1); // ERC1155
    });
  });

  describe("Payment Processing", function () {
    let loanId;
    const totalPrice = ethers.parseEther("1");
    const initialPayment = (totalPrice * BigInt(3333)) / BigInt(10000);
    const installmentAmount = (totalPrice - initialPayment) / BigInt(2);

    beforeEach(async function () {
      await mockERC721.connect(seller).approve(loanManager.target, 1);
      
      await loanManager.connect(seller).createLoan(
        mockERC721.target,
        1,
        1,
        totalPrice,
        5,
        buyer.address,
        0,
        { value: initialPayment }
      );
      
      loanId = 1;
    });

    it("should process regular payment", async function () {
      await ethers.provider.send("evm_increaseTime", [MONTH]);
      await ethers.provider.send("evm_mine");

      await expect(
        loanManager.connect(buyer).makePayment(loanId, { value: installmentAmount })
      ).to.emit(loanManager, "PaymentMade");

      const loan = await loanManager.loans(loanId);
      expect(loan.remainingBalance).to.equal(installmentAmount);
    });

    it("should handle late payment with penalty", async function () {
      await ethers.provider.send("evm_increaseTime", [MONTH + GRACE_PERIOD + 1]);
      await ethers.provider.send("evm_mine");

      const penalty = (totalPrice * BigInt(5)) / BigInt(100); // 5% penalty
      const totalDue = installmentAmount + penalty;

      await expect(
        loanManager.connect(buyer).makePayment(loanId, { value: totalDue })
      ).to.emit(loanManager, "PenaltyIncurred");
    });

    it("should complete loan after final payment", async function () {
      // First payment
      await ethers.provider.send("evm_increaseTime", [MONTH]);
      await loanManager.connect(buyer).makePayment(loanId, { value: installmentAmount });

      // Second (final) payment
      await ethers.provider.send("evm_increaseTime", [MONTH]);
      await expect(
        loanManager.connect(buyer).makePayment(loanId, { value: installmentAmount })
      ).to.emit(loanManager, "LoanCompleted");

      const loan = await loanManager.loans(loanId);
      expect(loan.status).to.equal(1); // COMPLETED
      expect(await mockERC721.ownerOf(1)).to.equal(buyer.address);
    });
  });

  describe("Default Handling", function () {
    it("should default after 3 missed payments", async function () {
      const totalPrice = ethers.parseEther("1");
      const initialPayment = (totalPrice * BigInt(3333)) / BigInt(10000);
      
      await mockERC721.connect(seller).approve(loanManager.target, 1);
      await loanManager.connect(seller).createLoan(
        mockERC721.target,
        1,
        1,
        totalPrice,
        5,
        buyer.address,
        0,
        { value: initialPayment }
      );

      // Skip 3 months + grace period
      await ethers.provider.send("evm_increaseTime", [3 * MONTH + GRACE_PERIOD + 1]);
      await ethers.provider.send("evm_mine");

      const installmentAmount = (totalPrice - initialPayment) / BigInt(2);
      const penalty = (totalPrice * BigInt(5)) / BigInt(100); // 5% penalty
      await expect(
        loanManager.connect(buyer).makePayment(1, { value: installmentAmount + penalty })
      ).to.emit(loanManager, "LoanDefaulted");

      const loan = await loanManager.loans(1);
      expect(loan.status).to.equal(2); // DEFAULTED
      expect(await mockERC721.ownerOf(1)).to.equal(seller.address);
    });
  });
});
