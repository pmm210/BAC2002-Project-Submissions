const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("NFTEscrow Contract", function () {
  let nftEscrow, mockERC721, mockERC1155;
  let owner, seller, buyer;
  const NFTStandard = { ERC721: 0, ERC1155: 1 };

  beforeEach(async function () {
    [owner, seller, buyer] = await ethers.getSigners();

    // Deploy MockNFTs
    const MockERC721 = await ethers.getContractFactory("MockERC721");
    mockERC721 = await MockERC721.deploy();
    await mockERC721.deployed();

    const MockERC1155 = await ethers.getContractFactory("MockERC1155");
    mockERC1155 = await MockERC1155.deploy();
    await mockERC1155.deployed();

    // Deploy NFTEscrow
    const NFTEscrow = await ethers.getContractFactory("NFTEscrow");
    nftEscrow = await NFTEscrow.deploy();
    await nftEscrow.deployed();

    // Mint NFTs to seller
    await mockERC721.connect(owner).mint(seller.address);
    await mockERC1155.connect(owner).mint(seller.address, 1, 10, "0x");
  });

  it("should deposit ERC721 NFT into escrow", async function () {
    await mockERC721.connect(seller).approve(nftEscrow.address, 1);

    await nftEscrow.connect(owner).depositNFT(mockERC721.address, 1, seller.address, 1, NFTStandard.ERC721);

    const escrow = await nftEscrow.escrows(0);
    expect(escrow.nftContract).to.equal(mockERC721.address);
    expect(escrow.tokenId).to.equal(1);
    expect(escrow.amount).to.equal(1);
    expect(escrow.seller).to.equal(seller.address);
    expect(escrow.isActive).to.be.true;
  });

  it("should deposit ERC1155 NFT into escrow", async function () {
    await mockERC1155.connect(seller).setApprovalForAll(nftEscrow.address, true);

    await nftEscrow.connect(owner).depositNFT(mockERC1155.address, 1, seller.address, 5, NFTStandard.ERC1155);

    const escrow = await nftEscrow.escrows(0);
    expect(escrow.nftContract).to.equal(mockERC1155.address);
    expect(escrow.tokenId).to.equal(1);
    expect(escrow.amount).to.equal(5);
    expect(escrow.seller).to.equal(seller.address);
    expect(escrow.isActive).to.be.true;
  });

  it("should release ERC721 NFT from escrow", async function () {
    await mockERC721.connect(seller).approve(nftEscrow.address, 1);

    await nftEscrow.connect(owner).depositNFT(mockERC721.address, 1, seller.address, 1, NFTStandard.ERC721);
    await nftEscrow.connect(owner).releaseNFT(0, buyer.address);

    expect(await mockERC721.ownerOf(1)).to.equal(buyer.address);
  });

  it("should release ERC1155 NFT from escrow", async function () {
    await mockERC1155.connect(seller).setApprovalForAll(nftEscrow.address, true);

    await nftEscrow.connect(owner).depositNFT(mockERC1155.address, 1, seller.address, 5, NFTStandard.ERC1155);
    await nftEscrow.connect(owner).releaseNFT(0, buyer.address);

    expect(await mockERC1155.balanceOf(buyer.address, 1)).to.equal(5);
  });

  it("should handle default correctly", async function () {
    await mockERC721.connect(seller).approve(nftEscrow.address, 1);

    await nftEscrow.connect(owner).depositNFT(mockERC721.address, 1, seller.address, 1, NFTStandard.ERC721);
    await nftEscrow.connect(owner).handleDefault(0);

    expect(await mockERC721.ownerOf(1)).to.equal(seller.address);
  });
});